module SIL-Syntax
signature
  operations
    Typevar	: TV 	-> TExp
    Typeapp	: List(TExp) * TC 	-> TExp
    Funtype	: List(TExp) * TExp 	-> TExp
  operations
    PVP	: PV * TExp 	-> PVP
  operations
    Tscm	: List(TV) * TExp 	-> Tscm
  operations
    Name	: PV * TExp * String 	-> Export
    Type	: TExp * String 	-> Export
  operations
    Boxed	: 	    Algdesc
    Flat	: 	    Algdesc
  operations
    Term	: List((Algdesc,List(TV),TC,List(Rator))) 	-> Alg
  operations
    Rator	: PV * List(TExp) 	-> Rator
  operations
    Normal	: 	    Absdesc
    Inline	: 	    Absdesc
  operations
    Vdec	: PV * Tscm * Exp 	-> Vdec
    Fdec	: PV * Tscm * Fargs * Absdesc * Exp 	-> Fdec
    PV-comma-s	: List(PV) 	-> Fargs
  operations
    Var	: PVP 	-> SE
    Const	: Const 	-> SE
    StrConst	: String 	-> Const
    IntConst	: Int 	-> Const
    FltConst	: Float 	-> Const
  operations
    Simple	: SE 	-> Exp
    App	: PVP * List(SE) 	-> Exp
    Case	: SE * List(Calt) * Option(Exp) 	-> Exp
    Bind	: Vdec * Exp 	-> Exp
    Letrec	: List(Fdec) * Exp 	-> Exp
    Goto	: PVP * List(SE) 	-> Exp
    Label	: List(Fdec) * Exp 	-> Exp
    Raise	: Option(SE) * TExp 	-> Exp
    Handle	: Exp * PV * Exp 	-> Exp
  operations
    Calt	: PVP * List(PV) * Exp 	-> Calt
  operations
    Val	: Vdec 	-> Dec
    Funs	: List(Fdec) 	-> Dec
  operations
    Program	: List(Export) * List(Alg) * List(Dec) 	-> Program
