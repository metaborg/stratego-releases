/* %% $Id: tree-to-dot.h,v 1.3 1999/03/10 14:29:37 js Exp $ */

#ifndef _TREE_TO_DOT_H_
#define _TREE_TO_DOT_H_ 1

#include <stack.h>

void SGtreeToDotFile(char *prg, char *fnam, ATerm t, ATbool suppress);
void SG_StacksToDotFile(stacks *, int);
void SG_LinksToDot(FILE *, stack *);

FILE  *SG_StackDot(void);

ATerm      SG_TermYield(ATermAppl);
ATerm      SG_DotTermYield(ATerm);

#endif  /* _TREE_TO_DOT_H_ */
