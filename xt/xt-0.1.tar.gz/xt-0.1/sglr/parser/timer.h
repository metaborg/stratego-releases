/*
  $Id:
 */

double SG_Timer(void);
long SG_Allocated(void);
void SG_PageFlt(long *maj, long *min);
