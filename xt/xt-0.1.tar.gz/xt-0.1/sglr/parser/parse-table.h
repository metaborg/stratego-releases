/*
  %% $Id: parse-table.h,v 1.17 1999/10/29 15:36:04 js Exp $

*/

#ifndef _PARSE_TABLE_
#define _PARSE_TABLE_  1

#include <aterm2.h>
  /*  Internal ATerm function: sglr happens to know to collect garbage.  */
  void AT_collect(int size);
  #define ATcollect()  AT_collect(2)

#include "sglr.h"

typedef struct _parse_table parse_table;

typedef enum ActionKind {ERROR, SHIFT, REDUCE, REDUCE_LA, ACCEPT}  actionkind;

/*  Some global variables/macros  */

#define SG_APPLLABEL    "#"
#define SG_REJECTLABEL  "X"
extern  token SG_EOF_Token;
extern  token SG_Zero_Token;
extern  AFun  SG_GtrPrio_AFun, SG_LeftPrio_AFun, SG_RightPrio_AFun,
              SG_Shift_AFun, SG_Reduce_AFun, SG_Appl_AFun, SG_Reject_AFun,
              SG_Aprod_AFun, SG_Amb_AFun;

/*  Function prototypes  */

#define SG_Max(a,b)  ((a>b)?a:b)

state         SG_LookupGoto(parse_table *pt, state s, label l);
actions       SG_LookupAction(parse_table *pt, state s, token c);
production    SG_LookupProduction(parse_table *pt, label c);
ATbool        SG_ProdIsInjection(parse_table *pt, label l);
ATermList     SG_LookupPriority(parse_table *pt, label l);
ATermInt      SG_GetATint(int l, size_t numprods);

#ifdef HAVE_REJECTABILITY_DETERMINATION
  ATbool SG_Rejectable(state s);
#else
  #define SG_Rejectable(s)  ATtrue
#endif


actionkind    SG_ActionKind(action a);

state         SG_A_STATE(action a);
int           SG_A_NR_ARGS(action a);
label         SG_A_PROD(action a);
ATbool        SG_A_REJECT(action a);
lookahead     SG_A_LOOKAHEAD(action a);

parse_table   *SG_AddParseTable(char *prgname, char *L, char *FN);
void          SG_RemoveParseTable(char *prgname, char *L);
parse_table   *SG_BuildParseTable(ATermAppl t);
void          SG_SaveParseTable(char *L, parse_table *pt);
void          SG_ClearParseTable(char *L);
parse_table   *SG_LookupParseTable(char *L, ATbool may_fail);

/*  Representation/data structures  */

struct _parse_table  {
  state      initial;
  size_t     numstates;
  size_t     numprods;
  actions    **actions;
  state      **gotos;
  production *productions;
  ATermTable priorities;
};

#define       SG_PT_INITIAL(pt)     ((pt)->initial)
#define       SG_PT_NUMSTATES(pt)   ((pt)->numstates)
#define       SG_PT_NUMPRODS(pt)    ((pt)->numprods)
#define       SG_PT_ACTIONS(pt)     ((pt)->actions)
#define       SG_PT_GOTOS(pt)       ((pt)->gotos)
#define       SG_PT_PRODUCTIONS(pt) ((pt)->productions)
#define       SG_PT_PRIORITIES(pt)  ((pt)->priorities)

#endif /*  _PARSE_TABLE_  */
