/*  $Id: sglr-version.h,v 1.18 1999/10/29 15:36:07 js Exp $  */

#define sglr_major_version      "2"
#define sglr_minor_version      "21"
#define sglr_version            sglr_major_version"."sglr_minor_version
