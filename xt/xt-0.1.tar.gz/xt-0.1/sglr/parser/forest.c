/*
  $Id: forest.c,v 1.27 1999/10/11 14:24:52 js Exp $
 */

#include <stdlib.h>

#include <aterm2.h>

#include "mem-alloc.h"
#include "forest.h"
#include "parse-table.h"
#include "sglr.h"

extern long sg_nr_rejects;


int SG_AmbCalls(int mode)
{
  static int nr_ambiguities = 0;

  switch(mode) {
    case SG_NRAMB_ZERO:
      return nr_ambiguities = 0;
    case SG_NRAMB_INC:
      return nr_ambiguities++;
    case SG_NRAMB_DEC:
      return nr_ambiguities--;
    case SG_NRAMB_ASK:
    default:
      return nr_ambiguities;
  }
}

int SG_MaxNrAmb(int mode)
{
  static int nr_ambiguities = 0;

  switch(mode) {
    case SG_NRAMB_ZERO:
      return nr_ambiguities = 0;
    case SG_NRAMB_INC:
      return nr_ambiguities++;
    case SG_NRAMB_DEC:
      return nr_ambiguities--;
    case SG_NRAMB_ASK:
    default:
      return nr_ambiguities;
  }
}

int SGnrAmb(int mode)
{
  static int nr_ambiguities = 0;

  switch(mode) {
    case SG_NRAMB_ZERO:
      return nr_ambiguities = 0;
    case SG_NRAMB_INC:
      return ++nr_ambiguities;
    case SG_NRAMB_DEC:
      return --nr_ambiguities;
    case SG_NRAMB_ASK:
    default:
      return nr_ambiguities;
  }
}


ATbool SG_StartInjection(parse_table *pt, label l)
{
  return ATmatch((ATerm) SG_LookupProduction(pt, l),
                 "prod([cf(opt(layout)),cf(sort(<str>)),cf(opt(layout))],"
                 "sort(\"<START>\"),no-attrs)",
                 NULL, NULL, NULL);
}


static ATerm sg_posinfo_label = NULL;
static ATerm sg_injections_label = NULL;

ATerm SG_GetPosInfoLabel(forest t)
{
  if(!SG_POSINFO)
    return NULL;

  if(!sg_posinfo_label) {
    sg_posinfo_label = ATmake("<str>","position");
  }
  return ATgetAnnotation((ATerm) t, sg_posinfo_label);
}

forest SG_SetPosInfoLabel(forest t, ATerm pi)
{
  if(!SG_POSINFO)
    return t;

  if(!sg_posinfo_label) {
    sg_posinfo_label = ATmake("<str>","position");
  }
  return (forest) ATsetAnnotation((ATerm) t, sg_posinfo_label, pi);
}

ATermInt SG_GetInjectionsLabel(forest t)
{
  if(!sg_injections_label) {
    sg_injections_label = ATmake("<str>","injections");
  }
  return (ATermInt) ATgetAnnotation((ATerm) t, sg_injections_label);
}

int SG_GetInjections(forest t)
{
  ATermInt cnt = SG_GetInjectionsLabel(t);

  return cnt ? ATgetInt(cnt) : 0;
}

forest SG_SetInjectionsLabel(forest t, ATermInt cnt)
{
  if(!sg_injections_label) {
    sg_injections_label = ATmake("<str>","injections");
  }
  return (forest) ATsetAnnotation((ATerm) t, sg_injections_label, (ATerm) cnt);
}

/*  The function |SG_Apply| is defined directly in terms of ATerm functions.  */

tree SG_Apply(parse_table *pt, label l, ATermList ts, ATbool reject, ATerm pi)
{
  tree t;

#ifdef KEEPINJECTCOUNT
  ATermList args;
  ATerm     arg;
  ATermInt  annot;
  int       injections;
#endif

  IF_STATISTICS(if(reject) sg_nr_rejects++;)

  if(!SG_NEED_TOP)
    return (tree) ATempty;

#ifdef KEEPINJECTCOUNT
  injections = SG_ProdIsInjection(pt, l) ? 1 : 0;
   /*  Compute sum of argument injection counts  */
  for(args = ts; !ATisEmpty(args); args = ATgetNext(args)) {
    arg = ATgetFirst(args);
   if((annot = SG_GetInjectionsLabel((forest) arg)))
      injections += ATgetInt(annot);
  }
#endif

  t = (tree) ATmakeAppl2(reject?SG_Reject_AFun:SG_Appl_AFun,
                         (ATerm) ATmakeAppl1(SG_Aprod_AFun,
                                             (ATerm) SG_GetATint(l, 0)),
                         (ATerm) ts);

#ifdef KEEPINJECTCOUNT
  if(injections)
    t = SG_SetInjectionsLabel((forest) t, SG_GetATint(injections,0));
#endif

  if(!SG_POSINFO || !pi)
    return t;

  return (tree) SG_SetPosInfoLabel((forest) t, pi);
}

/*  Managing Cyclic Syntax...  */

forest    CycleStart = NULL;
ATbool    CycleShown;
ATermList Cycle;

void SG_ShowCycle(forest CurrTerm, forest CycleStart)
{
  ATermList ambs;
  AFun      fun;

  if(ATisEqual(CurrTerm,CycleStart)) {
    CycleShown = ATtrue;
    return;
  }

  if(!CurrTerm) {
    Cycle      = ATempty;
    CycleShown = ATfalse;
    CurrTerm   = CycleStart;
  }

  if(CycleShown)
    return;

  switch(ATgetType(CurrTerm)) {
    case AT_APPL:

      fun  = ATgetAFun((ATermAppl) CurrTerm);
      if(ATisEqual(fun, SG_Appl_AFun)) {
        Cycle = ATinsert(Cycle,
                         (ATerm) SG_GetATint(SG_GetApplProdLabel((tree) CurrTerm), 0));
      } else if (ATisEqual(fun, SG_Aprod_AFun)) {
        Cycle = ATinsert(Cycle,
                         (ATerm) SG_GetATint(SG_GetProdLabel((tree) CurrTerm), 0));
      }

      /*  Ambiguity cluster?  */
      if(ATisEmpty(ambs = (ATermList) SG_AmbTable(SG_AMBTBL_GET,
                                                  (ATerm) CurrTerm, NULL))) {
        /*  No ambiguity  */
        SG_ShowCycle((forest) ATgetArgument((ATermAppl) CurrTerm, 1),
                                            CycleStart);
      } else {
        ATerm amb;
        /*  Encountered an ambiguity cluster  */
        for(; !ATisEmpty(ambs); ambs = ATgetNext(ambs)) {
          amb = ATgetFirst(ambs);
          if(!ATisEqual(CurrTerm, amb))
            SG_ShowCycle((forest) amb, CycleStart);
        }
      }
      break;
    case AT_LIST:
      if(!ATisEmpty((ATermList) CurrTerm)) {
        SG_ShowCycle((forest) ATgetFirst((ATermList) CurrTerm), CycleStart);
        SG_ShowCycle((forest) ATgetNext((ATermList) CurrTerm),  CycleStart);
      }
    default:
      break;
  }
}

void SG_TermIsCyclic(forest t)
{
  ATermList ambs;
  AFun      fun;

  if(CycleStart)
    /*  Revisiting cycle  */
    return;

  if(SG_IS_MARKED(t)) {
    /*  Cycle detected  */
    CycleStart = t;
    return;
  }

  SG_MARK(t);
  switch(ATgetType(t)) {
    case AT_APPL:
      if(ATisEqual((fun = ATgetAFun(t)), SG_Amb_AFun)) {
        SG_TermIsCyclic((forest) ATgetArgument((ATermAppl) t, 0));
        break;
      }
      if(ATisEqual(fun, SG_Aprod_AFun)) {
        break;
      }
      /*  Ambiguity cluster?  */
      if(ATisEmpty(ambs = (ATermList) SG_AmbTable(SG_AMBTBL_GET,
                                                  (ATerm) t, NULL))) {
        /*  No ambiguity  */
        SG_TermIsCyclic((forest) ATgetArgument((ATermAppl) t, 1));
      } else {
        ATerm amb;
        /*  Encountered an ambiguity cluster  */
        for(; !ATisEmpty(ambs); ambs = ATgetNext(ambs)) {
          amb = ATgetFirst(ambs);
          if(!ATisEqual(t, amb))
            SG_TermIsCyclic((forest) amb);
        }
      }
      break;
    case AT_LIST:
      if(!ATisEmpty((ATermList) t)) {
        SG_TermIsCyclic((forest) ATgetFirst((ATermList) t));
        SG_TermIsCyclic((forest) ATgetNext((ATermList) t));
      }
      break;
    default:
      break;
  }
  SG_UNMARK(t);
}

ATbool SG_CycleEncountered(int Mode)
{
  static ATbool CycleEncountered = ATfalse;

  switch(Mode) {
    case SG_CYCLE_ENCOUNTERED:
      CycleEncountered = ATtrue;
      break;
    case SG_CYCLE_RESET:
      if(CycleEncountered) {
        CycleEncountered = ATfalse;
        return ATtrue;
      }
      break;
  }
  return CycleEncountered;
}

ATermList SG_CyclicTerm(forest t)
{
/*
  if(!SG_CycleEncountered(SG_CYCLE_RESET))
    return ATempty;
 */

  CycleStart = NULL;

  SG_TermIsCyclic(t);
  if(!CycleStart)
    return ATempty;

  SG_ShowCycle(NULL, CycleStart);
  if(Cycle)
    return ATreverse(Cycle);

  ATwarning("Elusive cycle escaped detailed detection somehow.  Hmm...\n");
  return ATempty;
}

forest SG_ExpandApplNode(parse_table *pt, forest t, ATbool recurse,
                         ATbool doamb)
{
  forest    res;
  ATermList ambs, trms;
  AFun      fun;
  ATermList args;
  ATerm     pos_info;

  if(ATisEmpty((ATermList) t))
    return t;

  fun      = ATgetAFun(t);
  args     = ATgetArguments((ATermAppl) t);
  pos_info = SG_GetPosInfoLabel(t);

  /*  A small sanity check  */
  if(ATisEqual(fun, SG_Reject_AFun)) {
    IF_DEBUG(ATfprintf(SGlog(), "Reject seeped through:\n\t%t\n",
                       SG_LookupProduction(pt,SG_GetRejectProdLabel((tree) t))))
    return NULL;
  }

  /*  Expand aprod  */
  if(ATisEqual(fun, SG_Aprod_AFun)) {
    res = (forest) SG_LookupProduction(pt, SG_GetProdLabel((tree) t));
    return res;
  }

  /*  Expand appl(prod())-argument list  */
  if(!ATisEqual(fun, SG_Appl_AFun)) {
    if(!(res = SG_YieldPT(pt, (forest) args)))
      return NULL;

    t = (forest) ATmakeApplList(fun, (ATermList) res);
    return pos_info ? SG_SetPosInfoLabel(t, pos_info) : t;
  }

  /*  Expand appl(prod())s, handling ambiguity resolution  */
  /*  Are we encountering an ambiguity cluster?  */
  if(!doamb         /*
                        Are we even interested?  If not, we were invoked
                        to expand terms that are part of an ambiguity
                        cluster, for which the ambiguity-lookup would
                        simply recurse infinitely
                     */
     || ATisEmpty(ambs = (ATermList) SG_AmbTable(SG_AMBTBL_GET,
                                                 (ATerm) t, NULL))) {
                     /*  Is this one mapped to an ambiguity cluster?  */

    /*  No ambiguity, or we're doing one that's part of an ambiguity cluster */
    /*  First argument is an `aprod(X'), to be expanded  */
    t = (forest) ATgetFirst(args);
    if(!(t = SG_ExpandApplNode(pt, t, ATfalse, ATtrue))) {
      return NULL;
    }
    if(recurse) {
      if(!(res = SG_YieldPT(pt, (forest) ATelementAt(args, 1)))) {
        return NULL;
      }
      res = (forest) ATmakeAppl2(SG_Appl_AFun, (ATerm) t, (ATerm) res);
    } else {
      res = (forest) ATmakeAppl2(SG_Appl_AFun, (ATerm) t, ATelementAt(args, 1));
    }
  } else {
    ATbool RemovedSome = ATfalse;

    /*  Encountered an ambiguity cluster; resolve it */
    SG_MaxNrAmb(SG_NRAMB_DEC);

    /*
        Expand all terms in this ambiguity cluster; note that all these
        terms (of course) are mapped onto the ambiguity cluster, making
        some extra caution to prevent an infinite recursion necessary
     */
    for(trms=ATempty; !ATisEmpty(ambs); ambs=ATgetNext(ambs)) {
      if((res = SG_ExpandApplNode(pt, (forest) ATgetFirst(ambs),
                                  recurse, ATfalse))) {
        trms = ATinsert(trms, (ATerm) res);
      } else IF_DEBUG(
        RemovedSome = ATtrue;
        fprintf(SGlog(), "Removing term from ambiguity cluster\n");
      )
    }
    if(ATisEmpty(trms))
      return NULL;
    if (ATgetLength(trms) == 1)
      trms = ATreverse(trms);

    if (ATgetLength(trms) == 1) {
      /*  Only one left: ambiguity resolved  */
      IF_DEBUG(if(RemovedSome) fprintf(SGlog(), "Resolved entire ambiguity\n"))
      res = (forest) ATgetFirst(trms);
    } else {
      /*  Multiple terms left: this is truly an ambiguous node  */
      SGnrAmb(SG_NRAMB_INC);
      res = (forest) ATmakeAppl1(SG_Amb_AFun, (ATerm) trms);
    }
  }

  if(pos_info)
    res = SG_SetPosInfoLabel(res, pos_info);
  return res;
}

forest SG_YieldPT(parse_table *pt, forest t)
{
  forest    elt, res;
  ATermList args, l;

  if(!t)
    return NULL;

  switch(ATgetType(t)) {
    case AT_APPL:
      res = SG_ExpandApplNode(pt, t, ATtrue, ATtrue);
      return res;
    case AT_LIST:
      if(ATisEmpty((ATermList) t))
        return (forest) ATempty;
      for(l = ATempty, args = (ATermList) t;
          !ATisEmpty(args); args = ATgetNext(args)) {
        elt = (forest) ATgetFirst(args);
        if(!(res = SG_YieldPT(pt, elt))) {
          return NULL;
        }
        l = ATinsert(l, (ATerm) res);
      }
      return (forest) ATreverse(l);
    case AT_INT:
    case AT_REAL:
    case AT_PLACEHOLDER:
    case AT_BLOB:
    default:
      return t;
  }
}

/*
  Ambiguity Tables provide a mapping from terms to sets of terms,
  reflecting the ambiguity relation.  Note that terms can be
  `prioritized out' or rejected, so that the mapping may or may not
  yield a set containing the key term.

  The implementation consists of a two-level mapping, as follows:

  * a mapping from terms to indexes (of ambiguity clusters)
  * a mapping from indexes to sets of terms (the ambiguity cluster)

  Maintenance is relatively simple: for new ambiguity clusters, simply
  create.  Updates to existing ambiguity clusters can be performed
  simply by looking up the index from one of the terms that share the
  ambiguity, and update the ambiguity cluster that is found as desired.
 */

ATerm SG_AmbTable(int Mode, ATerm key, ATerm value)
{
  static  ATermTable  ambtbl = NULL;
  ATerm               ret = (ATerm) ATempty, idx = NULL;

  switch(Mode) {
    case SG_AMBTBL_GET:
      if((idx = SG_AmbTable(SG_AMBTBL_LOOKUP_INDEX, key, NULL)))
        ret = SG_AmbTable(SG_AMBTBL_LOOKUP_CLUSTER, idx, NULL);
      break;
    case SG_AMBTBL_INIT:
      if(ambtbl)
        SG_AmbTable(SG_AMBTBL_CLEAR, NULL, NULL);
      ambtbl = ATtableCreate(2048, 75);
      break;
    case SG_AMBTBL_CLEAR:
      if(ambtbl) {
        ATtableDestroy(ambtbl);
        ambtbl = NULL;
      }
      break;
    case SG_AMBTBL_ADD_INDEX:
    case SG_AMBTBL_ADD_CLUSTER:
    case SG_AMBTBL_UPDATE_INDEX:
    case SG_AMBTBL_UPDATE_CLUSTER:
      if(!ambtbl)
        SG_AmbTable(SG_AMBTBL_INIT, NULL, NULL);
      ATtablePut(ambtbl, key, value);
      break;
    case SG_AMBTBL_REMOVE:
      if(!ambtbl)
        break;
      if((idx = SG_AmbTable(SG_AMBTBL_LOOKUP_INDEX, key, NULL))) {
        ATtableRemove(ambtbl, key);
        if(!ATisEmpty((ATermList) SG_AmbTable(SG_AMBTBL_LOOKUP_CLUSTER,
                                              idx, NULL)))
          ATtableRemove(ambtbl, idx);
      }
      break;
    case SG_AMBTBL_LOOKUP_INDEX:
    case SG_AMBTBL_LOOKUP_CLUSTER:
      if(!ambtbl)
        return (ATerm) ATempty;
      ret = ATtableGet(ambtbl, key);
      ret=ret?ret:(ATerm) ATempty;
      break;
#ifdef DEBUG
    case SG_AMBTBL_DUMP:
      if(ambtbl) SG_Dump_ATtable(ambtbl, "Ambs");
      break;
#endif
  }
  return ret;
}

label SG_GetProdLabel(tree aprod)
{
  return ATgetInt((ATermInt) ATgetArgument(aprod, 0));
}

label SG_GetApplProdLabel(tree appl)
{
  return SG_GetProdLabel((tree) ATgetArgument(appl, 0));
}

label SG_GetRejectProdLabel(tree appl)
{
  return SG_GetProdLabel((tree) ATgetArgument(appl, 0));
}

/*
  SG_MaxPriority returns
    * lbl0,  if priority(lbl0) > priority(lbl1)
    * lbl1,  if priority(lbl1) > priority(lbl0)
    * NULL,  if there is no priority relation between lbl0 and lbl1
 */

ATbool SG_GtrPriority(parse_table *pt, ATermInt lt0, ATermInt lt1)
{
  ATermList prios;

  if((prios = SG_LookupPriority(pt, ATgetInt(lt0)))
  && (ATindexOf(prios, (ATerm) lt1, 0) != -1))
    return ATtrue;
  return ATfalse;
}

multiset SG_NewMultiSet(int size)
{
#ifdef MSISDICT
  return (multiset) ATdictCreate();
#else
  return ATtableCreate(size, 75); 
#endif
}

multiset SG_PutMultiSetEntry(multiset ms, ATermInt pl, ATermInt cnt)
{
#ifdef MSISDICT
  ATermList newms = ATempty, curentry, newentry;
  int       dist;

  newentry = ATmakeList2((ATerm) pl, (ATerm) cnt);

  /*  insert in ascending order  */
  for(; !ATisEmpty((ATermList) ms); ms=(multiset) ATgetNext((ATermList) ms)) {
    curentry = (ATermList) ATgetFirst((ATermList) ms);
    dist = ATgetInt((ATermInt) ATgetFirst(curentry)) - ATgetInt(pl);
    if(dist <= 0)   /*  inserting at or before current entry  */
      newms = ATreverse(newms);
    if(dist == 0)   /*  at current entry, replace it  */
      return (multiset) ATconcat(newms,
                                 ATinsert(ATgetNext((ATermList) ms),
                                          (ATerm) newentry));
    if(dist < 0)    /*  insert before current entry  */
      return (multiset) ATconcat(newms,
                                 ATinsert((ATermList) ms, (ATerm) newentry));
    /*  dist > 0  */
    /*
       Insert constructs a list in reversed order, but appending
       the new items is a linear operation -- costly.  Let's reverse
       it back in shape when using it.
     */
    newms = ATinsert(newms, (ATerm) curentry);
  }
  return (multiset) ATreverse(ATinsert(newms, (ATerm) newentry));
#else
  ATtablePut(ms, (ATerm) pl, (ATerm) cnt);
  return ms;
#endif
}

int SG_GetMultiSetEntry(multiset ms, ATermInt pl)
{
  ATermInt val = NULL;

#ifdef MSISDICT
  ATermList curentry;

  for(; !val && !ATisEmpty((ATermList) ms);
      ms = (multiset) ATgetNext((ATermList) ms)) {
    curentry = (ATermList) ATgetFirst((ATermList) ms);
    if(ATisEqual(pl, ATelementAt(curentry, 0)))
      val = (ATermInt) ATelementAt(curentry, 1);
  }
#else
  val = (ATermInt) ATtableGet(ms, (ATerm) pl);
#endif
  return val ? ATgetInt(val) : 0;
}

ATermList SG_GetMultiSetKeys(multiset ms)
{
#ifdef MSISDICT
  /*  Never called, but what the heck...  */
  ATermList keys = ATempty;

  for(; !ATisEmpty((ATermList) ms);  ms = (multiset)ATgetNext((ATermList) ms)) {
    keys = ATinsert(keys,ATelementAt((ATermList)ATgetFirst((ATermList) ms), 0));
  }
  return keys;
#else
  return ATtableKeys(ms);
#endif
}

multiset SG_GetMultiSet(tree t, multiset ms)
{
  label    l;
  int      count;

  switch(ATgetType(t)) {
    case AT_APPL:
      l = SG_GetApplProdLabel(t);
      count = 1 + SG_GetMultiSetEntry(ms, SG_GetATint(l, 0));
      ms = SG_PutMultiSetEntry(ms, SG_GetATint(l,0), SG_GetATint(count, 0));
      ms = SG_GetMultiSet((tree) ATgetArgument((ATermAppl) t, 1), ms);
      break;
    case AT_LIST:
      if(ATisEmpty((ATermList) t))
        break;
      for(; !ATisEmpty((ATermList) t); t = (tree) ATgetNext((ATermList) t))
        ms = SG_GetMultiSet((tree) ATgetFirst((ATermList) t), ms);
      break;
    case AT_INT:
    case AT_REAL:
    case AT_PLACEHOLDER:
    case AT_BLOB:
    default:
      break;
  }
  return ms;
}

ATbool SG_MultiSetGtr(parse_table *pt, multiset msM, ATermList kM,
                      multiset msN, ATermList kN)
{
  ATermInt  x, y;
  ATermList M, N, RestrictedM = ATempty;
  ATbool    foundone;

#ifdef MSISDICT
  ATermList N2, curM, curN;

  /*  multi-prio is irreflexive  */
/*
  if(SG_MultiSetEqual(multiset1, multiset2, NULL, NULL))
    return NULL;
 */

  /*
     Construct restriction:
      { x in M | Exists y in N: M(x) > N(x) /\ x gtr-prio y}
   */
  for(M = msM; !ATisEmpty(M); M = ATgetNext(M)) {
    curM = (ATermList) ATgetFirst(M);
    x = (ATermInt) ATelementAt(curM, 0);
    foundone = ATfalse;
    for(N = msN; !(foundone||ATisEmpty(N)); N = ATgetNext(N)) {
      curN = (ATermList) ATgetFirst(N);
      y = (ATermInt) ATelementAt(curN, 0);
      if( ATgetInt((ATermInt) ATelementAt(curM, 1)) >
          ATgetInt((ATermInt) ATelementAt(curN, 1))
      && SG_GtrPriority(pt, x, y)) {
        RestrictedM = ATinsert(RestrictedM, (ATerm) x);
        foundone = ATtrue;
      }
    }
  }

  if(ATisEmpty(RestrictedM)) {
    return ATfalse;
  }
  RestrictedM = ATreverse(RestrictedM);

  for(M = RestrictedM, N=msN; M && !ATisEmpty(M); M = ATgetNext(M)) {
    y = (ATermInt) ATgetFirst(M);
    /*  Skip items in msM up to y  */
    for(; !ATisEmpty(msM)
           && ATgetInt(y) >
              ATgetInt((ATermInt) ATelementAt((ATermList) ATgetFirst(msM), 0));
        msM = ATgetNext(msM));
    /*  Skip items in msN up to y  */
    for(; !ATisEmpty(N)
           && ATgetInt(y) >
              ATgetInt((ATermInt) ATelementAt((ATermList) ATgetFirst(N), 0));
        N = ATgetNext(N));
    if((curM = (ATermList) ATgetFirst(msM))
    &&  ATisEqual(y, ATelementAt(curM, 0))) {
      if(!(curN = (ATermList) ATgetFirst(N))
      || !ATisEqual(y, ATelementAt(curN, 0))
      ||  ATgetInt((ATermInt) ATelementAt(curM, 1)) <
          ATgetInt((ATermInt) ATelementAt(curN, 1))) {
        foundone = ATfalse;
        /*  Check all msN items in this case.. */
        for(N2 = msN; !(foundone||ATisEmpty(N2)); N2 = ATgetNext(N2)) {
          curN = (ATermList) ATgetFirst(N2);
          x = (ATermInt) ATelementAt(curN, 0);

          if( ATgetInt((ATermInt) ATelementAt(curM, 1)) <
              ATgetInt((ATermInt) ATelementAt(curN, 1))
          && SG_GtrPriority(pt, y, x)) {
            foundone = ATtrue;
          }
        }
        if(!foundone) {
          return ATfalse;
        }
      }
    }
  }
#else
  /*  Initialize key lists if we have to  */
  if(!kM)
    kM = SG_GetMultiSetKeys (msM);
  if(!kN)
    kN = SG_GetMultiSetKeys (msN);

  /*  multi-prio is irreflexive  */
/*
  if(SG_MultiSetEqual(multiset1, multiset2, NULL, NULL))
    return NULL;
 */

  /*
     Construct restriction:
      { x in M | Exists y in N: M(x) > N(x) /\ x gtr-prio y}
   */
  for(M = kM; !ATisEmpty(M); M = ATgetNext(M)) {
    x = (ATermInt) ATgetFirst(M);
    foundone = ATfalse;
    for(N = kN; !(foundone||ATisEmpty(N)); N = ATgetNext(N)) {
      y = (ATermInt) ATgetFirst(N);
      if(SG_GetMultiSetEntry(msM, x) > SG_GetMultiSetEntry(msN, x)
      && SG_GtrPriority(pt, x, y)) {
        RestrictedM = ATinsert(RestrictedM, (ATerm) x);
        foundone = ATtrue;
      }
    }
  }

  if(ATisEmpty(RestrictedM)) {
    return ATfalse;
  }

  for(M = RestrictedM; M && !ATisEmpty(M); M = ATgetNext(M)) {
    y = (ATermInt) ATgetFirst(M);
    if(SG_GetMultiSetEntry(msM, y) > SG_GetMultiSetEntry(msN, y)) {
      foundone = ATfalse;
      for(N = kN; !(foundone||ATisEmpty(N)); N = ATgetNext(N)) {
        x = (ATermInt) ATgetFirst(N);
        if(SG_GetMultiSetEntry(msM, x) < SG_GetMultiSetEntry(msN, x)
        && SG_GtrPriority(pt, y, x)) {
          foundone = ATtrue;
        }
      }
      if(!foundone) {
        return ATfalse;
      }
    }
  }
#endif

  return ATtrue;
}


ATbool ATsubTable(ATermTable t1, ATermTable t2, ATermList k1)
{
  ATerm     key;
  ATermList keys;

  if(!t2)
    return ATfalse;
  if(!t1)
    return ATtrue;

  /*  Initialise list of keys unless already available  */
  if(!k1)
    k1 = ATtableKeys(t1);

  /*  Now check if all the keys in t1 exist in t2, with equal values  */
  for(keys = k1; keys && !ATisEmpty(keys);
            keys=ATgetNext(keys)) {
    key = ATgetFirst(keys);
    if(!ATisEqual(ATtableGet(t1, key), ATtableGet(t2, key)))
      return ATfalse;
  }
  return ATtrue;
}

ATbool ATtableIsEqual(ATermTable t1, ATermTable t2, ATermList k1, ATermList k2)
{
  if(t1 == t2)
    return ATtrue;

  if(!t1 || !t2)
    return ATfalse;

  if(!k1)
    k1 = ATtableKeys(t1);
  if(!k2)
    k2 = ATtableKeys(t2);

  if(!ATisEqual(k1, k2))
    return ATfalse;

  if(!ATsubTable(t1, t2, k1))
    return ATfalse;

  if(!ATsubTable(t2, t1, k2))
    return ATfalse;

  return ATtrue;
}

ATbool SG_MultiSetEqual(multiset M1, multiset M2, ATermList k1, ATermList k2)
{
#ifdef MSISDICT
  return ATisEqual(M1, M2);
#else
  return ATtableIsEqual(M1, M2, k1, k2);
#endif
}

int SG_CountInjections(parse_table *pt, multiset ms, ATermList keys)
{
  int       ret = 0;

#ifdef MSISDICT
  ATermList curentry;

  for(; !ATisEmpty((ATermList) ms);  ms = (multiset)ATgetNext((ATermList) ms)) {
    curentry = (ATermList) ATgetFirst((ATermList) ms);
    if(SG_ProdIsInjection(pt, ATgetInt((ATermInt) ATelementAt(curentry, 0)))) {
      ret += ATgetInt((ATermInt) ATelementAt(curentry, 1));
    }
  }
#else
  ATermInt  key;

  if(!keys)
    keys = SG_GetMultiSetKeys (ms);

  for(; keys && !ATisEmpty(keys); keys=ATgetNext(keys)) {
    key = (ATermInt) ATgetFirst(keys);
    if(SG_ProdIsInjection(pt, ATgetInt((ATermInt) key))) {
      ret += ATgetInt((ATermInt) ATtableGet(ms, (ATerm) key));
    }
  }
#endif

  return ret;
}

/*
  SG_Filter -- a generic hook to add disambiguating `filters'

  Arguments:  the current parse table
              two terms
  Returns:    the preferred term of the two, or NULL if there is no
              filter that prefers either one of them
 */

tree SG_Filter(parse_table *pt, tree t0, tree t1, multiset m0, ATermList k0)
{
  ATermInt   l0, l1;
  multiset   m1;
  tree       max = NULL;
  ATermList  k1;
  ATbool     m0made = ATfalse;

  /*  Always apply direct priority filtering first  */
  l0 = SG_GetATint(SG_GetApplProdLabel(t0), 0);
  l1 = SG_GetATint(SG_GetApplProdLabel(t1), 0);

  if(SG_GtrPriority(pt, l0, l1)) {
    IF_DEBUG(ATfprintf(SGlog(), "Direct Priority: %t > %t\n", l0, l1))
    return t0;
  }
  if(SG_GtrPriority(pt, l1, l0)) {
    IF_DEBUG(ATfprintf(SGlog(), "Direct Priority: %t < %t\n", l0, l1))
    return t1;
  }

  /*  Don't even bother filtering any further if filtering is disabled  */
  if(!SG_FILTER)
    return NULL;

  /*  Don't filter START symbols when start symbol subselection is on  */
  if(SG_STARTSYMBOL && SG_StartInjection(pt, ATgetInt(l0)))
    return (tree) NULL;

  /*  No direct priority relation?  Apply multiset ordering.  */
  if(!m0) {
    m0made = ATtrue;
    m0 = SG_GetMultiSet(t0, SG_NewMultiSet(SG_PT_NUMPRODS(pt)));
  }
  m1 = SG_GetMultiSet(t1, SG_NewMultiSet(SG_PT_NUMPRODS(pt)));

#ifdef MSISDICT
  k0 = k1 = ATempty;
#else
  if(!k0)
    k0 = SG_GetMultiSetKeys(m0);
  k1 = SG_GetMultiSetKeys(m1);
#endif

  if(!ATisEqual(t0, t1) && !SG_MultiSetEqual(m0, m1, k0, k1)) {
                                            /*  multi-prio is irreflexive  */
    if(SG_MultiSetGtr(pt, m0, k0, m1, k1)) {
      IF_DEBUG(ATfprintf(SGlog(), "Multiset Priority: %t > %t\n", l0, l1))
      max = t0;
    }
    if(SG_MultiSetGtr(pt, m1, k1, m0, k0)) {
      if(max) {                             /*  shouldn't happen, really  */
        IF_DEBUG(fprintf(SGlog(),
                         "Ignoring symmetric multiset priority relation\n"))
        ATwarning("Ignoring symmetric multiset priority relation\n");
        max = NULL;
      } else {
        IF_DEBUG(ATfprintf(SGlog(), "Multiset Priority: %t < %t\n", l0, l1))
        max = t1;
      }
    }
  }

  /*  No multiset ordering either?  Count injections.  */
  if(!max) {
    int in0, in1;

#ifdef KEEPINJECTCOUNT
    in0 = SG_GetInjections(t0);
    in1 =SG_GetInjections(t1);
#else
    in0 = SG_CountInjections(pt, m0, k0);
    in1 = SG_CountInjections(pt, m1, k1);
#endif
    if(in0 > in1) {
      IF_DEBUG(ATfprintf(SGlog(), "Injection Priority: %t < %t (%d > %d)\n",
                         l0, l1, in0, in1))
      max = t1;
    } else if(in0 < in1) {
      IF_DEBUG(ATfprintf(SGlog(), "Injection Priority: %t > %t (%d < %d)\n",
                         l0, l1, in0, in1))
      max = t0;
    }
  }

#ifndef MSISDICT
  if(m0made)
    ATtableDestroy(m0);
  ATtableDestroy(m1);
#endif

  return max;
}

ATermList SG_FilterList(parse_table *pt, ATermList old, tree t)
{
  multiset   m = NULL;
  ATermList  k = ATempty, new = ATempty;
  tree       prev, max;
  ATbool     term_filtered_out = ATfalse;

  if(ATisEmpty(old))
    return ATmakeList1((ATerm) t);

  /*  Multiset construction is needed only when really filtering  */
  if(SG_FILTER) {
    m = SG_GetMultiSet(t, SG_NewMultiSet(SG_PT_NUMPRODS(pt)));
#ifndef MSISDICT
    k = SG_GetMultiSetKeys(m);
#endif
  }

  /*  Filter term against existing terms in ambiguity cluster  */
  for(; !ATisEmpty(old); old = ATgetNext(old)) {
    prev = (tree) ATgetFirst(old);

    /* Add prev to new, unless new has a higher priority  */
    max = SG_Filter(pt, t, prev, m, k);
    if(!max || (term_filtered_out=ATisEqual(max, prev)))
      new = ATinsert(new, (ATerm) prev);
    if(max)
      IF_DEBUG(
        fprintf(SGlog(), "Priority: %d %c %d (old amb)\n",
                SG_GetApplProdLabel(prev),
                ATisEqual(max, prev)?'>':'<',
                SG_GetApplProdLabel(t))
      )
  }
  if(!term_filtered_out)
    new = ATinsert(new, (ATerm) t);

#ifndef MSISDICT
  if(m)
    ATtableDestroy(m);
#endif

  return new;
}

/*
  |SG_Amb| maintans the ambiguity table, needed for the mapping from
  terms to ambiguity clusters.  On a new ambiguity, it makes a new
  entry; existing ambiguities get expanded, applying filtering wherever
  applicable.
*/

void SG_Amb(parse_table *pt, tree existing, tree new) {
  ATermList newambs;
  ATerm     ambidx;
  tree      max;
  
  SG_AmbCalls(SG_NRAMB_INC);

  if(!SG_NEED_TOP) {
    SG_MaxNrAmb(SG_NRAMB_INC);
    return;
  }

  ambidx = SG_AmbTable(SG_AMBTBL_LOOKUP_INDEX, (ATerm) existing, NULL);
  if(!ambidx || ATisEmpty((ATermList) ambidx)) {
    /* New ambiguity */
    ambidx = (ATerm) ATmakeInt(SG_MaxNrAmb(SG_NRAMB_INC));
    /* Add mapping for existing term also */
    SG_AmbTable(SG_AMBTBL_ADD_INDEX, (ATerm) existing, ambidx);

    /*  Filter the two  */
    if(!(max = SG_Filter(pt, new, existing, NULL, NULL))) {
      /*  max and new are not priority-related */
      newambs = ATmakeList2((ATerm) existing, (ATerm) new);
    } else {
      /*  new and existing are in a priority relation, max is top  */
      newambs = ATmakeList1((ATerm) max);
      if(max)
        IF_DEBUG(
          fprintf(SGlog(), "Priority: %d %c %d (new amb)\n",
                  SG_GetApplProdLabel(existing),
                  ATisEqual(max, existing)?'>':'<',
                  SG_GetApplProdLabel(new))
        )
    }
  } else {
    /* Expand (or update) existing ambiguity */
    ATermList oldambs;

    oldambs = (ATermList) SG_AmbTable(SG_AMBTBL_LOOKUP_CLUSTER, ambidx, NULL);
    if(ATindexOf(oldambs, (ATerm) new, 0) != -1)
      return;  /*  Already present?  Done.  */
    newambs = SG_FilterList(pt, oldambs, new);
  }

  /*   Update ambiguity cluster  */
  SG_AmbTable(SG_AMBTBL_ADD_INDEX, (ATerm) new, ambidx);
  SG_AmbTable(SG_AMBTBL_UPDATE_CLUSTER, ambidx, (ATerm) newambs);

  return;
}
