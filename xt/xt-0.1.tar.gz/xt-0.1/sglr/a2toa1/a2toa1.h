/* $Id: a2toa1.h,v 1.2 1999/10/11 14:19:16 js Exp $ */

ATerm a2toa1(ATerm t, ATbool interp_cons);

