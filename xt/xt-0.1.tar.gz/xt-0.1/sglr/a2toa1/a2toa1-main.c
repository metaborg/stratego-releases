/*
  Program: a2toa1 main
  Authors: Eelco Visser, Tobias Kuipers, Mark van den Brand,
           and Jeroen Scheerder
  date:    July 1998
  CVS:     $Id: a2toa1-main.c,v 1.4 1999/10/11 14:19:16 js Exp $
*/

#include <stdlib.h>
#include <string.h>

#include <aterm2.h>
#include <AsFix.h>

#include "a2toa1.h"

#ifndef WIN32  /*  Not available for DOS  */
  #include <atb-tool.h>
  #include "a2toa1.tif.h"
  #include "a2toa1.tif.c"
#endif


int main(int argc, char **argv)
{
  int i;
  ATbool use_toolbus = ATfalse, text_out = ATfalse, interpret_cons = ATfalse;
  ATerm bottomOfStack, translatedTerm;

  for(i=1; i<argc; i++) {
    if(!strcmp(argv[i], "-TB_TOOL_NAME")) {
      use_toolbus = ATtrue;
    } else if(!strcmp(argv[i], "-t")) {
      text_out = ATtrue;
    } else if(!strcmp(argv[i], "-c")) {
      interpret_cons = ATtrue;
    }
  }

  if(use_toolbus) {
#ifndef WIN32
    int cid;

    ATBinit(argc, argv, &bottomOfStack);    /* Initialize Aterm library */
    cid = ATBconnect(NULL, NULL, -1, a2toa1_handler);
    ATBeventloop();                         /* Never returns            */
#else
    fprintf(stderr, "%s: platform lacks ToolBus functionality\n", argv[0]);
    return -1;
#endif
  }

  AFinit(argc, argv, &bottomOfStack);       /* Initialize Aterm library */
  translatedTerm = a2toa1(ATreadFromFile(stdin), interpret_cons);
  if(text_out)
    ATwriteToTextFile(translatedTerm, stdout);
  else
    ATwriteToBinaryFile(translatedTerm,stdout);

  return 0;
}


void rec_terminate(int cid, ATerm t) {
  exit(0);
}
