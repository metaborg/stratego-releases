#include  "asc-support.h"
static Symbol lf_AUX_AsFix_Syntax1_1sym ;
static ATerm lf_AUX_AsFix_Syntax1_1 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_2sym ;
static ATerm lf_AUX_AsFix_Syntax1_2 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_3sym ;
static ATerm lf_AUX_AsFix_Syntax1_3 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_4sym ;
static ATerm lf_AUX_AsFix_Syntax1_4 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_5sym ;
static ATerm lf_AUX_AsFix_Syntax1_5 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_6sym ;
static ATerm lf_AUX_AsFix_Syntax1_6 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_7sym ;
static ATerm lf_AUX_AsFix_Syntax1_7 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_8sym ;
static ATerm lf_AUX_AsFix_Syntax1_8 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_9sym ;
static ATerm lf_AUX_AsFix_Syntax1_9 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_10sym ;
static ATerm lf_AUX_AsFix_Syntax1_10 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_11sym ;
static ATerm lf_AUX_AsFix_Syntax1_11 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_12sym ;
static ATerm lf_AUX_AsFix_Syntax1_12 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_13sym ;
static ATerm lf_AUX_AsFix_Syntax1_13 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_14sym ;
static ATerm lf_AUX_AsFix_Syntax1_14 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_15sym ;
static ATerm lf_AUX_AsFix_Syntax1_15 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_16sym ;
static ATerm lf_AUX_AsFix_Syntax1_16 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_17sym ;
static ATerm lf_AUX_AsFix_Syntax1_17 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_18sym ;
static ATerm lf_AUX_AsFix_Syntax1_18 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_19sym ;
static ATerm lf_AUX_AsFix_Syntax1_19 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_20sym ;
static ATerm lf_AUX_AsFix_Syntax1_20 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_21sym ;
static ATerm lf_AUX_AsFix_Syntax1_21 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_22sym ;
static ATerm lf_AUX_AsFix_Syntax1_22 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_23sym ;
static ATerm lf_AUX_AsFix_Syntax1_23 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_24sym ;
static ATerm lf_AUX_AsFix_Syntax1_24 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_25sym ;
static ATerm lf_AUX_AsFix_Syntax1_25 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_26sym ;
static ATerm lf_AUX_AsFix_Syntax1_26 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_27sym ;
static ATerm lf_AUX_AsFix_Syntax1_27 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_28sym ;
static ATerm lf_AUX_AsFix_Syntax1_28 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_29sym ;
static ATerm lf_AUX_AsFix_Syntax1_29 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_30sym ;
static ATerm lf_AUX_AsFix_Syntax1_30 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_31sym ;
static ATerm lf_AUX_AsFix_Syntax1_31 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_32sym ;
static ATerm lf_AUX_AsFix_Syntax1_32 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_33sym ;
static ATerm lf_AUX_AsFix_Syntax1_33 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_34sym ;
static ATerm lf_AUX_AsFix_Syntax1_34 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_35sym ;
static ATerm lf_AUX_AsFix_Syntax1_35 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_36sym ;
static ATerm lf_AUX_AsFix_Syntax1_36 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_37sym ;
static ATerm lf_AUX_AsFix_Syntax1_37 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_38sym ;
static ATerm lf_AUX_AsFix_Syntax1_38 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_39sym ;
static ATerm lf_AUX_AsFix_Syntax1_39 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_40sym ;
static ATerm lf_AUX_AsFix_Syntax1_40 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_41sym ;
static ATerm lf_AUX_AsFix_Syntax1_41 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_42sym ;
static ATerm lf_AUX_AsFix_Syntax1_42 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_43sym ;
static ATerm lf_AUX_AsFix_Syntax1_43 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_44sym ;
static ATerm lf_AUX_AsFix_Syntax1_44 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_45sym ;
static ATerm lf_AUX_AsFix_Syntax1_45 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_46sym ;
static ATerm lf_AUX_AsFix_Syntax1_46 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_47sym ;
static ATerm lf_AUX_AsFix_Syntax1_47 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_48sym ;
static ATerm lf_AUX_AsFix_Syntax1_48 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_49sym ;
static ATerm lf_AUX_AsFix_Syntax1_49 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_50sym ;
static ATerm lf_AUX_AsFix_Syntax1_50 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_51sym ;
static ATerm lf_AUX_AsFix_Syntax1_51 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_52sym ;
static ATerm lf_AUX_AsFix_Syntax1_52 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_53sym ;
static ATerm lf_AUX_AsFix_Syntax1_53 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_54sym ;
static ATerm lf_AUX_AsFix_Syntax1_54 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_55sym ;
static ATerm lf_AUX_AsFix_Syntax1_55 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_56sym ;
static ATerm lf_AUX_AsFix_Syntax1_56 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_57sym ;
static ATerm lf_AUX_AsFix_Syntax1_57 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_58sym ;
static ATerm lf_AUX_AsFix_Syntax1_58 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_59sym ;
static ATerm lf_AUX_AsFix_Syntax1_59 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_60sym ;
static ATerm lf_AUX_AsFix_Syntax1_60 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_61sym ;
static ATerm lf_AUX_AsFix_Syntax1_61 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_62sym ;
static ATerm lf_AUX_AsFix_Syntax1_62 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_63sym ;
static ATerm lf_AUX_AsFix_Syntax1_63 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_64sym ;
static ATerm lf_AUX_AsFix_Syntax1_64 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_65sym ;
static ATerm lf_AUX_AsFix_Syntax1_65 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_66sym ;
static ATerm lf_AUX_AsFix_Syntax1_66 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_67sym ;
static ATerm lf_AUX_AsFix_Syntax1_67 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_68sym ;
static ATerm lf_AUX_AsFix_Syntax1_68 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_69sym ;
static ATerm lf_AUX_AsFix_Syntax1_69 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_70sym ;
static ATerm lf_AUX_AsFix_Syntax1_70 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_71sym ;
static ATerm lf_AUX_AsFix_Syntax1_71 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_72sym ;
static ATerm lf_AUX_AsFix_Syntax1_72 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_73sym ;
static ATerm lf_AUX_AsFix_Syntax1_73 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_74sym ;
static ATerm lf_AUX_AsFix_Syntax1_74 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_75sym ;
static ATerm lf_AUX_AsFix_Syntax1_75 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_76sym ;
static ATerm lf_AUX_AsFix_Syntax1_76 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_77sym ;
static ATerm lf_AUX_AsFix_Syntax1_77 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_78sym ;
static ATerm lf_AUX_AsFix_Syntax1_78 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_79sym ;
static ATerm lf_AUX_AsFix_Syntax1_79 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_80sym ;
static ATerm lf_AUX_AsFix_Syntax1_80 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_81sym ;
static ATerm lf_AUX_AsFix_Syntax1_81 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_82sym ;
static ATerm lf_AUX_AsFix_Syntax1_82 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_83sym ;
static ATerm lf_AUX_AsFix_Syntax1_83 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_84sym ;
static ATerm lf_AUX_AsFix_Syntax1_84 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_85sym ;
static ATerm lf_AUX_AsFix_Syntax1_85 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_86sym ;
static ATerm lf_AUX_AsFix_Syntax1_86 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_87sym ;
static ATerm lf_AUX_AsFix_Syntax1_87 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_88sym ;
static ATerm lf_AUX_AsFix_Syntax1_88 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_89sym ;
static ATerm lf_AUX_AsFix_Syntax1_89 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_90sym ;
static ATerm lf_AUX_AsFix_Syntax1_90 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_91sym ;
static ATerm lf_AUX_AsFix_Syntax1_91 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_92sym ;
static ATerm lf_AUX_AsFix_Syntax1_92 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_93sym ;
static ATerm lf_AUX_AsFix_Syntax1_93 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_94sym ;
static ATerm lf_AUX_AsFix_Syntax1_94 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_95sym ;
static ATerm lf_AUX_AsFix_Syntax1_95 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_96sym ;
static ATerm lf_AUX_AsFix_Syntax1_96 ( ) ;
static Symbol lf_AUX_AsFix_Syntax1_97sym ;
static ATerm lf_AUX_AsFix_Syntax1_97 ( ) ;
void register_AUX_AsFix_Syntax1 ( ) {
lf_AUX_AsFix_Syntax1_1sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"abbrevs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))"
 , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_1sym ) ;
lf_AUX_AsFix_Syntax1_2sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"no-abbreviations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_2sym ) ;
lf_AUX_AsFix_Syntax1_3sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Abbreviations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_3sym ) ;
lf_AUX_AsFix_Syntax1_4sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"abbreviations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_4sym ) ;
lf_AUX_AsFix_Syntax1_5sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"agroup\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_5sym ) ;
lf_AUX_AsFix_Syntax1_6sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"appl\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_6sym ) ;
lf_AUX_AsFix_Syntax1_7sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"aprod\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_7sym ) ;
lf_AUX_AsFix_Syntax1_8sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"args\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_8sym ) ;
lf_AUX_AsFix_Syntax1_9sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"AsFix\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_9sym ) ;
lf_AUX_AsFix_Syntax1_10sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"asfix\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_10sym ) ;
lf_AUX_AsFix_Syntax1_11sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"AsFixTerm\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_11sym ) ;
lf_AUX_AsFix_Syntax1_12sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Assoc\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_12sym ) ;
lf_AUX_AsFix_Syntax1_13sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"assoc\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_13sym ) ;
lf_AUX_AsFix_Syntax1_14sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Attribute\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_14sym ) ;
lf_AUX_AsFix_Syntax1_15sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Attributes\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_15sym ) ;
lf_AUX_AsFix_Syntax1_16sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"attr\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_16sym ) ;
lf_AUX_AsFix_Syntax1_17sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"attrs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_17sym ) ;
lf_AUX_AsFix_Syntax1_18sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ceq-equ\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_18sym ) ;
lf_AUX_AsFix_Syntax1_19sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ceq-impl\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_19sym ) ;
lf_AUX_AsFix_Syntax1_20sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ceq-when\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_20sym ) ;
lf_AUX_AsFix_Syntax1_21sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"CharClass\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_21sym ) ;
lf_AUX_AsFix_Syntax1_22sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"char-class\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_22sym ) ;
lf_AUX_AsFix_Syntax1_23sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"chars\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_23sym ) ;
lf_AUX_AsFix_Syntax1_24sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"CondEquation\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_24sym ) ;
lf_AUX_AsFix_Syntax1_25sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"cond-equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_25sym ) ;
lf_AUX_AsFix_Syntax1_26sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Condition\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_26sym ) ;
lf_AUX_AsFix_Syntax1_27sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"condition\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_27sym ) ;
lf_AUX_AsFix_Syntax1_28sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"conditions\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_28sym ) ;
lf_AUX_AsFix_Syntax1_29sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"context-free-syntax\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_29sym ) ;
lf_AUX_AsFix_Syntax1_30sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"cop\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_30sym ) ;
lf_AUX_AsFix_Syntax1_31sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"decr-chain\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_31sym ) ;
lf_AUX_AsFix_Syntax1_32sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"elems\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_32sym ) ;
lf_AUX_AsFix_Syntax1_33sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_33sym ) ;
lf_AUX_AsFix_Syntax1_34sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_34sym ) ;
lf_AUX_AsFix_Syntax1_35sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"exports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_35sym ) ;
lf_AUX_AsFix_Syntax1_36sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ExtAsFixTerm\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_36sym ) ;
lf_AUX_AsFix_Syntax1_37sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"fun\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_37sym ) ;
lf_AUX_AsFix_Syntax1_38sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Grammar\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_38sym ) ;
lf_AUX_AsFix_Syntax1_39sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"grammars\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_39sym ) ;
lf_AUX_AsFix_Syntax1_40sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Group\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_40sym ) ;
lf_AUX_AsFix_Syntax1_41sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"group\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_41sym ) ;
lf_AUX_AsFix_Syntax1_42sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"groups\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_42sym ) ;
lf_AUX_AsFix_Syntax1_43sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"hiddens\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_43sym ) ;
lf_AUX_AsFix_Syntax1_44sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Id\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_44sym ) ;
lf_AUX_AsFix_Syntax1_45sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"id\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_45sym ) ;
lf_AUX_AsFix_Syntax1_46sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ids\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_46sym ) ;
lf_AUX_AsFix_Syntax1_47sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Imports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_47sym ) ;
lf_AUX_AsFix_Syntax1_48sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"imports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_48sym ) ;
lf_AUX_AsFix_Syntax1_49sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"impl\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_49sym ) ;
lf_AUX_AsFix_Syntax1_50sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"incr-chain\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_50sym ) ;
lf_AUX_AsFix_Syntax1_51sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"label\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_51sym ) ;
lf_AUX_AsFix_Syntax1_52sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"left\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_52sym ) ;
lf_AUX_AsFix_Syntax1_53sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"lex\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_53sym ) ;
lf_AUX_AsFix_Syntax1_54sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"lexical-syntax\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_54sym ) ;
lf_AUX_AsFix_Syntax1_55sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"lhs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_55sym ) ;
lf_AUX_AsFix_Syntax1_56sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Literal\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_56sym ) ;
lf_AUX_AsFix_Syntax1_57sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"modules\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_57sym ) ;
lf_AUX_AsFix_Syntax1_58sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Module\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_58sym ) ;
lf_AUX_AsFix_Syntax1_59sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"module\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_59sym ) ;
lf_AUX_AsFix_Syntax1_60sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"module-name\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_60sym ) ;
lf_AUX_AsFix_Syntax1_61sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"name\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_61sym ) ;
lf_AUX_AsFix_Syntax1_62sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"neg\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_62sym ) ;
lf_AUX_AsFix_Syntax1_63sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"no-attrs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_63sym ) ;
lf_AUX_AsFix_Syntax1_64sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"no-equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_64sym ) ;
lf_AUX_AsFix_Syntax1_65sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"priorities\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_65sym ) ;
lf_AUX_AsFix_Syntax1_66sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Pair\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_66sym ) ;
lf_AUX_AsFix_Syntax1_67sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"pairs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_67sym ) ;
lf_AUX_AsFix_Syntax1_68sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Priority\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_68sym ) ;
lf_AUX_AsFix_Syntax1_69sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prio-assoc\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_69sym ) ;
lf_AUX_AsFix_Syntax1_70sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prod\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_70sym ) ;
lf_AUX_AsFix_Syntax1_71sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prods\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_71sym ) ;
lf_AUX_AsFix_Syntax1_72sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prod-skel\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_72sym ) ;
lf_AUX_AsFix_Syntax1_73sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ProdSkel\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_73sym ) ;
lf_AUX_AsFix_Syntax1_74sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Production\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_74sym ) ;
lf_AUX_AsFix_Syntax1_75sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"productions\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_75sym ) ;
lf_AUX_AsFix_Syntax1_76sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"QLiteral\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_76sym ) ;
lf_AUX_AsFix_Syntax1_77sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ql\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_77sym ) ;
lf_AUX_AsFix_Syntax1_78sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"rhs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_78sym ) ;
lf_AUX_AsFix_Syntax1_79sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"right\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_79sym ) ;
lf_AUX_AsFix_Syntax1_80sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Sort\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_80sym ) ;
lf_AUX_AsFix_Syntax1_81sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"sorts\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_81sym ) ;
lf_AUX_AsFix_Syntax1_82sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Section\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_82sym ) ;
lf_AUX_AsFix_Syntax1_83sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"sections\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_83sym ) ;
lf_AUX_AsFix_Syntax1_84sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Separator\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_84sym ) ;
lf_AUX_AsFix_Syntax1_85sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"sym\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_85sym ) ;
lf_AUX_AsFix_Syntax1_86sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"syms\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_86sym ) ;
lf_AUX_AsFix_Syntax1_87sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Symbol\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_87sym ) ;
lf_AUX_AsFix_Syntax1_88sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"symbol\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_88sym ) ;
lf_AUX_AsFix_Syntax1_89sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"tag\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_89sym ) ;
lf_AUX_AsFix_Syntax1_90sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"terms\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_90sym ) ;
lf_AUX_AsFix_Syntax1_91sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Term\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_91sym ) ;
lf_AUX_AsFix_Syntax1_92sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"term\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_92sym ) ;
lf_AUX_AsFix_Syntax1_93sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"text\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_93sym ) ;
lf_AUX_AsFix_Syntax1_94sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"uses\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_94sym ) ;
lf_AUX_AsFix_Syntax1_95sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"variables\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_95sym ) ;
lf_AUX_AsFix_Syntax1_96sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"var\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_96sym ) ;
lf_AUX_AsFix_Syntax1_97sym = ATmakeSymbol ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"list\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_AsFix_Syntax1_97sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"abbrevs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_1 , lf_AUX_AsFix_Syntax1_1sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"no-abbreviations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_2 , lf_AUX_AsFix_Syntax1_2sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Abbreviations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_3 , lf_AUX_AsFix_Syntax1_3sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"abbreviations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_4 , lf_AUX_AsFix_Syntax1_4sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"agroup\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_5 , lf_AUX_AsFix_Syntax1_5sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"appl\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_6 , lf_AUX_AsFix_Syntax1_6sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"aprod\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_7 , lf_AUX_AsFix_Syntax1_7sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"args\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_8 , lf_AUX_AsFix_Syntax1_8sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"AsFix\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_9 , lf_AUX_AsFix_Syntax1_9sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"asfix\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_10 , lf_AUX_AsFix_Syntax1_10sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"AsFixTerm\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_11 , lf_AUX_AsFix_Syntax1_11sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Assoc\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_12 , lf_AUX_AsFix_Syntax1_12sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"assoc\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_13 , lf_AUX_AsFix_Syntax1_13sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Attribute\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_14 , lf_AUX_AsFix_Syntax1_14sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Attributes\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_15 , lf_AUX_AsFix_Syntax1_15sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"attr\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_16 , lf_AUX_AsFix_Syntax1_16sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"attrs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_17 , lf_AUX_AsFix_Syntax1_17sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ceq-equ\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_18 , lf_AUX_AsFix_Syntax1_18sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ceq-impl\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_19 , lf_AUX_AsFix_Syntax1_19sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ceq-when\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_20 , lf_AUX_AsFix_Syntax1_20sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"CharClass\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_21 , lf_AUX_AsFix_Syntax1_21sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"char-class\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_22 , lf_AUX_AsFix_Syntax1_22sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"chars\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_23 , lf_AUX_AsFix_Syntax1_23sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"CondEquation\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_24 , lf_AUX_AsFix_Syntax1_24sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"cond-equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_25 , lf_AUX_AsFix_Syntax1_25sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Condition\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_26 , lf_AUX_AsFix_Syntax1_26sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"condition\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_27 , lf_AUX_AsFix_Syntax1_27sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"conditions\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_28 , lf_AUX_AsFix_Syntax1_28sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"context-free-syntax\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_29 , lf_AUX_AsFix_Syntax1_29sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"cop\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_30 , lf_AUX_AsFix_Syntax1_30sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"decr-chain\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_31 , lf_AUX_AsFix_Syntax1_31sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"elems\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_32 , lf_AUX_AsFix_Syntax1_32sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_33 , lf_AUX_AsFix_Syntax1_33sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_34 , lf_AUX_AsFix_Syntax1_34sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"exports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_35 , lf_AUX_AsFix_Syntax1_35sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ExtAsFixTerm\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_36 , lf_AUX_AsFix_Syntax1_36sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"fun\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_37 , lf_AUX_AsFix_Syntax1_37sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Grammar\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_38 , lf_AUX_AsFix_Syntax1_38sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"grammars\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_39 , lf_AUX_AsFix_Syntax1_39sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Group\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_40 , lf_AUX_AsFix_Syntax1_40sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"group\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_41 , lf_AUX_AsFix_Syntax1_41sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"groups\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_42 , lf_AUX_AsFix_Syntax1_42sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"hiddens\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_43 , lf_AUX_AsFix_Syntax1_43sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Id\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_44 , lf_AUX_AsFix_Syntax1_44sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"id\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_45 , lf_AUX_AsFix_Syntax1_45sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ids\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_46 , lf_AUX_AsFix_Syntax1_46sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Imports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_47 , lf_AUX_AsFix_Syntax1_47sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"imports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_48 , lf_AUX_AsFix_Syntax1_48sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"impl\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_49 , lf_AUX_AsFix_Syntax1_49sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"incr-chain\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_50 , lf_AUX_AsFix_Syntax1_50sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"label\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_51 , lf_AUX_AsFix_Syntax1_51sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"left\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_52 , lf_AUX_AsFix_Syntax1_52sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"lex\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_53 , lf_AUX_AsFix_Syntax1_53sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"lexical-syntax\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_54 , lf_AUX_AsFix_Syntax1_54sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"lhs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_55 , lf_AUX_AsFix_Syntax1_55sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Literal\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_56 , lf_AUX_AsFix_Syntax1_56sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"modules\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_57 , lf_AUX_AsFix_Syntax1_57sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Module\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_58 , lf_AUX_AsFix_Syntax1_58sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"module\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_59 , lf_AUX_AsFix_Syntax1_59sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"module-name\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_60 , lf_AUX_AsFix_Syntax1_60sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"name\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_61 , lf_AUX_AsFix_Syntax1_61sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"neg\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_62 , lf_AUX_AsFix_Syntax1_62sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"no-attrs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_63 , lf_AUX_AsFix_Syntax1_63sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"no-equations\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_64 , lf_AUX_AsFix_Syntax1_64sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"priorities\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_65 , lf_AUX_AsFix_Syntax1_65sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Pair\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_66 , lf_AUX_AsFix_Syntax1_66sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"pairs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_67 , lf_AUX_AsFix_Syntax1_67sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Priority\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_68 , lf_AUX_AsFix_Syntax1_68sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prio-assoc\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_69 , lf_AUX_AsFix_Syntax1_69sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prod\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_70 , lf_AUX_AsFix_Syntax1_70sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prods\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_71 , lf_AUX_AsFix_Syntax1_71sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prod-skel\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_72 , lf_AUX_AsFix_Syntax1_72sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ProdSkel\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_73 , lf_AUX_AsFix_Syntax1_73sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Production\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_74 , lf_AUX_AsFix_Syntax1_74sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"productions\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_75 , lf_AUX_AsFix_Syntax1_75sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"QLiteral\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_76 , lf_AUX_AsFix_Syntax1_76sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ql\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_77 , lf_AUX_AsFix_Syntax1_77sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"rhs\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_78 , lf_AUX_AsFix_Syntax1_78sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"right\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_79 , lf_AUX_AsFix_Syntax1_79sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Sort\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_80 , lf_AUX_AsFix_Syntax1_80sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"sorts\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_81 , lf_AUX_AsFix_Syntax1_81sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Section\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_82 , lf_AUX_AsFix_Syntax1_82sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"sections\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_83 , lf_AUX_AsFix_Syntax1_83sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Separator\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_84 , lf_AUX_AsFix_Syntax1_84sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"sym\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_85 , lf_AUX_AsFix_Syntax1_85sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"syms\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_86 , lf_AUX_AsFix_Syntax1_86sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Symbol\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_87 , lf_AUX_AsFix_Syntax1_87sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"symbol\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_88 , lf_AUX_AsFix_Syntax1_88sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"tag\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_89 , lf_AUX_AsFix_Syntax1_89sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"terms\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_90 , lf_AUX_AsFix_Syntax1_90sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"Term\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_91 , lf_AUX_AsFix_Syntax1_91sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"term\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_92 , lf_AUX_AsFix_Syntax1_92sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"text\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_93 , lf_AUX_AsFix_Syntax1_93sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"uses\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_94 , lf_AUX_AsFix_Syntax1_94sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"variables\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_95 , lf_AUX_AsFix_Syntax1_95sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"var\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_96 , lf_AUX_AsFix_Syntax1_96sym ) ;
register_prod ( ATparse ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"list\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_AsFix_Syntax1_97 , lf_AUX_AsFix_Syntax1_97sym ) ;
}
void resolve_AUX_AsFix_Syntax1 ( ) {
}
static ATerm constant0 = NULL ;
static ATerm constant1 = NULL ;
static ATerm constant2 = NULL ;
static ATerm constant3 = NULL ;
static ATerm constant4 = NULL ;
static ATerm constant5 = NULL ;
static ATerm constant6 = NULL ;
static ATerm constant7 = NULL ;
static ATerm constant8 = NULL ;
static ATerm constant9 = NULL ;
static ATerm constant10 = NULL ;
static ATerm constant11 = NULL ;
static ATerm constant12 = NULL ;
static ATerm constant13 = NULL ;
static ATerm constant14 = NULL ;
static ATerm constant15 = NULL ;
static ATerm constant16 = NULL ;
static ATerm constant17 = NULL ;
static ATerm constant18 = NULL ;
static ATerm constant19 = NULL ;
static ATerm constant20 = NULL ;
static ATerm constant21 = NULL ;
static ATerm constant22 = NULL ;
static ATerm constant23 = NULL ;
static ATerm constant24 = NULL ;
static ATerm constant25 = NULL ;
static ATerm constant26 = NULL ;
static ATerm constant27 = NULL ;
static ATerm constant28 = NULL ;
static ATerm constant29 = NULL ;
static ATerm constant30 = NULL ;
static ATerm constant31 = NULL ;
static ATerm constant32 = NULL ;
static ATerm constant33 = NULL ;
static ATerm constant34 = NULL ;
static ATerm constant35 = NULL ;
static ATerm constant36 = NULL ;
static ATerm constant37 = NULL ;
static ATerm constant38 = NULL ;
static ATerm constant39 = NULL ;
static ATerm constant40 = NULL ;
static ATerm constant41 = NULL ;
static ATerm constant42 = NULL ;
static ATerm constant43 = NULL ;
static ATerm constant44 = NULL ;
static ATerm constant45 = NULL ;
static ATerm constant46 = NULL ;
static ATerm constant47 = NULL ;
static ATerm constant48 = NULL ;
static ATerm constant49 = NULL ;
static ATerm constant50 = NULL ;
static ATerm constant51 = NULL ;
static ATerm constant52 = NULL ;
static ATerm constant53 = NULL ;
static ATerm constant54 = NULL ;
static ATerm constant55 = NULL ;
static ATerm constant56 = NULL ;
static ATerm constant57 = NULL ;
static ATerm constant58 = NULL ;
static ATerm constant59 = NULL ;
static ATerm constant60 = NULL ;
static ATerm constant61 = NULL ;
static ATerm constant62 = NULL ;
static ATerm constant63 = NULL ;
static ATerm constant64 = NULL ;
static ATerm constant65 = NULL ;
static ATerm constant66 = NULL ;
static ATerm constant67 = NULL ;
static ATerm constant68 = NULL ;
static ATerm constant69 = NULL ;
static ATerm constant70 = NULL ;
static ATerm constant71 = NULL ;
static ATerm constant72 = NULL ;
static ATerm constant73 = NULL ;
static ATerm constant74 = NULL ;
static ATerm constant75 = NULL ;
static ATerm constant76 = NULL ;
static ATerm constant77 = NULL ;
static ATerm constant78 = NULL ;
static ATerm constant79 = NULL ;
static ATerm constant80 = NULL ;
static ATerm constant81 = NULL ;
static ATerm constant82 = NULL ;
static ATerm constant83 = NULL ;
static ATerm constant84 = NULL ;
static ATerm constant85 = NULL ;
static ATerm constant86 = NULL ;
static ATerm constant87 = NULL ;
static ATerm constant88 = NULL ;
static ATerm constant89 = NULL ;
static ATerm constant90 = NULL ;
static ATerm constant91 = NULL ;
static ATerm constant92 = NULL ;
static ATerm constant93 = NULL ;
static ATerm constant94 = NULL ;
static ATerm constant95 = NULL ;
static ATerm constant96 = NULL ;
void init_AUX_AsFix_Syntax1 ( ) {
ATprotect ( & constant0 ) ;
ATprotect ( & constant1 ) ;
ATprotect ( & constant2 ) ;
ATprotect ( & constant3 ) ;
ATprotect ( & constant4 ) ;
ATprotect ( & constant5 ) ;
ATprotect ( & constant6 ) ;
ATprotect ( & constant7 ) ;
ATprotect ( & constant8 ) ;
ATprotect ( & constant9 ) ;
ATprotect ( & constant10 ) ;
ATprotect ( & constant11 ) ;
ATprotect ( & constant12 ) ;
ATprotect ( & constant13 ) ;
ATprotect ( & constant14 ) ;
ATprotect ( & constant15 ) ;
ATprotect ( & constant16 ) ;
ATprotect ( & constant17 ) ;
ATprotect ( & constant18 ) ;
ATprotect ( & constant19 ) ;
ATprotect ( & constant20 ) ;
ATprotect ( & constant21 ) ;
ATprotect ( & constant22 ) ;
ATprotect ( & constant23 ) ;
ATprotect ( & constant24 ) ;
ATprotect ( & constant25 ) ;
ATprotect ( & constant26 ) ;
ATprotect ( & constant27 ) ;
ATprotect ( & constant28 ) ;
ATprotect ( & constant29 ) ;
ATprotect ( & constant30 ) ;
ATprotect ( & constant31 ) ;
ATprotect ( & constant32 ) ;
ATprotect ( & constant33 ) ;
ATprotect ( & constant34 ) ;
ATprotect ( & constant35 ) ;
ATprotect ( & constant36 ) ;
ATprotect ( & constant37 ) ;
ATprotect ( & constant38 ) ;
ATprotect ( & constant39 ) ;
ATprotect ( & constant40 ) ;
ATprotect ( & constant41 ) ;
ATprotect ( & constant42 ) ;
ATprotect ( & constant43 ) ;
ATprotect ( & constant44 ) ;
ATprotect ( & constant45 ) ;
ATprotect ( & constant46 ) ;
ATprotect ( & constant47 ) ;
ATprotect ( & constant48 ) ;
ATprotect ( & constant49 ) ;
ATprotect ( & constant50 ) ;
ATprotect ( & constant51 ) ;
ATprotect ( & constant52 ) ;
ATprotect ( & constant53 ) ;
ATprotect ( & constant54 ) ;
ATprotect ( & constant55 ) ;
ATprotect ( & constant56 ) ;
ATprotect ( & constant57 ) ;
ATprotect ( & constant58 ) ;
ATprotect ( & constant59 ) ;
ATprotect ( & constant60 ) ;
ATprotect ( & constant61 ) ;
ATprotect ( & constant62 ) ;
ATprotect ( & constant63 ) ;
ATprotect ( & constant64 ) ;
ATprotect ( & constant65 ) ;
ATprotect ( & constant66 ) ;
ATprotect ( & constant67 ) ;
ATprotect ( & constant68 ) ;
ATprotect ( & constant69 ) ;
ATprotect ( & constant70 ) ;
ATprotect ( & constant71 ) ;
ATprotect ( & constant72 ) ;
ATprotect ( & constant73 ) ;
ATprotect ( & constant74 ) ;
ATprotect ( & constant75 ) ;
ATprotect ( & constant76 ) ;
ATprotect ( & constant77 ) ;
ATprotect ( & constant78 ) ;
ATprotect ( & constant79 ) ;
ATprotect ( & constant80 ) ;
ATprotect ( & constant81 ) ;
ATprotect ( & constant82 ) ;
ATprotect ( & constant83 ) ;
ATprotect ( & constant84 ) ;
ATprotect ( & constant85 ) ;
ATprotect ( & constant86 ) ;
ATprotect ( & constant87 ) ;
ATprotect ( & constant88 ) ;
ATprotect ( & constant89 ) ;
ATprotect ( & constant90 ) ;
ATprotect ( & constant91 ) ;
ATprotect ( & constant92 ) ;
ATprotect ( & constant93 ) ;
ATprotect ( & constant94 ) ;
ATprotect ( & constant95 ) ;
ATprotect ( & constant96 ) ;
}
ATerm lf_AUX_AsFix_Syntax1_97 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_97sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_97sym ) ) ;
CONS_EXIT_CONST ( constant0 , make_nf0 ( lf_AUX_AsFix_Syntax1_97sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_96 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_96sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_96sym ) ) ;
CONS_EXIT_CONST ( constant1 , make_nf0 ( lf_AUX_AsFix_Syntax1_96sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_95 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_95sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_95sym ) ) ;
CONS_EXIT_CONST ( constant2 , make_nf0 ( lf_AUX_AsFix_Syntax1_95sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_94 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_94sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_94sym ) ) ;
CONS_EXIT_CONST ( constant3 , make_nf0 ( lf_AUX_AsFix_Syntax1_94sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_93 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_93sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_93sym ) ) ;
CONS_EXIT_CONST ( constant4 , make_nf0 ( lf_AUX_AsFix_Syntax1_93sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_92 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_92sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_92sym ) ) ;
CONS_EXIT_CONST ( constant5 , make_nf0 ( lf_AUX_AsFix_Syntax1_92sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_91 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_91sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_91sym ) ) ;
CONS_EXIT_CONST ( constant6 , make_nf0 ( lf_AUX_AsFix_Syntax1_91sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_90 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_90sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_90sym ) ) ;
CONS_EXIT_CONST ( constant7 , make_nf0 ( lf_AUX_AsFix_Syntax1_90sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_89 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_89sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_89sym ) ) ;
CONS_EXIT_CONST ( constant8 , make_nf0 ( lf_AUX_AsFix_Syntax1_89sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_88 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_88sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_88sym ) ) ;
CONS_EXIT_CONST ( constant9 , make_nf0 ( lf_AUX_AsFix_Syntax1_88sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_87 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_87sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_87sym ) ) ;
CONS_EXIT_CONST ( constant10 , make_nf0 ( lf_AUX_AsFix_Syntax1_87sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_86 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_86sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_86sym ) ) ;
CONS_EXIT_CONST ( constant11 , make_nf0 ( lf_AUX_AsFix_Syntax1_86sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_85 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_85sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_85sym ) ) ;
CONS_EXIT_CONST ( constant12 , make_nf0 ( lf_AUX_AsFix_Syntax1_85sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_84 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_84sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_84sym ) ) ;
CONS_EXIT_CONST ( constant13 , make_nf0 ( lf_AUX_AsFix_Syntax1_84sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_83 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_83sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_83sym ) ) ;
CONS_EXIT_CONST ( constant14 , make_nf0 ( lf_AUX_AsFix_Syntax1_83sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_82 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_82sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_82sym ) ) ;
CONS_EXIT_CONST ( constant15 , make_nf0 ( lf_AUX_AsFix_Syntax1_82sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_81 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_81sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_81sym ) ) ;
CONS_EXIT_CONST ( constant16 , make_nf0 ( lf_AUX_AsFix_Syntax1_81sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_80 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_80sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_80sym ) ) ;
CONS_EXIT_CONST ( constant17 , make_nf0 ( lf_AUX_AsFix_Syntax1_80sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_79 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_79sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_79sym ) ) ;
CONS_EXIT_CONST ( constant18 , make_nf0 ( lf_AUX_AsFix_Syntax1_79sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_78 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_78sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_78sym ) ) ;
CONS_EXIT_CONST ( constant19 , make_nf0 ( lf_AUX_AsFix_Syntax1_78sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_77 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_77sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_77sym ) ) ;
CONS_EXIT_CONST ( constant20 , make_nf0 ( lf_AUX_AsFix_Syntax1_77sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_76 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_76sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_76sym ) ) ;
CONS_EXIT_CONST ( constant21 , make_nf0 ( lf_AUX_AsFix_Syntax1_76sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_75 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_75sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_75sym ) ) ;
CONS_EXIT_CONST ( constant22 , make_nf0 ( lf_AUX_AsFix_Syntax1_75sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_74 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_74sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_74sym ) ) ;
CONS_EXIT_CONST ( constant23 , make_nf0 ( lf_AUX_AsFix_Syntax1_74sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_73 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_73sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_73sym ) ) ;
CONS_EXIT_CONST ( constant24 , make_nf0 ( lf_AUX_AsFix_Syntax1_73sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_72 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_72sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_72sym ) ) ;
CONS_EXIT_CONST ( constant25 , make_nf0 ( lf_AUX_AsFix_Syntax1_72sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_71 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_71sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_71sym ) ) ;
CONS_EXIT_CONST ( constant26 , make_nf0 ( lf_AUX_AsFix_Syntax1_71sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_70 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_70sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_70sym ) ) ;
CONS_EXIT_CONST ( constant27 , make_nf0 ( lf_AUX_AsFix_Syntax1_70sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_69 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_69sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_69sym ) ) ;
CONS_EXIT_CONST ( constant28 , make_nf0 ( lf_AUX_AsFix_Syntax1_69sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_68 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_68sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_68sym ) ) ;
CONS_EXIT_CONST ( constant29 , make_nf0 ( lf_AUX_AsFix_Syntax1_68sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_67 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_67sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_67sym ) ) ;
CONS_EXIT_CONST ( constant30 , make_nf0 ( lf_AUX_AsFix_Syntax1_67sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_66 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_66sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_66sym ) ) ;
CONS_EXIT_CONST ( constant31 , make_nf0 ( lf_AUX_AsFix_Syntax1_66sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_65 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_65sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_65sym ) ) ;
CONS_EXIT_CONST ( constant32 , make_nf0 ( lf_AUX_AsFix_Syntax1_65sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_64 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_64sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_64sym ) ) ;
CONS_EXIT_CONST ( constant33 , make_nf0 ( lf_AUX_AsFix_Syntax1_64sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_63 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_63sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_63sym ) ) ;
CONS_EXIT_CONST ( constant34 , make_nf0 ( lf_AUX_AsFix_Syntax1_63sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_62 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_62sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_62sym ) ) ;
CONS_EXIT_CONST ( constant35 , make_nf0 ( lf_AUX_AsFix_Syntax1_62sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_61 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_61sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_61sym ) ) ;
CONS_EXIT_CONST ( constant36 , make_nf0 ( lf_AUX_AsFix_Syntax1_61sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_60 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_60sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_60sym ) ) ;
CONS_EXIT_CONST ( constant37 , make_nf0 ( lf_AUX_AsFix_Syntax1_60sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_59 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_59sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_59sym ) ) ;
CONS_EXIT_CONST ( constant38 , make_nf0 ( lf_AUX_AsFix_Syntax1_59sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_58 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_58sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_58sym ) ) ;
CONS_EXIT_CONST ( constant39 , make_nf0 ( lf_AUX_AsFix_Syntax1_58sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_57 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_57sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_57sym ) ) ;
CONS_EXIT_CONST ( constant40 , make_nf0 ( lf_AUX_AsFix_Syntax1_57sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_56 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_56sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_56sym ) ) ;
CONS_EXIT_CONST ( constant41 , make_nf0 ( lf_AUX_AsFix_Syntax1_56sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_55 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_55sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_55sym ) ) ;
CONS_EXIT_CONST ( constant42 , make_nf0 ( lf_AUX_AsFix_Syntax1_55sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_54 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_54sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_54sym ) ) ;
CONS_EXIT_CONST ( constant43 , make_nf0 ( lf_AUX_AsFix_Syntax1_54sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_53 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_53sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_53sym ) ) ;
CONS_EXIT_CONST ( constant44 , make_nf0 ( lf_AUX_AsFix_Syntax1_53sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_52 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_52sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_52sym ) ) ;
CONS_EXIT_CONST ( constant45 , make_nf0 ( lf_AUX_AsFix_Syntax1_52sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_51 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_51sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_51sym ) ) ;
CONS_EXIT_CONST ( constant46 , make_nf0 ( lf_AUX_AsFix_Syntax1_51sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_50 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_50sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_50sym ) ) ;
CONS_EXIT_CONST ( constant47 , make_nf0 ( lf_AUX_AsFix_Syntax1_50sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_49 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_49sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_49sym ) ) ;
CONS_EXIT_CONST ( constant48 , make_nf0 ( lf_AUX_AsFix_Syntax1_49sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_48 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_48sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_48sym ) ) ;
CONS_EXIT_CONST ( constant49 , make_nf0 ( lf_AUX_AsFix_Syntax1_48sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_47 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_47sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_47sym ) ) ;
CONS_EXIT_CONST ( constant50 , make_nf0 ( lf_AUX_AsFix_Syntax1_47sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_46 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_46sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_46sym ) ) ;
CONS_EXIT_CONST ( constant51 , make_nf0 ( lf_AUX_AsFix_Syntax1_46sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_45 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_45sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_45sym ) ) ;
CONS_EXIT_CONST ( constant52 , make_nf0 ( lf_AUX_AsFix_Syntax1_45sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_44 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_44sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_44sym ) ) ;
CONS_EXIT_CONST ( constant53 , make_nf0 ( lf_AUX_AsFix_Syntax1_44sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_43 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_43sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_43sym ) ) ;
CONS_EXIT_CONST ( constant54 , make_nf0 ( lf_AUX_AsFix_Syntax1_43sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_42 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_42sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_42sym ) ) ;
CONS_EXIT_CONST ( constant55 , make_nf0 ( lf_AUX_AsFix_Syntax1_42sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_41 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_41sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_41sym ) ) ;
CONS_EXIT_CONST ( constant56 , make_nf0 ( lf_AUX_AsFix_Syntax1_41sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_40 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_40sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_40sym ) ) ;
CONS_EXIT_CONST ( constant57 , make_nf0 ( lf_AUX_AsFix_Syntax1_40sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_39 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_39sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_39sym ) ) ;
CONS_EXIT_CONST ( constant58 , make_nf0 ( lf_AUX_AsFix_Syntax1_39sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_38 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_38sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_38sym ) ) ;
CONS_EXIT_CONST ( constant59 , make_nf0 ( lf_AUX_AsFix_Syntax1_38sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_37 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_37sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_37sym ) ) ;
CONS_EXIT_CONST ( constant60 , make_nf0 ( lf_AUX_AsFix_Syntax1_37sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_36 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_36sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_36sym ) ) ;
CONS_EXIT_CONST ( constant61 , make_nf0 ( lf_AUX_AsFix_Syntax1_36sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_35 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_35sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_35sym ) ) ;
CONS_EXIT_CONST ( constant62 , make_nf0 ( lf_AUX_AsFix_Syntax1_35sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_34 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_34sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_34sym ) ) ;
CONS_EXIT_CONST ( constant63 , make_nf0 ( lf_AUX_AsFix_Syntax1_34sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_33 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_33sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_33sym ) ) ;
CONS_EXIT_CONST ( constant64 , make_nf0 ( lf_AUX_AsFix_Syntax1_33sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_32 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_32sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_32sym ) ) ;
CONS_EXIT_CONST ( constant65 , make_nf0 ( lf_AUX_AsFix_Syntax1_32sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_31 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_31sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_31sym ) ) ;
CONS_EXIT_CONST ( constant66 , make_nf0 ( lf_AUX_AsFix_Syntax1_31sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_30 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_30sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_30sym ) ) ;
CONS_EXIT_CONST ( constant67 , make_nf0 ( lf_AUX_AsFix_Syntax1_30sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_29 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_29sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_29sym ) ) ;
CONS_EXIT_CONST ( constant68 , make_nf0 ( lf_AUX_AsFix_Syntax1_29sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_28 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_28sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_28sym ) ) ;
CONS_EXIT_CONST ( constant69 , make_nf0 ( lf_AUX_AsFix_Syntax1_28sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_27 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_27sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_27sym ) ) ;
CONS_EXIT_CONST ( constant70 , make_nf0 ( lf_AUX_AsFix_Syntax1_27sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_26 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_26sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_26sym ) ) ;
CONS_EXIT_CONST ( constant71 , make_nf0 ( lf_AUX_AsFix_Syntax1_26sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_25 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_25sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_25sym ) ) ;
CONS_EXIT_CONST ( constant72 , make_nf0 ( lf_AUX_AsFix_Syntax1_25sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_24 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_24sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_24sym ) ) ;
CONS_EXIT_CONST ( constant73 , make_nf0 ( lf_AUX_AsFix_Syntax1_24sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_23 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_23sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_23sym ) ) ;
CONS_EXIT_CONST ( constant74 , make_nf0 ( lf_AUX_AsFix_Syntax1_23sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_22 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_22sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_22sym ) ) ;
CONS_EXIT_CONST ( constant75 , make_nf0 ( lf_AUX_AsFix_Syntax1_22sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_21 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_21sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_21sym ) ) ;
CONS_EXIT_CONST ( constant76 , make_nf0 ( lf_AUX_AsFix_Syntax1_21sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_20 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_20sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_20sym ) ) ;
CONS_EXIT_CONST ( constant77 , make_nf0 ( lf_AUX_AsFix_Syntax1_20sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_19 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_19sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_19sym ) ) ;
CONS_EXIT_CONST ( constant78 , make_nf0 ( lf_AUX_AsFix_Syntax1_19sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_18 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_18sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_18sym ) ) ;
CONS_EXIT_CONST ( constant79 , make_nf0 ( lf_AUX_AsFix_Syntax1_18sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_17 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_17sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_17sym ) ) ;
CONS_EXIT_CONST ( constant80 , make_nf0 ( lf_AUX_AsFix_Syntax1_17sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_16 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_16sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_16sym ) ) ;
CONS_EXIT_CONST ( constant81 , make_nf0 ( lf_AUX_AsFix_Syntax1_16sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_15 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_15sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_15sym ) ) ;
CONS_EXIT_CONST ( constant82 , make_nf0 ( lf_AUX_AsFix_Syntax1_15sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_14 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_14sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_14sym ) ) ;
CONS_EXIT_CONST ( constant83 , make_nf0 ( lf_AUX_AsFix_Syntax1_14sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_13 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_13sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_13sym ) ) ;
CONS_EXIT_CONST ( constant84 , make_nf0 ( lf_AUX_AsFix_Syntax1_13sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_12 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_12sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_12sym ) ) ;
CONS_EXIT_CONST ( constant85 , make_nf0 ( lf_AUX_AsFix_Syntax1_12sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_11 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_11sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_11sym ) ) ;
CONS_EXIT_CONST ( constant86 , make_nf0 ( lf_AUX_AsFix_Syntax1_11sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_10 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_10sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_10sym ) ) ;
CONS_EXIT_CONST ( constant87 , make_nf0 ( lf_AUX_AsFix_Syntax1_10sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_9 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_9sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_9sym ) ) ;
CONS_EXIT_CONST ( constant88 , make_nf0 ( lf_AUX_AsFix_Syntax1_9sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_8 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_8sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_8sym ) ) ;
CONS_EXIT_CONST ( constant89 , make_nf0 ( lf_AUX_AsFix_Syntax1_8sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_7 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_7sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_7sym ) ) ;
CONS_EXIT_CONST ( constant90 , make_nf0 ( lf_AUX_AsFix_Syntax1_7sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_6 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_6sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_6sym ) ) ;
CONS_EXIT_CONST ( constant91 , make_nf0 ( lf_AUX_AsFix_Syntax1_6sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_5 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_5sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_5sym ) ) ;
CONS_EXIT_CONST ( constant92 , make_nf0 ( lf_AUX_AsFix_Syntax1_5sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_4 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_4sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_4sym ) ) ;
CONS_EXIT_CONST ( constant93 , make_nf0 ( lf_AUX_AsFix_Syntax1_4sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_3 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_3sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_3sym ) ) ;
CONS_EXIT_CONST ( constant94 , make_nf0 ( lf_AUX_AsFix_Syntax1_3sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_2 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_2sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_2sym ) ) ;
CONS_EXIT_CONST ( constant95 , make_nf0 ( lf_AUX_AsFix_Syntax1_2sym ) ) ;
}
ATerm lf_AUX_AsFix_Syntax1_1 ( ) {
CONS_ENTRY ( lf_AUX_AsFix_Syntax1_1sym , ATmakeAppl0 ( lf_AUX_AsFix_Syntax1_1sym ) ) ;
CONS_EXIT_CONST ( constant96 , make_nf0 ( lf_AUX_AsFix_Syntax1_1sym ) ) ;
}

