#include  "asc-support.h"
void register_AUX_ATerm_Tables1 ( ) {
}
void resolve_AUX_ATerm_Tables1 ( ) {
}
void init_AUX_ATerm_Tables1 ( ) {
}

