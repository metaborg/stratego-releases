#include  "asc-support.h"
void register_AUX_ATerm_Trees1 ( ) {
}
void resolve_AUX_ATerm_Trees1 ( ) {
}
void init_AUX_ATerm_Trees1 ( ) {
}

