#include  "asc-support.h"
void register_AUX_AsFix_Toolkit1 ( ) {
}
void resolve_AUX_AsFix_Toolkit1 ( ) {
}
void init_AUX_AsFix_Toolkit1 ( ) {
}

