#include  "asc-support.h"
void register_AUX_ATerm_Layout1 ( ) {
}
void resolve_AUX_ATerm_Layout1 ( ) {
}
void init_AUX_ATerm_Layout1 ( ) {
}

