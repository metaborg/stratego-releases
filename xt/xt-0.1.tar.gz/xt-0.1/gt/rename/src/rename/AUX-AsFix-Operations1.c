#include  "asc-support.h"
void register_AUX_AsFix_Operations1 ( ) {
}
void resolve_AUX_AsFix_Operations1 ( ) {
}
void init_AUX_AsFix_Operations1 ( ) {
}

