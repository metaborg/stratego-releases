#include  "asc-support.h"
static Symbol lf_AUX_ATerm_Operations13_2sym ;
static ATerm lf_AUX_ATerm_Operations13_2 ( ATerm arg1 , ATerm arg2 ) ;
static Symbol ef11sym ;
static funcptr ef11 ;
static Symbol ef15sym ;
static funcptr ef15 ;
static Symbol ef16sym ;
static funcptr ef16 ;
static Symbol ef18sym ;
static funcptr ef18 ;
static Symbol ef20sym ;
static funcptr ef20 ;
static Symbol ef22sym ;
static funcptr ef22 ;
static Symbol ef23sym ;
static funcptr ef23 ;
static Symbol ef26sym ;
static funcptr ef26 ;
static Symbol ef24sym ;
static funcptr ef24 ;
static Symbol ef5sym ;
static funcptr ef5 ;
static Symbol ef27sym ;
static funcptr ef27 ;
static Symbol ef29sym ;
static funcptr ef29 ;
static Symbol ef32sym ;
static funcptr ef32 ;
static Symbol ef33sym ;
static funcptr ef33 ;
static Symbol ef30sym ;
static funcptr ef30 ;
static Symbol ef31sym ;
static funcptr ef31 ;
static Symbol ef35sym ;
static funcptr ef35 ;
static Symbol ef34sym ;
static funcptr ef34 ;
static Symbol ef36sym ;
static funcptr ef36 ;
static Symbol ef21sym ;
static funcptr ef21 ;
static Symbol ef12sym ;
static funcptr ef12 ;
static Symbol ef37sym ;
static funcptr ef37 ;
static Symbol ef13sym ;
static funcptr ef13 ;
static Symbol ef9sym ;
static funcptr ef9 ;
static Symbol ef38sym ;
static funcptr ef38 ;
static Symbol ef25sym ;
static funcptr ef25 ;
static Symbol lf4sym ;
static ATerm lf4 ( ATerm arg1 ) ;
static Symbol ef40sym ;
static funcptr ef40 ;
static Symbol ef41sym ;
static funcptr ef41 ;
static Symbol ef6sym ;
static funcptr ef6 ;
static Symbol ef43sym ;
static funcptr ef43 ;
static Symbol ef7sym ;
static funcptr ef7 ;
static Symbol ef17sym ;
static funcptr ef17 ;
static Symbol ef44sym ;
static funcptr ef44 ;
static Symbol ef45sym ;
static funcptr ef45 ;
static Symbol ef46sym ;
static funcptr ef46 ;
static Symbol ef47sym ;
static funcptr ef47 ;
static Symbol ef49sym ;
static funcptr ef49 ;
static Symbol ef48sym ;
static funcptr ef48 ;
static Symbol ef10sym ;
static funcptr ef10 ;
static Symbol ef14sym ;
static funcptr ef14 ;
static Symbol ef50sym ;
static funcptr ef50 ;
static Symbol ef28sym ;
static funcptr ef28 ;
static Symbol ef8sym ;
static funcptr ef8 ;
static Symbol ef51sym ;
static funcptr ef51 ;
static Symbol ef52sym ;
static funcptr ef52 ;
static Symbol ef53sym ;
static funcptr ef53 ;
static Symbol ef56sym ;
static funcptr ef56 ;
static Symbol ef58sym ;
static funcptr ef58 ;
static Symbol ef54sym ;
static funcptr ef54 ;
static Symbol ef55sym ;
static funcptr ef55 ;
static Symbol ef60sym ;
static funcptr ef60 ;
static Symbol ef59sym ;
static funcptr ef59 ;
static Symbol ef57sym ;
static funcptr ef57 ;
static Symbol ef61sym ;
static funcptr ef61 ;
static Symbol ef62sym ;
static funcptr ef62 ;
static Symbol ef42sym ;
static funcptr ef42 ;
static Symbol ef63sym ;
static funcptr ef63 ;
static Symbol ef64sym ;
static funcptr ef64 ;
static Symbol ef65sym ;
static funcptr ef65 ;
static Symbol ef66sym ;
static funcptr ef66 ;
static Symbol ef67sym ;
static funcptr ef67 ;
static Symbol ef19sym ;
static funcptr ef19 ;
static Symbol ef39sym ;
static funcptr ef39 ;
static Symbol ef68sym ;
static funcptr ef68 ;
static Symbol ef69sym ;
static funcptr ef69 ;
static Symbol ef70sym ;
static funcptr ef70 ;
static Symbol ef1sym ;
static funcptr ef1 ;
static Symbol ef2sym ;
static funcptr ef2 ;
static Symbol lf3sym ;
static ATerm lf3 ( ATerm arg1 ) ;
static Symbol ef3sym ;
static funcptr ef3 ;
static Symbol lf_AUX_ATerm_Operations13_1sym ;
static ATerm lf_AUX_ATerm_Operations13_1 ( ATerm arg1 ) ;
static Symbol ef4sym ;
static funcptr ef4 ;
static Symbol ef71sym ;
static funcptr ef71 ;
void register_AUX_ATerm_Operations13 ( ) {
lf_AUX_ATerm_Operations13_2sym = ATmakeSymbol ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"apply\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)"
 , 2 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_ATerm_Operations13_2sym ) ;
lf4sym = ATmakeSymbol ( "listtype(sort(\"AFun\"),ql(\".\"))" , 1 , ATtrue ) ;
ATprotectSymbol ( lf4sym ) ;
lf3sym = ATmakeSymbol ( "listtype(sort(\"CHAR\"))" , 1 , ATtrue ) ;
ATprotectSymbol ( lf3sym ) ;
lf_AUX_ATerm_Operations13_1sym = ATmakeSymbol ( "listtype(sort(\"ATerm\"),ql(\",\"))" , 1 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_ATerm_Operations13_1sym ) ;
register_prod ( ATparse ( "listtype(sort(\"ATerm\"),ql(\",\"))" ) , lf_AUX_ATerm_Operations13_1 , lf_AUX_ATerm_Operations13_1sym ) ;
register_prod ( ATparse ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"apply\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) , lf_AUX_ATerm_Operations13_2 , lf_AUX_ATerm_Operations13_2sym ) ;
register_prod ( ATparse ( "listtype(sort(\"CHAR\"))" ) , lf3 , lf3sym ) ;
register_prod ( ATparse ( "listtype(sort(\"AFun\"),ql(\".\"))" ) , lf4 , lf4sym ) ;
}
void resolve_AUX_ATerm_Operations13 ( ) {
ef1 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"AFun\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef1sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"AFun\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef2 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"Literal\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef2sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"Literal\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef3 = lookup_func ( ATreadFromString ( "prod(id(\"caller\"),w(\"\"),[l(\"literal\"),w(\"\"),ql(\"(\"),w(\"\"),iter(sort(\"CHAR\"),w(\"\"),l(\"+\")),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Literal\"),w(\"\"),no-attrs)" ) ) ;
ef3sym = lookup_sym ( ATreadFromString ( "prod(id(\"caller\"),w(\"\"),[l(\"literal\"),w(\"\"),ql(\"(\"),w(\"\"),iter(sort(\"CHAR\"),w(\"\"),l(\"+\")),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Literal\"),w(\"\"),no-attrs)" ) ) ;
ef4 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"ATermList\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef4sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"ATermList\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef5 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"if\"),w(\"\"),sort(\"Bool\"),w(\"\"),l(\"then\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\"else\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\"fi\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef5sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"if\"),w(\"\"),sort(\"Bool\"),w(\"\"),l(\"then\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\"else\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\"fi\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef6 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"empty\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef6sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"empty\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef7 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[ql(\"[\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"*\")),w(\"\"),ql(\"]\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef7sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[ql(\"[\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"*\")),w(\"\"),ql(\"]\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef8 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[sort(\"ATermList\"),w(\"\"),ql(\"++\"),w(\"\"),sort(\"ATermList\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"right\")],w(\"\"),l(\"}\")))" ) ) ;
ef8sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[sort(\"ATermList\"),w(\"\"),ql(\"++\"),w(\"\"),sort(\"ATermList\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"right\")],w(\"\"),l(\"}\")))" ) ) ;
ef9 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[ql(\"fun\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef9sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[ql(\"fun\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef10 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Syntax\"),w(\"\"),[ql(\"w\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef10sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Syntax\"),w(\"\"),[ql(\"w\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef11 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Syntax\"),w(\"\"),[ql(\"sep\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef11sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Syntax\"),w(\"\"),[ql(\"sep\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef12 = lookup_func ( ATreadFromString ( "prod(id(\"Boolean-Syntax\"),w(\"\"),[sort(\"Bool\"),w(\"\"),ql(\"\\\\\\\\/\"),w(\"\"),sort(\"Bool\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"assoc\")],w(\"\"),l(\"}\")))" ) ) ;
ef12sym = lookup_sym ( ATreadFromString ( "prod(id(\"Boolean-Syntax\"),w(\"\"),[sort(\"Bool\"),w(\"\"),ql(\"\\\\\\\\/\"),w(\"\"),sort(\"Bool\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"assoc\")],w(\"\"),l(\"}\")))" ) ) ;
ef13 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\"==\"),w(\"\"),sort(\"ATerm\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef13sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\"==\"),w(\"\"),sort(\"ATerm\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef14 = lookup_func ( ATreadFromString ( "prod(id(\"Boolean-Syntax\"),w(\"\"),[ql(\"true\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef14sym = lookup_sym ( ATreadFromString ( "prod(id(\"Boolean-Syntax\"),w(\"\"),[ql(\"true\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef15 = lookup_func ( ATreadFromString ( "prod(id(\"Ren-productions\"),w(\"\"),[ql(\"rename-prod\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef15sym = lookup_sym ( ATreadFromString ( "prod(id(\"Ren-productions\"),w(\"\"),[ql(\"rename-prod\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef16 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"if\"),w(\"\"),sort(\"Bool\"),w(\"\"),l(\"then\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\"else\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\"fi\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef16sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"if\"),w(\"\"),sort(\"Bool\"),w(\"\"),l(\"then\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\"else\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\"fi\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef17 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"ann\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef17sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"ann\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef18 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"set-ann\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef18sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"set-ann\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef19 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"AFun\"),w(\"\"),ql(\"(\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef19sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"AFun\"),w(\"\"),ql(\"(\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef20 = lookup_func ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prod\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef20sym = lookup_sym ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"prod\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef21 = lookup_func ( ATreadFromString ( "prod(id(\"Ren-ATerm\"),w(\"\"),[ql(\"rename\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef21sym = lookup_sym ( ATreadFromString ( "prod(id(\"Ren-ATerm\"),w(\"\"),[ql(\"rename\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef22 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\"[\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"AFun\"),w(\"\"),ql(\".\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\":=\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\"]\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef22sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\"[\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"AFun\"),w(\"\"),ql(\".\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\":=\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\"]\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef23 = lookup_func ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ids\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef23sym = lookup_sym ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"ids\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef24 = lookup_func ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"imports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef24sym = lookup_sym ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"imports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef25 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\"[\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"AFun\"),w(\"\"),ql(\".\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\"]\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef25sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\"[\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"AFun\"),w(\"\"),ql(\".\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\"]\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef26 = lookup_func ( ATreadFromString ( "prod(id(\"ModuleTable2AsFix\"),w(\"\"),[ql(\"update-imports\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef26sym = lookup_sym ( ATreadFromString ( "prod(id(\"ModuleTable2AsFix\"),w(\"\"),[ql(\"update-imports\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef27 = lookup_func ( ATreadFromString ( "prod(id(\"Misc\"),w(\"\"),[ql(\"contains\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef27sym = lookup_sym ( ATreadFromString ( "prod(id(\"Misc\"),w(\"\"),[ql(\"contains\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef28 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\":\"),w(\"\"),sort(\"ATermList\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef28sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[sort(\"ATerm\"),w(\"\"),ql(\":\"),w(\"\"),sort(\"ATermList\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef29 = lookup_func ( ATreadFromString ( "prod(id(\"Ren-sorts\"),w(\"\"),[ql(\"rename-sort\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef29sym = lookup_sym ( ATreadFromString ( "prod(id(\"Ren-sorts\"),w(\"\"),[ql(\"rename-sort\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef30 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Syntax\"),w(\"\"),[ql(\"sort\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef30sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Syntax\"),w(\"\"),[ql(\"sort\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef31 = lookup_func ( ATreadFromString ( "prod(id(\"Lookup\"),w(\"\"),[ql(\"lookup\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef31sym = lookup_sym ( ATreadFromString ( "prod(id(\"Lookup\"),w(\"\"),[ql(\"lookup\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef32 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"AFun\"),w(\"\"),sort(\"Args\"),w(\"\"),sort(\"Ann\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef32sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"AFun\"),w(\"\"),sort(\"Args\"),w(\"\"),sort(\"Ann\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef33 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[ql(\"(\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Args\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef33sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[ql(\"(\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Args\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef34 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[ql(\"{\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\"}\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Ann\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef34sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[ql(\"{\"),w(\"\"),iter-sep(l(\"{\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),l(\"}\"),w(\"\"),l(\"+\")),w(\"\"),ql(\"}\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Ann\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef35 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"ATermList\"),w(\"\"),sort(\"Ann\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef35sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"ATermList\"),w(\"\"),sort(\"Ann\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef36 = lookup_func ( ATreadFromString ( "prod(id(\"Ren-ATerm\"),w(\"\"),[ql(\"rename-aterm\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef36sym = lookup_sym ( ATreadFromString ( "prod(id(\"Ren-ATerm\"),w(\"\"),[ql(\"rename-aterm\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef37 = lookup_func ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"exports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef37sym = lookup_sym ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"exports\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef38 = lookup_func ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"hiddens\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef38sym = lookup_sym ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"hiddens\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef39 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[ql(\"term\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef39sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Operations\"),w(\"\"),[ql(\"term\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef40 = lookup_func ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"grammars\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef40sym = lookup_sym ( ATreadFromString ( "prod(id(\"AsFix-Syntax\"),w(\"\"),[ql(\"grammars\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef41 = lookup_func ( ATreadFromString ( "prod(id(\"Misc\"),w(\"\"),[ql(\"is-empty\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef41sym = lookup_sym ( ATreadFromString ( "prod(id(\"Misc\"),w(\"\"),[ql(\"is-empty\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef42 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"filter\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef42sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"filter\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef43 = lookup_func ( ATreadFromString ( "prod(id(\"ModuleTable2AsFix\"),w(\"\"),[ql(\"make-new-name\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef43sym = lookup_sym ( ATreadFromString ( "prod(id(\"ModuleTable2AsFix\"),w(\"\"),[ql(\"make-new-name\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef44 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Trees-Ann\"),w(\"\"),[ql(\"treplace-ann\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef44sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Trees-Ann\"),w(\"\"),[ql(\"treplace-ann\"),w(\"\"),ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef45 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[l(\"subterms\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef45sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[l(\"subterms\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef46 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[l(\"treplace\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef46sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[l(\"treplace\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef47 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[l(\"tmap\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef47sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Trees\"),w(\"\"),[l(\"tmap\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef48 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[l(\"is-cons\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"AFun\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef48sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[l(\"is-cons\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"AFun\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),no-attrs)" ) ) ;
ef49 = lookup_func ( ATreadFromString ( "prod(id(\"Boolean-Syntax\"),w(\"\"),[ql(\"false\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef49sym = lookup_sym ( ATreadFromString ( "prod(id(\"Boolean-Syntax\"),w(\"\"),[ql(\"false\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Bool\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef50 = lookup_func ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[l(\"wmap\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef50sym = lookup_sym ( ATreadFromString ( "prod(id(\"ParseTree-Operations\"),w(\"\"),[l(\"wmap\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef51 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"concat\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef51sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"concat\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef52 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"first\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef52sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"first\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef53 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"rest\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef53sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"rest\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef54 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"ACon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef54sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"ACon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef55 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"IntCon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ACon\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef55sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Syntax\"),w(\"\"),[sort(\"IntCon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ACon\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef56 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"size\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"IntCon\"),w(\"\"),no-attrs)" ) ) ;
ef56sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"size\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"IntCon\"),w(\"\"),no-attrs)" ) ) ;
ef57 = lookup_func ( ATreadFromString ( "prod(id(\"Integer-Syntax\"),w(\"\"),[sort(\"NatCon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"IntCon\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef57sym = lookup_sym ( ATreadFromString ( "prod(id(\"Integer-Syntax\"),w(\"\"),[sort(\"NatCon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"IntCon\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef58 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"index\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"Int\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef58sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"index\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"Int\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef59 = lookup_func ( ATreadFromString ( "prod(id(\"Integer-Syntax\"),w(\"\"),[sort(\"IntCon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Int\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef59sym = lookup_sym ( ATreadFromString ( "prod(id(\"Integer-Syntax\"),w(\"\"),[sort(\"IntCon\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"Int\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) ) ;
ef60 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"replace\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"Int\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef60sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"replace\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"Int\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef61 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"delete\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef61sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"delete\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef62 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"delete1\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef62sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"delete1\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef63 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"map\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef63sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"map\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef64 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"zip\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef64sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"zip\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef65 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"foldr\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef65sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"foldr\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef66 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"foldl\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef66sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"foldl\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef67 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"foldr-zip\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef67sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Lists\"),w(\"\"),[l(\"foldr-zip\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef68 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"get\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef68sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"get\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef69 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"eget\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef69sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"eget\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),no-attrs)" ) ) ;
ef70 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"put\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef70sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"put\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef71 = lookup_func ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"cput\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
ef71sym = lookup_sym ( ATreadFromString ( "prod(id(\"ATerm-Tables\"),w(\"\"),[l(\"cput\"),w(\"\"),l(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),l(\",\"),w(\"\"),sort(\"ATerm\"),w(\"\"),l(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),no-attrs)" ) ) ;
}
static ATerm constant0 = NULL ;
static ATerm constant1 = NULL ;
static ATerm constant2 = NULL ;
static ATerm constant3 = NULL ;
static ATerm constant4 = NULL ;
static ATerm constant5 = NULL ;
static ATerm constant6 = NULL ;
static ATerm constant7 = NULL ;
static ATerm constant8 = NULL ;
static ATerm constant9 = NULL ;
static ATerm constant10 = NULL ;
static ATerm constant11 = NULL ;
static ATerm constant12 = NULL ;
void init_AUX_ATerm_Operations13 ( ) {
ATprotect ( & constant0 ) ;
ATprotect ( & constant1 ) ;
ATprotect ( & constant2 ) ;
ATprotect ( & constant3 ) ;
ATprotect ( & constant4 ) ;
ATprotect ( & constant5 ) ;
ATprotect ( & constant6 ) ;
ATprotect ( & constant7 ) ;
ATprotect ( & constant8 ) ;
ATprotect ( & constant9 ) ;
ATprotect ( & constant10 ) ;
ATprotect ( & constant11 ) ;
ATprotect ( & constant12 ) ;
}
ATerm lf_AUX_ATerm_Operations13_2 ( ATerm arg0 , ATerm arg1 ) {
{
ATerm tmp [ 40 ] ;
FUNC_ENTRY ( lf_AUX_ATerm_Operations13_2sym , ATmakeAppl ( lf_AUX_ATerm_Operations13_2sym , arg0 , arg1 ) ) ;
{
ATerm ltmp [ 2 ] ;
lbl_lf_AUX_ATerm_Operations13_2 : ltmp [ 0 ] = arg0 ;
ltmp [ 1 ] = arg1 ;
if ( check_sym ( ltmp [ 0 ] , ef1sym ) ) {
{
ATerm atmp00 = arg_0 ( arg0 ) ;
if ( check_sym ( atmp00 , ef2sym ) ) {
{
ATerm atmp000 = arg_0 ( atmp00 ) ;
if ( check_sym ( atmp000 , ef3sym ) ) {
{
ATerm atmp0000 = arg_0 ( atmp000 ) ;
if ( check_sym ( atmp0000 , lf3sym ) ) {
{
ATerm atmp00000 = arg_0 ( atmp0000 ) ;
if ( check_sym ( ltmp [ 1 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp10 = arg_0 ( arg1 ) ;
if ( not_empty_list ( atmp00000 ) ) {
tmp [ 0 ] = list_head ( atmp00000 ) ;
if ( term_equal ( tmp [ 0 ] , make_char ( 34 ) ) ) {
tmp [ 1 ] = list_tail ( atmp00000 ) ;
{
if ( not_empty_list ( tmp [ 1 ] ) ) {
tmp [ 2 ] = list_head ( tmp [ 1 ] ) ;
if ( term_equal ( tmp [ 2 ] , make_char ( 117 ) ) ) {
tmp [ 3 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 3 ] ) ) {
tmp [ 4 ] = list_head ( tmp [ 3 ] ) ;
if ( term_equal ( tmp [ 4 ] , make_char ( 112 ) ) ) {
tmp [ 5 ] = list_tail ( tmp [ 3 ] ) ;
{
if ( not_empty_list ( tmp [ 5 ] ) ) {
tmp [ 6 ] = list_head ( tmp [ 5 ] ) ;
if ( term_equal ( tmp [ 6 ] , make_char ( 100 ) ) ) {
tmp [ 7 ] = list_tail ( tmp [ 5 ] ) ;
{
if ( not_empty_list ( tmp [ 7 ] ) ) {
tmp [ 8 ] = list_head ( tmp [ 7 ] ) ;
if ( term_equal ( tmp [ 8 ] , make_char ( 97 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 7 ] ) ;
{
if ( not_empty_list ( tmp [ 9 ] ) ) {
tmp [ 10 ] = list_head ( tmp [ 9 ] ) ;
if ( term_equal ( tmp [ 10 ] , make_char ( 116 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 9 ] ) ;
{
if ( not_empty_list ( tmp [ 11 ] ) ) {
tmp [ 12 ] = list_head ( tmp [ 11 ] ) ;
if ( term_equal ( tmp [ 12 ] , make_char ( 101 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 11 ] ) ;
{
if ( not_empty_list ( tmp [ 13 ] ) ) {
tmp [ 14 ] = list_head ( tmp [ 13 ] ) ;
if ( term_equal ( tmp [ 14 ] , make_char ( 45 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 13 ] ) ;
{
if ( not_empty_list ( tmp [ 15 ] ) ) {
tmp [ 16 ] = list_head ( tmp [ 15 ] ) ;
if ( term_equal ( tmp [ 16 ] , make_char ( 105 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 15 ] ) ;
{
if ( not_empty_list ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
if ( term_equal ( tmp [ 18 ] , make_char ( 109 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 17 ] ) ;
{
if ( not_empty_list ( tmp [ 19 ] ) ) {
tmp [ 20 ] = list_head ( tmp [ 19 ] ) ;
if ( term_equal ( tmp [ 20 ] , make_char ( 112 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 19 ] ) ;
{
if ( not_empty_list ( tmp [ 21 ] ) ) {
tmp [ 22 ] = list_head ( tmp [ 21 ] ) ;
if ( term_equal ( tmp [ 22 ] , make_char ( 111 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
{
if ( not_empty_list ( tmp [ 23 ] ) ) {
tmp [ 24 ] = list_head ( tmp [ 23 ] ) ;
if ( term_equal ( tmp [ 24 ] , make_char ( 114 ) ) ) {
tmp [ 25 ] = list_tail ( tmp [ 23 ] ) ;
{
if ( not_empty_list ( tmp [ 25 ] ) ) {
tmp [ 26 ] = list_head ( tmp [ 25 ] ) ;
if ( term_equal ( tmp [ 26 ] , make_char ( 116 ) ) ) {
tmp [ 27 ] = list_tail ( tmp [ 25 ] ) ;
{
if ( not_empty_list ( tmp [ 27 ] ) ) {
tmp [ 28 ] = list_head ( tmp [ 27 ] ) ;
if ( term_equal ( tmp [ 28 ] , make_char ( 115 ) ) ) {
tmp [ 29 ] = list_tail ( tmp [ 27 ] ) ;
{
if ( is_single_element ( tmp [ 29 ] ) ) {
tmp [ 30 ] = list_head ( tmp [ 29 ] ) ;
if ( term_equal ( tmp [ 30 ] , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 31 ] = list_head ( atmp10 ) ;
{
tmp [ 32 ] = list_tail ( atmp10 ) ;
{
if ( is_single_element ( tmp [ 32 ] ) ) {
tmp [ 33 ] = list_head ( tmp [ 32 ] ) ;
{
if ( check_sym ( tmp [ 31 ] , ef4sym ) ) {
tmp [ 34 ] = arg_0 ( tmp [ 31 ] ) ;
tmp [ 35 ] = ( * ef9 ) ( tmp [ 33 ] ) ;
if ( ! term_equal ( tmp [ 35 ] , make_nf1 ( ef1sym , make_nf0 ( ef24sym ) ) ) ) {
FUNC_EXIT ( tmp [ 33 ] ) ;
}
else {
tmp [ 36 ] = ( * ef25 ) ( tmp [ 33 ] , ( constant0 ? constant0 : ( constant0 = lf4 ( make_list ( make_nf0 ( ef23sym ) ) ) ) ) ) ;
if ( check_sym ( tmp [ 36 ] , ef4sym ) ) {
tmp [ 37 ] = arg_0 ( tmp [ 36 ] ) ;
tmp [ 38 ] = ( * ef26 ) ( tmp [ 37 ] , tmp [ 34 ] ) ;
FUNC_EXIT ( ( * ef22 ) ( tmp [ 33 ] , lf4 ( make_list ( make_nf0 ( ef23sym ) ) ) , make_nf1 ( ef4sym , tmp [ 38 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 4 ] , make_char ( 110 ) ) ) {
tmp [ 5 ] = list_tail ( tmp [ 3 ] ) ;
if ( not_empty_list ( tmp [ 5 ] ) ) {
if ( term_equal ( list_head ( tmp [ 5 ] ) , make_char ( 105 ) ) ) {
tmp [ 6 ] = list_tail ( tmp [ 5 ] ) ;
if ( not_empty_list ( tmp [ 6 ] ) ) {
if ( term_equal ( list_head ( tmp [ 6 ] ) , make_char ( 102 ) ) ) {
tmp [ 7 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 7 ] ) ) {
if ( term_equal ( list_head ( tmp [ 7 ] ) , make_char ( 121 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 7 ] ) ;
if ( is_single_element ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 9 ] = list_head ( atmp10 ) ;
tmp [ 10 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 10 ] ) ) {
tmp [ 11 ] = list_head ( tmp [ 10 ] ) ;
if ( check_sym ( tmp [ 9 ] , ef4sym ) ) {
tmp [ 12 ] = arg_0 ( tmp [ 9 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef5 ) ( ( * ef27 ) ( tmp [ 12 ] , tmp [ 11 ] ) , tmp [ 12 ] , ( * ef28 ) ( tmp [ 11 ] , tmp [ 12 ] ) ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 3 ] = make_char ( 114 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 3 ] ) ) {
tmp [ 4 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 4 ] ) ) {
tmp [ 5 ] = list_head ( tmp [ 4 ] ) ;
if ( term_equal ( tmp [ 5 ] , make_char ( 101 ) ) ) {
tmp [ 6 ] = list_tail ( tmp [ 4 ] ) ;
{
if ( not_empty_list ( tmp [ 6 ] ) ) {
tmp [ 7 ] = list_head ( tmp [ 6 ] ) ;
if ( term_equal ( tmp [ 7 ] , make_char ( 110 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 6 ] ) ;
{
if ( not_empty_list ( tmp [ 8 ] ) ) {
tmp [ 9 ] = list_head ( tmp [ 8 ] ) ;
if ( term_equal ( tmp [ 9 ] , make_char ( 97 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 8 ] ) ;
{
if ( not_empty_list ( tmp [ 10 ] ) ) {
tmp [ 11 ] = list_head ( tmp [ 10 ] ) ;
if ( term_equal ( tmp [ 11 ] , make_char ( 109 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 10 ] ) ;
{
if ( not_empty_list ( tmp [ 12 ] ) ) {
tmp [ 13 ] = list_head ( tmp [ 12 ] ) ;
if ( term_equal ( tmp [ 13 ] , make_char ( 101 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 12 ] ) ;
{
if ( not_empty_list ( tmp [ 14 ] ) ) {
tmp [ 15 ] = list_head ( tmp [ 14 ] ) ;
if ( term_equal ( tmp [ 15 ] , make_char ( 45 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 14 ] ) ;
{
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
if ( term_equal ( tmp [ 17 ] , make_char ( 115 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
{
if ( not_empty_list ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 111 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 18 ] ) ;
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 114 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 116 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( is_single_element ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 22 ] = list_head ( atmp10 ) ;
tmp [ 23 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
tmp [ 24 ] = list_head ( tmp [ 23 ] ) ;
tmp [ 25 ] = list_tail ( tmp [ 23 ] ) ;
if ( is_single_element ( tmp [ 25 ] ) ) {
tmp [ 26 ] = list_head ( tmp [ 25 ] ) ;
if ( check_sym ( tmp [ 22 ] , ef4sym ) ) {
tmp [ 27 ] = arg_0 ( tmp [ 22 ] ) ;
FUNC_EXIT ( ( * ef29 ) ( tmp [ 27 ] , tmp [ 24 ] , tmp [ 26 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
{
if ( is_single_element ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( term_equal ( tmp [ 19 ] , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 20 ] = list_head ( atmp10 ) ;
{
tmp [ 21 ] = list_tail ( atmp10 ) ;
{
if ( not_empty_list ( tmp [ 21 ] ) ) {
tmp [ 22 ] = list_head ( tmp [ 21 ] ) ;
{
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
{
if ( is_single_element ( tmp [ 23 ] ) ) {
tmp [ 24 ] = list_head ( tmp [ 23 ] ) ;
{
if ( check_sym ( tmp [ 20 ] , ef4sym ) ) {
tmp [ 25 ] = arg_0 ( tmp [ 20 ] ) ;
tmp [ 26 ] = ( * ef9 ) ( tmp [ 24 ] ) ;
if ( term_equal ( tmp [ 26 ] , ( constant1 ? constant1 : ( constant1 = make_nf1 ( ef1sym , make_nf0 ( ef30sym ) ) ) ) ) ) {
tmp [ 27 ] = ( * ef31 ) ( tmp [ 24 ] , tmp [ 25 ] ) ;
if ( check_sym ( tmp [ 27 ] , ef35sym ) ) {
tmp [ 28 ] = arg_0 ( tmp [ 27 ] ) ;
tmp [ 29 ] = arg_1 ( tmp [ 27 ] ) ;
if ( check_sym ( tmp [ 28 ] , ef7sym ) ) {
tmp [ 30 ] = arg_0 ( tmp [ 28 ] ) ;
if ( check_sym ( tmp [ 30 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
tmp [ 31 ] = arg_0 ( tmp [ 30 ] ) ;
if ( check_sym ( tmp [ 29 ] , ef34sym ) ) {
tmp [ 32 ] = arg_0 ( tmp [ 29 ] ) ;
if ( check_sym ( tmp [ 32 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
tmp [ 33 ] = arg_0 ( tmp [ 32 ] ) ;
if ( not_empty_list ( tmp [ 31 ] ) ) {
tmp [ 34 ] = list_head ( tmp [ 31 ] ) ;
tmp [ 35 ] = list_tail ( tmp [ 31 ] ) ;
if ( is_single_element ( tmp [ 35 ] ) ) {
tmp [ 36 ] = list_head ( tmp [ 35 ] ) ;
if ( is_single_element ( tmp [ 33 ] ) ) {
tmp [ 37 ] = list_head ( tmp [ 33 ] ) ;
FUNC_EXIT ( make_nf3 ( ef32sym , make_nf0 ( ef10sym ) , make_nf1 ( ef33sym , lf_AUX_ATerm_Operations13_1 ( make_list ( make_nf1 ( ef1sym , make_nf1 ( ef2sym , ( * ef3 ) ( lf3 ( ( ATerm ) ATmakeList ( 2 , char_table [ 34 ] , char_table [ 34 ] ) ) ) ) ) ) ) ) , make_nf1 ( ef34sym , lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 37 ] ) ) ) ) ) ;
}
}
}
}
}
}
}
}
if ( check_sym ( tmp [ 27 ] , ef4sym ) ) {
tmp [ 28 ] = arg_0 ( tmp [ 27 ] ) ;
if ( check_sym ( tmp [ 28 ] , ef7sym ) ) {
tmp [ 29 ] = arg_0 ( tmp [ 28 ] ) ;
if ( check_sym ( tmp [ 29 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
tmp [ 30 ] = arg_0 ( tmp [ 29 ] ) ;
if ( not_empty_list ( tmp [ 30 ] ) ) {
tmp [ 31 ] = list_head ( tmp [ 30 ] ) ;
tmp [ 32 ] = list_tail ( tmp [ 30 ] ) ;
if ( is_single_element ( tmp [ 32 ] ) ) {
tmp [ 33 ] = list_head ( tmp [ 32 ] ) ;
FUNC_EXIT ( tmp [ 33 ] ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 17 ] , make_char ( 97 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
if ( not_empty_list ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 116 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 18 ] ) ;
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 101 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 114 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 109 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 21 ] ) ;
if ( is_single_element ( tmp [ 22 ] ) ) {
if ( term_equal ( list_head ( tmp [ 22 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 23 ] = list_head ( atmp10 ) ;
tmp [ 24 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 24 ] ) ) {
tmp [ 25 ] = list_head ( tmp [ 24 ] ) ;
tmp [ 26 ] = list_tail ( tmp [ 24 ] ) ;
if ( is_single_element ( tmp [ 26 ] ) ) {
tmp [ 27 ] = list_head ( tmp [ 26 ] ) ;
if ( check_sym ( tmp [ 23 ] , ef4sym ) ) {
tmp [ 28 ] = arg_0 ( tmp [ 23 ] ) ;
FUNC_EXIT ( ( * ef36 ) ( tmp [ 28 ] , tmp [ 25 ] , tmp [ 27 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 18 ] = make_char ( 112 ) ;
if ( term_equal ( tmp [ 17 ] , tmp [ 18 ] ) ) {
tmp [ 19 ] = list_tail ( tmp [ 16 ] ) ;
{
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 114 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 111 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 100 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 21 ] ) ;
if ( is_single_element ( tmp [ 22 ] ) ) {
if ( term_equal ( list_head ( tmp [ 22 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 23 ] = list_head ( atmp10 ) ;
tmp [ 24 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 24 ] ) ) {
tmp [ 25 ] = list_head ( tmp [ 24 ] ) ;
tmp [ 26 ] = list_tail ( tmp [ 24 ] ) ;
if ( is_single_element ( tmp [ 26 ] ) ) {
tmp [ 27 ] = list_head ( tmp [ 26 ] ) ;
if ( check_sym ( tmp [ 23 ] , ef4sym ) ) {
tmp [ 28 ] = arg_0 ( tmp [ 23 ] ) ;
FUNC_EXIT ( ( * ef15 ) ( tmp [ 28 ] , tmp [ 25 ] , tmp [ 27 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
{
if ( is_single_element ( tmp [ 19 ] ) ) {
tmp [ 20 ] = list_head ( tmp [ 19 ] ) ;
if ( term_equal ( tmp [ 20 ] , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 21 ] = list_head ( atmp10 ) ;
{
tmp [ 22 ] = list_tail ( atmp10 ) ;
{
if ( not_empty_list ( tmp [ 22 ] ) ) {
tmp [ 23 ] = list_head ( tmp [ 22 ] ) ;
{
tmp [ 24 ] = list_tail ( tmp [ 22 ] ) ;
{
if ( is_single_element ( tmp [ 24 ] ) ) {
tmp [ 25 ] = list_head ( tmp [ 24 ] ) ;
{
if ( check_sym ( tmp [ 21 ] , ef4sym ) ) {
tmp [ 26 ] = arg_0 ( tmp [ 21 ] ) ;
tmp [ 27 ] = ( * ef9 ) ( tmp [ 25 ] ) ;
if ( ! term_equal ( tmp [ 27 ] , make_nf1 ( ef1sym , make_nf0 ( ef20sym ) ) ) ) {
FUNC_EXIT ( ( * ef21 ) ( tmp [ 26 ] , tmp [ 23 ] , tmp [ 25 ] ) ) ;
}
else {
tmp [ 28 ] = ( * ef21 ) ( tmp [ 26 ] , tmp [ 23 ] , tmp [ 25 ] ) ;
FUNC_EXIT ( ( * ef16 ) ( ( * ef6 ) ( ( * ef17 ) ( tmp [ 28 ] ) ) , tmp [ 28 ] , ( * ef18 ) ( make_nf2 ( ef19sym , make_nf0 ( ef10sym ) , lf_AUX_ATerm_Operations13_1 ( make_list ( make_nf1 ( ef1sym , make_nf1 ( ef2sym , ( * ef3 ) ( lf3 ( ( ATerm ) ATmakeList ( 2 , char_table [ 34 ] , char_table [ 34 ] ) ) ) ) ) ) ) ) , ( * ef17 ) ( tmp [ 28 ] ) ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( is_single_element ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 15 ] = list_head ( atmp10 ) ;
tmp [ 16 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( check_sym ( tmp [ 15 ] , ef4sym ) ) {
tmp [ 20 ] = arg_0 ( tmp [ 15 ] ) ;
FUNC_EXIT ( ( * ef21 ) ( tmp [ 20 ] , tmp [ 17 ] , tmp [ 19 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 8 ] = make_char ( 109 ) ;
if ( term_equal ( tmp [ 7 ] , tmp [ 8 ] ) ) {
tmp [ 9 ] = list_tail ( tmp [ 6 ] ) ;
{
if ( not_empty_list ( tmp [ 9 ] ) ) {
tmp [ 10 ] = list_head ( tmp [ 9 ] ) ;
if ( term_equal ( tmp [ 10 ] , make_char ( 111 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 9 ] ) ;
{
if ( not_empty_list ( tmp [ 11 ] ) ) {
tmp [ 12 ] = list_head ( tmp [ 11 ] ) ;
if ( term_equal ( tmp [ 12 ] , make_char ( 118 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 11 ] ) ;
{
if ( not_empty_list ( tmp [ 13 ] ) ) {
tmp [ 14 ] = list_head ( tmp [ 13 ] ) ;
if ( term_equal ( tmp [ 14 ] , make_char ( 101 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 13 ] ) ;
{
if ( not_empty_list ( tmp [ 15 ] ) ) {
tmp [ 16 ] = list_head ( tmp [ 15 ] ) ;
if ( term_equal ( tmp [ 16 ] , make_char ( 45 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 15 ] ) ;
{
if ( not_empty_list ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
if ( term_equal ( tmp [ 18 ] , make_char ( 97 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 17 ] ) ;
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 110 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 110 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 111 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 21 ] ) ;
if ( not_empty_list ( tmp [ 22 ] ) ) {
if ( term_equal ( list_head ( tmp [ 22 ] ) , make_char ( 116 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 22 ] ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 97 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 23 ] ) ;
if ( not_empty_list ( tmp [ 24 ] ) ) {
if ( term_equal ( list_head ( tmp [ 24 ] ) , make_char ( 116 ) ) ) {
tmp [ 25 ] = list_tail ( tmp [ 24 ] ) ;
if ( not_empty_list ( tmp [ 25 ] ) ) {
if ( term_equal ( list_head ( tmp [ 25 ] ) , make_char ( 105 ) ) ) {
tmp [ 26 ] = list_tail ( tmp [ 25 ] ) ;
if ( not_empty_list ( tmp [ 26 ] ) ) {
if ( term_equal ( list_head ( tmp [ 26 ] ) , make_char ( 111 ) ) ) {
tmp [ 27 ] = list_tail ( tmp [ 26 ] ) ;
if ( not_empty_list ( tmp [ 27 ] ) ) {
if ( term_equal ( list_head ( tmp [ 27 ] ) , make_char ( 110 ) ) ) {
tmp [ 28 ] = list_tail ( tmp [ 27 ] ) ;
if ( not_empty_list ( tmp [ 28 ] ) ) {
if ( term_equal ( list_head ( tmp [ 28 ] ) , make_char ( 115 ) ) ) {
tmp [ 29 ] = list_tail ( tmp [ 28 ] ) ;
if ( is_single_element ( tmp [ 29 ] ) ) {
if ( term_equal ( list_head ( tmp [ 29 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 30 ] = list_head ( atmp10 ) ;
FUNC_EXIT ( ( * ef39 ) ( tmp [ 30 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 18 ] , make_char ( 101 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 17 ] ) ;
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 109 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 112 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 116 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 21 ] ) ;
if ( not_empty_list ( tmp [ 22 ] ) ) {
if ( term_equal ( list_head ( tmp [ 22 ] ) , make_char ( 121 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 22 ] ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 45 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 23 ] ) ;
if ( not_empty_list ( tmp [ 24 ] ) ) {
if ( term_equal ( list_head ( tmp [ 24 ] ) , make_char ( 103 ) ) ) {
tmp [ 25 ] = list_tail ( tmp [ 24 ] ) ;
if ( not_empty_list ( tmp [ 25 ] ) ) {
if ( term_equal ( list_head ( tmp [ 25 ] ) , make_char ( 114 ) ) ) {
tmp [ 26 ] = list_tail ( tmp [ 25 ] ) ;
if ( not_empty_list ( tmp [ 26 ] ) ) {
if ( term_equal ( list_head ( tmp [ 26 ] ) , make_char ( 97 ) ) ) {
tmp [ 27 ] = list_tail ( tmp [ 26 ] ) ;
if ( not_empty_list ( tmp [ 27 ] ) ) {
if ( term_equal ( list_head ( tmp [ 27 ] ) , make_char ( 109 ) ) ) {
tmp [ 28 ] = list_tail ( tmp [ 27 ] ) ;
if ( not_empty_list ( tmp [ 28 ] ) ) {
if ( term_equal ( list_head ( tmp [ 28 ] ) , make_char ( 109 ) ) ) {
tmp [ 29 ] = list_tail ( tmp [ 28 ] ) ;
if ( not_empty_list ( tmp [ 29 ] ) ) {
if ( term_equal ( list_head ( tmp [ 29 ] ) , make_char ( 97 ) ) ) {
tmp [ 30 ] = list_tail ( tmp [ 29 ] ) ;
if ( not_empty_list ( tmp [ 30 ] ) ) {
if ( term_equal ( list_head ( tmp [ 30 ] ) , make_char ( 114 ) ) ) {
tmp [ 31 ] = list_tail ( tmp [ 30 ] ) ;
if ( not_empty_list ( tmp [ 31 ] ) ) {
if ( term_equal ( list_head ( tmp [ 31 ] ) , make_char ( 115 ) ) ) {
tmp [ 32 ] = list_tail ( tmp [ 31 ] ) ;
if ( is_single_element ( tmp [ 32 ] ) ) {
if ( term_equal ( list_head ( tmp [ 32 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 33 ] = list_head ( atmp10 ) ;
if ( term_equal ( ( * ef12 ) ( ( * ef13 ) ( ( * ef9 ) ( tmp [ 33 ] ) , ( constant2 ? constant2 : ( constant2 = make_nf1 ( ef1sym , make_nf0 ( ef37sym ) ) ) ) ) , ( * ef13 ) ( ( * ef9 ) ( tmp [ 33 ] ) , ( constant3 ? constant3 : ( constant3 = make_nf1 ( ef1sym , make_nf0 ( ef38sym ) ) ) ) ) ) , ( constant4 ? constant4 : ( constant4 = make_nf0 ( ef14sym ) ) ) ) ) {
tmp [ 34 ] = ( * ef39 ) ( ( * ef25 ) ( tmp [ 33 ] , ( constant5 ? constant5 : ( constant5 = lf4 ( make_list ( make_nf0 ( ef40sym ) ) ) ) ) ) ) ;
if ( check_sym ( tmp [ 34 ] , ef4sym ) ) {
tmp [ 35 ] = arg_0 ( tmp [ 34 ] ) ;
if ( term_equal ( ( * ef41 ) ( tmp [ 35 ] ) , ( constant4 ? constant4 : ( constant4 = make_nf0 ( ef14sym ) ) ) ) ) {
FUNC_EXIT_CONST ( constant6 , make_nf2 ( ef19sym , make_nf0 ( ef10sym ) , lf_AUX_ATerm_Operations13_1 ( make_list ( make_nf1 ( ef1sym , make_nf1 ( ef2sym , ( * ef3 ) ( lf3 ( ( ATerm ) ATmakeList ( 2 , char_table [ 34 ] , char_table [ 34 ] ) ) ) ) ) ) ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 7 ] , make_char ( 115 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 116 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 102 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( is_single_element ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 12 ] = list_head ( atmp10 ) ;
if ( check_sym ( tmp [ 12 ] , ef4sym ) ) {
tmp [ 13 ] = arg_0 ( tmp [ 12 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef53 ) ( tmp [ 13 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 7 ] , make_char ( 112 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 108 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 97 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 99 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 101 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 102 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( is_single_element ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 15 ] = list_head ( atmp10 ) ;
tmp [ 16 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( check_sym ( tmp [ 15 ] , ef4sym ) ) {
tmp [ 20 ] = arg_0 ( tmp [ 15 ] ) ;
if ( check_sym ( tmp [ 17 ] , ef54sym ) ) {
tmp [ 21 ] = arg_0 ( tmp [ 17 ] ) ;
if ( check_sym ( tmp [ 21 ] , ef55sym ) ) {
tmp [ 22 ] = arg_0 ( tmp [ 21 ] ) ;
if ( check_sym ( tmp [ 22 ] , ef57sym ) ) {
tmp [ 23 ] = arg_0 ( tmp [ 22 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef60 ) ( tmp [ 20 ] , make_nf1 ( ef59sym , make_nf1 ( ef57sym , tmp [ 23 ] ) ) , tmp [ 19 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 4 ] = make_char ( 109 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 4 ] ) ) {
tmp [ 5 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 5 ] ) ) {
tmp [ 6 ] = list_head ( tmp [ 5 ] ) ;
if ( term_equal ( tmp [ 6 ] , make_char ( 97 ) ) ) {
tmp [ 7 ] = list_tail ( tmp [ 5 ] ) ;
if ( not_empty_list ( tmp [ 7 ] ) ) {
if ( term_equal ( list_head ( tmp [ 7 ] ) , make_char ( 112 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 7 ] ) ;
if ( not_empty_list ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 102 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 8 ] ) ;
if ( is_single_element ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 10 ] = list_head ( atmp10 ) ;
tmp [ 11 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 11 ] ) ) {
tmp [ 12 ] = list_head ( tmp [ 11 ] ) ;
if ( check_sym ( tmp [ 12 ] , ef4sym ) ) {
tmp [ 13 ] = arg_0 ( tmp [ 12 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef63 ) ( tmp [ 10 ] , tmp [ 13 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
tmp [ 7 ] = make_char ( 111 ) ;
if ( term_equal ( tmp [ 6 ] , tmp [ 7 ] ) ) {
tmp [ 8 ] = list_tail ( tmp [ 5 ] ) ;
{
if ( not_empty_list ( tmp [ 8 ] ) ) {
tmp [ 9 ] = list_head ( tmp [ 8 ] ) ;
if ( term_equal ( tmp [ 9 ] , make_char ( 100 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 8 ] ) ;
{
if ( not_empty_list ( tmp [ 10 ] ) ) {
tmp [ 11 ] = list_head ( tmp [ 10 ] ) ;
if ( term_equal ( tmp [ 11 ] , make_char ( 117 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 10 ] ) ;
{
if ( not_empty_list ( tmp [ 12 ] ) ) {
tmp [ 13 ] = list_head ( tmp [ 12 ] ) ;
if ( term_equal ( tmp [ 13 ] , make_char ( 108 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 12 ] ) ;
{
if ( not_empty_list ( tmp [ 14 ] ) ) {
tmp [ 15 ] = list_head ( tmp [ 14 ] ) ;
if ( term_equal ( tmp [ 15 ] , make_char ( 101 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 14 ] ) ;
{
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
if ( term_equal ( tmp [ 17 ] , make_char ( 78 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
{
if ( not_empty_list ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( term_equal ( tmp [ 19 ] , make_char ( 97 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 18 ] ) ;
{
if ( not_empty_list ( tmp [ 20 ] ) ) {
tmp [ 21 ] = list_head ( tmp [ 20 ] ) ;
if ( term_equal ( tmp [ 21 ] , make_char ( 109 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 20 ] ) ;
{
if ( not_empty_list ( tmp [ 22 ] ) ) {
tmp [ 23 ] = list_head ( tmp [ 22 ] ) ;
if ( term_equal ( tmp [ 23 ] , make_char ( 101 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 22 ] ) ;
{
if ( is_single_element ( tmp [ 24 ] ) ) {
tmp [ 25 ] = list_head ( tmp [ 24 ] ) ;
if ( term_equal ( tmp [ 25 ] , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 26 ] = list_head ( atmp10 ) ;
{
tmp [ 27 ] = list_tail ( atmp10 ) ;
{
if ( is_single_element ( tmp [ 27 ] ) ) {
tmp [ 28 ] = list_head ( tmp [ 27 ] ) ;
{
if ( check_sym ( tmp [ 26 ] , ef4sym ) ) {
tmp [ 29 ] = arg_0 ( tmp [ 26 ] ) ;
tmp [ 30 ] = ( * ef42 ) ( make_nf2 ( ef19sym , ( constant7 ? constant7 : ( constant7 = make_nf1 ( ef2sym , ( * ef3 ) ( lf3 ( cons ( make_list ( make_char ( 34 ) ) , cons ( make_list ( make_char ( 109 ) ) , cons ( make_list ( make_char ( 97 ) ) , cons ( make_list ( make_char ( 116 ) ) , cons ( make_list ( make_char ( 99 ) ) , cons ( make_list ( make_char ( 104 ) ) , cons ( make_list ( make_char ( 105 ) ) , cons ( make_list ( make_char ( 110 ) ) , cons ( make_list ( make_char ( 103 ) ) , cons ( make_list ( make_char ( 77 ) ) , cons ( make_list ( make_char ( 111 ) ) , cons ( make_list ( make_char ( 100 ) ) , cons ( make_list ( make_char ( 117 ) ) , cons ( make_list ( make_char ( 108 ) ) , cons ( make_list ( make_char ( 101 ) ) , cons ( make_list ( make_char ( 78 ) ) , cons ( make_list ( make_char ( 97 ) ) , cons ( make_list ( make_char ( 109 ) ) , cons ( make_list ( make_char ( 101 ) ) , make_list ( make_char ( 34 ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) ) , lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 28 ] ) ) ) , tmp [ 29 ] ) ;
if ( check_sym ( tmp [ 30 ] , ef7sym ) ) {
tmp [ 31 ] = arg_0 ( tmp [ 30 ] ) ;
if ( check_sym ( tmp [ 31 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
tmp [ 32 ] = arg_0 ( tmp [ 31 ] ) ;
if ( is_single_element ( tmp [ 32 ] ) ) {
tmp [ 33 ] = list_head ( tmp [ 32 ] ) ;
if ( check_sym ( tmp [ 33 ] , ef4sym ) ) {
tmp [ 34 ] = arg_0 ( tmp [ 33 ] ) ;
if ( check_sym ( tmp [ 34 ] , ef7sym ) ) {
tmp [ 35 ] = arg_0 ( tmp [ 34 ] ) ;
if ( check_sym ( tmp [ 35 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
tmp [ 36 ] = arg_0 ( tmp [ 35 ] ) ;
if ( not_empty_list ( tmp [ 36 ] ) ) {
tmp [ 37 ] = list_head ( tmp [ 36 ] ) ;
tmp [ 38 ] = list_tail ( tmp [ 36 ] ) ;
if ( is_single_element ( tmp [ 38 ] ) ) {
tmp [ 39 ] = list_head ( tmp [ 38 ] ) ;
FUNC_EXIT ( ( * ef43 ) ( tmp [ 37 ] , tmp [ 39 ] ) ) ;
}
}
}
}
}
}
}
}
if ( term_equal ( ( * ef6 ) ( tmp [ 30 ] ) , ( constant4 ? constant4 : ( constant4 = make_nf0 ( ef14sym ) ) ) ) ) {
FUNC_EXIT ( tmp [ 28 ] ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 5 ] = make_char ( 115 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 5 ] ) ) {
tmp [ 6 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 6 ] ) ) {
tmp [ 7 ] = list_head ( tmp [ 6 ] ) ;
if ( term_equal ( tmp [ 7 ] , make_char ( 105 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 122 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 8 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 101 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 102 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( is_single_element ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 12 ] = list_head ( atmp10 ) ;
if ( check_sym ( tmp [ 12 ] , ef4sym ) ) {
tmp [ 13 ] = arg_0 ( tmp [ 12 ] ) ;
FUNC_EXIT ( make_nf1 ( ef54sym , make_nf1 ( ef55sym , ( * ef56 ) ( tmp [ 13 ] ) ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 7 ] , make_char ( 101 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 108 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 8 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 101 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 99 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 116 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 45 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 97 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 110 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 110 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 111 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 16 ] ) ;
if ( not_empty_list ( tmp [ 17 ] ) ) {
if ( term_equal ( list_head ( tmp [ 17 ] ) , make_char ( 116 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 17 ] ) ;
if ( not_empty_list ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 97 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 18 ] ) ;
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 116 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 105 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 111 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 21 ] ) ;
if ( not_empty_list ( tmp [ 22 ] ) ) {
if ( term_equal ( list_head ( tmp [ 22 ] ) , make_char ( 110 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 22 ] ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 115 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 23 ] ) ;
if ( is_single_element ( tmp [ 24 ] ) ) {
if ( term_equal ( list_head ( tmp [ 24 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 25 ] = list_head ( atmp10 ) ;
tmp [ 26 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 26 ] ) ) {
tmp [ 27 ] = list_head ( tmp [ 26 ] ) ;
if ( check_sym ( tmp [ 25 ] , ef4sym ) ) {
tmp [ 28 ] = arg_0 ( tmp [ 25 ] ) ;
tmp [ 29 ] = ( * ef17 ) ( tmp [ 27 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef8 ) ( tmp [ 28 ] , tmp [ 29 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 7 ] , make_char ( 117 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 98 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 8 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 116 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 101 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 114 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 109 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 115 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 102 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( is_single_element ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 16 ] = list_head ( atmp10 ) ;
tmp [ 17 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef45 ) ( tmp [ 16 ] , tmp [ 18 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 6 ] = make_char ( 116 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 6 ] ) ) {
tmp [ 7 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 7 ] ) ) {
tmp [ 8 ] = list_head ( tmp [ 7 ] ) ;
if ( term_equal ( tmp [ 8 ] , make_char ( 114 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 7 ] ) ;
{
if ( not_empty_list ( tmp [ 9 ] ) ) {
tmp [ 10 ] = list_head ( tmp [ 9 ] ) ;
if ( term_equal ( tmp [ 10 ] , make_char ( 101 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 9 ] ) ;
{
if ( not_empty_list ( tmp [ 11 ] ) ) {
tmp [ 12 ] = list_head ( tmp [ 11 ] ) ;
if ( term_equal ( tmp [ 12 ] , make_char ( 112 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 11 ] ) ;
{
if ( not_empty_list ( tmp [ 13 ] ) ) {
tmp [ 14 ] = list_head ( tmp [ 13 ] ) ;
if ( term_equal ( tmp [ 14 ] , make_char ( 108 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 13 ] ) ;
{
if ( not_empty_list ( tmp [ 15 ] ) ) {
tmp [ 16 ] = list_head ( tmp [ 15 ] ) ;
if ( term_equal ( tmp [ 16 ] , make_char ( 97 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 15 ] ) ;
{
if ( not_empty_list ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
if ( term_equal ( tmp [ 18 ] , make_char ( 99 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 17 ] ) ;
{
if ( not_empty_list ( tmp [ 19 ] ) ) {
tmp [ 20 ] = list_head ( tmp [ 19 ] ) ;
if ( term_equal ( tmp [ 20 ] , make_char ( 101 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 19 ] ) ;
{
if ( not_empty_list ( tmp [ 21 ] ) ) {
tmp [ 22 ] = list_head ( tmp [ 21 ] ) ;
if ( term_equal ( tmp [ 22 ] , make_char ( 45 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 97 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 23 ] ) ;
if ( not_empty_list ( tmp [ 24 ] ) ) {
if ( term_equal ( list_head ( tmp [ 24 ] ) , make_char ( 110 ) ) ) {
tmp [ 25 ] = list_tail ( tmp [ 24 ] ) ;
if ( not_empty_list ( tmp [ 25 ] ) ) {
if ( term_equal ( list_head ( tmp [ 25 ] ) , make_char ( 110 ) ) ) {
tmp [ 26 ] = list_tail ( tmp [ 25 ] ) ;
if ( is_single_element ( tmp [ 26 ] ) ) {
if ( term_equal ( list_head ( tmp [ 26 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 27 ] = list_head ( atmp10 ) ;
tmp [ 28 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 28 ] ) ) {
tmp [ 29 ] = list_head ( tmp [ 28 ] ) ;
tmp [ 30 ] = list_tail ( tmp [ 28 ] ) ;
if ( is_single_element ( tmp [ 30 ] ) ) {
tmp [ 31 ] = list_head ( tmp [ 30 ] ) ;
FUNC_EXIT ( ( * ef44 ) ( tmp [ 27 ] , tmp [ 29 ] , tmp [ 31 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 22 ] , make_char ( 102 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
if ( is_single_element ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 24 ] = list_head ( atmp10 ) ;
tmp [ 25 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 25 ] ) ) {
tmp [ 26 ] = list_head ( tmp [ 25 ] ) ;
tmp [ 27 ] = list_tail ( tmp [ 25 ] ) ;
if ( is_single_element ( tmp [ 27 ] ) ) {
tmp [ 28 ] = list_head ( tmp [ 27 ] ) ;
FUNC_EXIT ( ( * ef46 ) ( tmp [ 24 ] , tmp [ 26 ] , tmp [ 28 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 8 ] , make_char ( 109 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 7 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 97 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 112 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 102 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( is_single_element ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 13 ] = list_head ( atmp10 ) ;
tmp [ 14 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 14 ] ) ) {
tmp [ 15 ] = list_head ( tmp [ 14 ] ) ;
FUNC_EXIT ( ( * ef47 ) ( tmp [ 13 ] , tmp [ 15 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 8 ] , make_char ( 101 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 7 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 114 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 109 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 102 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( is_single_element ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 13 ] = list_head ( atmp10 ) ;
FUNC_EXIT ( ( * ef39 ) ( tmp [ 13 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 7 ] = make_char ( 99 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 7 ] ) ) {
tmp [ 8 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 8 ] ) ) {
tmp [ 9 ] = list_head ( tmp [ 8 ] ) ;
if ( term_equal ( tmp [ 9 ] , make_char ( 111 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 8 ] ) ;
{
if ( not_empty_list ( tmp [ 10 ] ) ) {
tmp [ 11 ] = list_head ( tmp [ 10 ] ) ;
if ( term_equal ( tmp [ 11 ] , make_char ( 110 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 10 ] ) ;
{
if ( not_empty_list ( tmp [ 12 ] ) ) {
tmp [ 13 ] = list_head ( tmp [ 12 ] ) ;
if ( term_equal ( tmp [ 13 ] , make_char ( 99 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 12 ] ) ;
{
if ( not_empty_list ( tmp [ 14 ] ) ) {
tmp [ 15 ] = list_head ( tmp [ 14 ] ) ;
if ( term_equal ( tmp [ 15 ] , make_char ( 102 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 14 ] ) ;
if ( is_single_element ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 17 ] = list_head ( atmp10 ) ;
tmp [ 18 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( check_sym ( tmp [ 17 ] , ef4sym ) ) {
tmp [ 20 ] = arg_0 ( tmp [ 17 ] ) ;
if ( check_sym ( tmp [ 19 ] , ef4sym ) ) {
tmp [ 21 ] = arg_0 ( tmp [ 19 ] ) ;
tmp [ 22 ] = make_nf1 ( ef4sym , ( * ef8 ) ( tmp [ 20 ] , tmp [ 21 ] ) ) ;
FUNC_EXIT ( tmp [ 22 ] ) ;
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 15 ] , make_char ( 97 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 116 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 16 ] ) ;
if ( not_empty_list ( tmp [ 17 ] ) ) {
if ( term_equal ( list_head ( tmp [ 17 ] ) , make_char ( 102 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 17 ] ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 19 ] = list_head ( atmp10 ) ;
if ( check_sym ( tmp [ 19 ] , ef4sym ) ) {
tmp [ 20 ] = arg_0 ( tmp [ 19 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef51 ) ( tmp [ 20 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 13 ] , make_char ( 115 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 102 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( is_single_element ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 16 ] = list_head ( atmp10 ) ;
tmp [ 17 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
if ( check_sym ( tmp [ 18 ] , ef4sym ) ) {
tmp [ 19 ] = arg_0 ( tmp [ 18 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef28 ) ( tmp [ 16 ] , tmp [ 19 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 9 ] , make_char ( 112 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 8 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 117 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 116 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 102 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( is_single_element ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 14 ] = list_head ( atmp10 ) ;
tmp [ 15 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 15 ] ) ) {
tmp [ 16 ] = list_head ( tmp [ 15 ] ) ;
if ( check_sym ( tmp [ 14 ] , ef4sym ) ) {
tmp [ 17 ] = arg_0 ( tmp [ 14 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef71 ) ( tmp [ 17 ] , tmp [ 16 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 8 ] = make_char ( 102 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 8 ] ) ) {
tmp [ 9 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 9 ] ) ) {
tmp [ 10 ] = list_head ( tmp [ 9 ] ) ;
if ( term_equal ( tmp [ 10 ] , make_char ( 105 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 9 ] ) ;
{
if ( not_empty_list ( tmp [ 11 ] ) ) {
tmp [ 12 ] = list_head ( tmp [ 11 ] ) ;
if ( term_equal ( tmp [ 12 ] , make_char ( 108 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 116 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 101 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 114 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 102 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 16 ] ) ;
if ( is_single_element ( tmp [ 17 ] ) ) {
if ( term_equal ( list_head ( tmp [ 17 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 18 ] = list_head ( atmp10 ) ;
tmp [ 19 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 19 ] ) ) {
tmp [ 20 ] = list_head ( tmp [ 19 ] ) ;
if ( check_sym ( tmp [ 20 ] , ef4sym ) ) {
tmp [ 21 ] = arg_0 ( tmp [ 20 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef42 ) ( tmp [ 18 ] , tmp [ 21 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 12 ] , make_char ( 114 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 115 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 116 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 102 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( is_single_element ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 17 ] = list_head ( atmp10 ) ;
if ( check_sym ( tmp [ 17 ] , ef4sym ) ) {
tmp [ 18 ] = arg_0 ( tmp [ 17 ] ) ;
FUNC_EXIT ( ( * ef52 ) ( tmp [ 18 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 11 ] = make_char ( 111 ) ;
if ( term_equal ( tmp [ 10 ] , tmp [ 11 ] ) ) {
tmp [ 12 ] = list_tail ( tmp [ 9 ] ) ;
{
if ( not_empty_list ( tmp [ 12 ] ) ) {
tmp [ 13 ] = list_head ( tmp [ 12 ] ) ;
if ( term_equal ( tmp [ 13 ] , make_char ( 108 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 12 ] ) ;
{
if ( not_empty_list ( tmp [ 14 ] ) ) {
tmp [ 15 ] = list_head ( tmp [ 14 ] ) ;
if ( term_equal ( tmp [ 15 ] , make_char ( 100 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 14 ] ) ;
{
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
if ( term_equal ( tmp [ 17 ] , make_char ( 114 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
{
if ( not_empty_list ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( term_equal ( tmp [ 19 ] , make_char ( 45 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 18 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 122 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 105 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 21 ] ) ;
if ( not_empty_list ( tmp [ 22 ] ) ) {
if ( term_equal ( list_head ( tmp [ 22 ] ) , make_char ( 112 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 22 ] ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 102 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 23 ] ) ;
if ( is_single_element ( tmp [ 24 ] ) ) {
if ( term_equal ( list_head ( tmp [ 24 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 25 ] = list_head ( atmp10 ) ;
tmp [ 26 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 26 ] ) ) {
tmp [ 27 ] = list_head ( tmp [ 26 ] ) ;
tmp [ 28 ] = list_tail ( tmp [ 26 ] ) ;
if ( not_empty_list ( tmp [ 28 ] ) ) {
tmp [ 29 ] = list_head ( tmp [ 28 ] ) ;
tmp [ 30 ] = list_tail ( tmp [ 28 ] ) ;
if ( not_empty_list ( tmp [ 30 ] ) ) {
tmp [ 31 ] = list_head ( tmp [ 30 ] ) ;
tmp [ 32 ] = list_tail ( tmp [ 30 ] ) ;
if ( is_single_element ( tmp [ 32 ] ) ) {
tmp [ 33 ] = list_head ( tmp [ 32 ] ) ;
if ( check_sym ( tmp [ 31 ] , ef4sym ) ) {
tmp [ 34 ] = arg_0 ( tmp [ 31 ] ) ;
if ( check_sym ( tmp [ 33 ] , ef4sym ) ) {
tmp [ 35 ] = arg_0 ( tmp [ 33 ] ) ;
FUNC_EXIT ( ( * ef67 ) ( tmp [ 25 ] , tmp [ 27 ] , tmp [ 29 ] , tmp [ 34 ] , tmp [ 35 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 19 ] , make_char ( 102 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 18 ] ) ;
if ( is_single_element ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 21 ] = list_head ( atmp10 ) ;
tmp [ 22 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 22 ] ) ) {
tmp [ 23 ] = list_head ( tmp [ 22 ] ) ;
tmp [ 24 ] = list_tail ( tmp [ 22 ] ) ;
if ( is_single_element ( tmp [ 24 ] ) ) {
tmp [ 25 ] = list_head ( tmp [ 24 ] ) ;
if ( check_sym ( tmp [ 25 ] , ef4sym ) ) {
tmp [ 26 ] = arg_0 ( tmp [ 25 ] ) ;
FUNC_EXIT ( ( * ef65 ) ( tmp [ 21 ] , tmp [ 23 ] , tmp [ 26 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 17 ] , make_char ( 108 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
if ( not_empty_list ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 102 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 18 ] ) ;
if ( is_single_element ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 20 ] = list_head ( atmp10 ) ;
tmp [ 21 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 21 ] ) ) {
tmp [ 22 ] = list_head ( tmp [ 21 ] ) ;
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
if ( is_single_element ( tmp [ 23 ] ) ) {
tmp [ 24 ] = list_head ( tmp [ 23 ] ) ;
if ( check_sym ( tmp [ 24 ] , ef4sym ) ) {
tmp [ 25 ] = arg_0 ( tmp [ 24 ] ) ;
FUNC_EXIT ( ( * ef66 ) ( tmp [ 20 ] , tmp [ 22 ] , tmp [ 25 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 9 ] = make_char ( 105 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 9 ] ) ) {
tmp [ 10 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 10 ] ) ) {
tmp [ 11 ] = list_head ( tmp [ 10 ] ) ;
if ( term_equal ( tmp [ 11 ] , make_char ( 100 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 101 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 110 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 116 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 105 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 116 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 16 ] ) ;
if ( not_empty_list ( tmp [ 17 ] ) ) {
if ( term_equal ( list_head ( tmp [ 17 ] ) , make_char ( 121 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 17 ] ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 19 ] = list_head ( atmp10 ) ;
FUNC_EXIT ( tmp [ 19 ] ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 11 ] , make_char ( 110 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 100 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 101 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 120 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 102 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( is_single_element ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 17 ] = list_head ( atmp10 ) ;
tmp [ 18 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( check_sym ( tmp [ 17 ] , ef4sym ) ) {
tmp [ 20 ] = arg_0 ( tmp [ 17 ] ) ;
if ( check_sym ( tmp [ 19 ] , ef54sym ) ) {
tmp [ 21 ] = arg_0 ( tmp [ 19 ] ) ;
if ( check_sym ( tmp [ 21 ] , ef55sym ) ) {
tmp [ 22 ] = arg_0 ( tmp [ 21 ] ) ;
if ( check_sym ( tmp [ 22 ] , ef57sym ) ) {
tmp [ 23 ] = arg_0 ( tmp [ 22 ] ) ;
FUNC_EXIT ( ( * ef58 ) ( tmp [ 20 ] , make_nf1 ( ef59sym , make_nf1 ( ef57sym , tmp [ 23 ] ) ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 10 ] = make_char ( 100 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 10 ] ) ) {
tmp [ 11 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 11 ] ) ) {
tmp [ 12 ] = list_head ( tmp [ 11 ] ) ;
if ( term_equal ( tmp [ 12 ] , make_char ( 101 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 11 ] ) ;
{
if ( not_empty_list ( tmp [ 13 ] ) ) {
tmp [ 14 ] = list_head ( tmp [ 13 ] ) ;
if ( term_equal ( tmp [ 14 ] , make_char ( 108 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 13 ] ) ;
{
if ( not_empty_list ( tmp [ 15 ] ) ) {
tmp [ 16 ] = list_head ( tmp [ 15 ] ) ;
if ( term_equal ( tmp [ 16 ] , make_char ( 101 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 15 ] ) ;
{
if ( not_empty_list ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
if ( term_equal ( tmp [ 18 ] , make_char ( 116 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 17 ] ) ;
{
if ( not_empty_list ( tmp [ 19 ] ) ) {
tmp [ 20 ] = list_head ( tmp [ 19 ] ) ;
if ( term_equal ( tmp [ 20 ] , make_char ( 101 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 19 ] ) ;
{
if ( not_empty_list ( tmp [ 21 ] ) ) {
tmp [ 22 ] = list_head ( tmp [ 21 ] ) ;
if ( term_equal ( tmp [ 22 ] , make_char ( 102 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
if ( is_single_element ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 24 ] = list_head ( atmp10 ) ;
tmp [ 25 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 25 ] ) ) {
tmp [ 26 ] = list_head ( tmp [ 25 ] ) ;
if ( check_sym ( tmp [ 24 ] , ef4sym ) ) {
tmp [ 27 ] = arg_0 ( tmp [ 24 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef61 ) ( tmp [ 27 ] , tmp [ 26 ] ) ) ) ;
}
}
}
}
}
}
if ( term_equal ( tmp [ 22 ] , make_char ( 49 ) ) ) {
tmp [ 23 ] = list_tail ( tmp [ 21 ] ) ;
if ( not_empty_list ( tmp [ 23 ] ) ) {
if ( term_equal ( list_head ( tmp [ 23 ] ) , make_char ( 102 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 23 ] ) ;
if ( is_single_element ( tmp [ 24 ] ) ) {
if ( term_equal ( list_head ( tmp [ 24 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 25 ] = list_head ( atmp10 ) ;
tmp [ 26 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 26 ] ) ) {
tmp [ 27 ] = list_head ( tmp [ 26 ] ) ;
if ( check_sym ( tmp [ 25 ] , ef4sym ) ) {
tmp [ 28 ] = arg_0 ( tmp [ 25 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef62 ) ( tmp [ 28 ] , tmp [ 27 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 2 ] , make_char ( 122 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 105 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 112 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 102 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( is_single_element ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 15 ] = list_head ( atmp10 ) ;
tmp [ 16 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
if ( is_single_element ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( check_sym ( tmp [ 17 ] , ef4sym ) ) {
tmp [ 20 ] = arg_0 ( tmp [ 17 ] ) ;
if ( check_sym ( tmp [ 19 ] , ef4sym ) ) {
tmp [ 21 ] = arg_0 ( tmp [ 19 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef64 ) ( tmp [ 15 ] , tmp [ 20 ] , tmp [ 21 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 2 ] , make_char ( 97 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 112 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 112 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 108 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 121 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 102 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( is_single_element ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 17 ] = list_head ( atmp10 ) ;
tmp [ 18 ] = list_tail ( atmp10 ) ;
if ( not_empty_list ( tmp [ 18 ] ) ) {
arg0 = tmp [ 17 ] ;
arg1 = lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 18 ] ) ) ;
goto lbl_lf_AUX_ATerm_Operations13_2 ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 2 ] , make_char ( 103 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 101 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 116 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 102 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( is_single_element ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 15 ] = list_head ( atmp10 ) ;
tmp [ 16 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
if ( check_sym ( tmp [ 15 ] , ef4sym ) ) {
tmp [ 18 ] = arg_0 ( tmp [ 15 ] ) ;
FUNC_EXIT ( ( * ef68 ) ( tmp [ 18 ] , tmp [ 17 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 2 ] , make_char ( 101 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 103 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 101 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 116 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 102 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( is_single_element ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 16 ] = list_head ( atmp10 ) ;
tmp [ 17 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 17 ] ) ) {
tmp [ 18 ] = list_head ( tmp [ 17 ] ) ;
if ( check_sym ( tmp [ 16 ] , ef4sym ) ) {
tmp [ 19 ] = arg_0 ( tmp [ 16 ] ) ;
FUNC_EXIT ( ( * ef69 ) ( tmp [ 19 ] , tmp [ 18 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( term_equal ( tmp [ 2 ] , make_char ( 112 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 117 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 116 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 102 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( is_single_element ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 15 ] = list_head ( atmp10 ) ;
tmp [ 16 ] = list_tail ( atmp10 ) ;
if ( is_single_element ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
if ( check_sym ( tmp [ 15 ] , ef4sym ) ) {
tmp [ 18 ] = arg_0 ( tmp [ 15 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef70 ) ( tmp [ 18 ] , tmp [ 17 ] ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 11 ] = make_char ( 110 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 11 ] ) ) {
tmp [ 12 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 12 ] ) ) {
tmp [ 13 ] = list_head ( tmp [ 12 ] ) ;
if ( term_equal ( tmp [ 13 ] , make_char ( 101 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 12 ] ) ;
{
if ( not_empty_list ( tmp [ 14 ] ) ) {
tmp [ 15 ] = list_head ( tmp [ 14 ] ) ;
if ( term_equal ( tmp [ 15 ] , make_char ( 119 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 14 ] ) ;
{
if ( not_empty_list ( tmp [ 16 ] ) ) {
tmp [ 17 ] = list_head ( tmp [ 16 ] ) ;
if ( term_equal ( tmp [ 17 ] , make_char ( 45 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 16 ] ) ;
{
if ( not_empty_list ( tmp [ 18 ] ) ) {
tmp [ 19 ] = list_head ( tmp [ 18 ] ) ;
if ( term_equal ( tmp [ 19 ] , make_char ( 115 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 18 ] ) ;
{
if ( not_empty_list ( tmp [ 20 ] ) ) {
tmp [ 21 ] = list_head ( tmp [ 20 ] ) ;
if ( term_equal ( tmp [ 21 ] , make_char ( 101 ) ) ) {
tmp [ 22 ] = list_tail ( tmp [ 20 ] ) ;
{
if ( not_empty_list ( tmp [ 22 ] ) ) {
tmp [ 23 ] = list_head ( tmp [ 22 ] ) ;
if ( term_equal ( tmp [ 23 ] , make_char ( 112 ) ) ) {
tmp [ 24 ] = list_tail ( tmp [ 22 ] ) ;
{
if ( is_single_element ( tmp [ 24 ] ) ) {
tmp [ 25 ] = list_head ( tmp [ 24 ] ) ;
if ( term_equal ( tmp [ 25 ] , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp10 ) ) {
tmp [ 26 ] = list_head ( atmp10 ) ;
{
tmp [ 27 ] = list_tail ( atmp10 ) ;
{
if ( not_empty_list ( tmp [ 27 ] ) ) {
tmp [ 28 ] = list_head ( tmp [ 27 ] ) ;
{
tmp [ 29 ] = list_tail ( tmp [ 27 ] ) ;
{
if ( is_single_element ( tmp [ 29 ] ) ) {
tmp [ 30 ] = list_head ( tmp [ 29 ] ) ;
{
if ( check_sym ( tmp [ 26 ] , ef4sym ) ) {
tmp [ 31 ] = arg_0 ( tmp [ 26 ] ) ;
{
if ( check_sym ( tmp [ 28 ] , ef4sym ) ) {
tmp [ 32 ] = arg_0 ( tmp [ 28 ] ) ;
if ( ! term_equal ( ( * ef9 ) ( tmp [ 30 ] ) , make_nf1 ( ef1sym , make_nf0 ( ef10sym ) ) ) ) {
if ( ! term_equal ( ( * ef9 ) ( tmp [ 30 ] ) , make_nf1 ( ef1sym , make_nf0 ( ef11sym ) ) ) ) {
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef5 ) ( ( * ef6 ) ( tmp [ 32 ] ) , ( * ef7 ) ( lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 30 ] ) ) ) , ( * ef8 ) ( tmp [ 32 ] , ( * ef8 ) ( tmp [ 31 ] , ( * ef7 ) ( lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 30 ] ) ) ) ) ) ) ) ) ;
}
}
if ( term_equal ( ( * ef12 ) ( ( * ef13 ) ( ( * ef9 ) ( tmp [ 30 ] ) , ( constant8 ? constant8 : ( constant8 = make_nf1 ( ef1sym , make_nf0 ( ef10sym ) ) ) ) ) , ( * ef13 ) ( ( * ef9 ) ( tmp [ 30 ] ) , ( constant9 ? constant9 : ( constant9 = make_nf1 ( ef1sym , make_nf0 ( ef11sym ) ) ) ) ) ) , ( constant4 ? constant4 : ( constant4 = make_nf0 ( ef14sym ) ) ) ) ) {
FUNC_EXIT ( make_nf1 ( ef4sym , tmp [ 32 ] ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if ( check_sym ( ltmp [ 0 ] , ef19sym ) ) {
{
ATerm atmp00 = arg_0 ( arg0 ) ;
if ( check_sym ( atmp00 , ef2sym ) ) {
{
ATerm atmp000 = arg_0 ( atmp00 ) ;
if ( check_sym ( atmp000 , ef3sym ) ) {
{
ATerm atmp0000 = arg_0 ( atmp000 ) ;
if ( check_sym ( atmp0000 , lf3sym ) ) {
{
ATerm atmp00000 = arg_0 ( atmp0000 ) ;
{
ATerm atmp01 = arg_1 ( arg0 ) ;
if ( check_sym ( atmp01 , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp010 = arg_0 ( atmp01 ) ;
if ( check_sym ( ltmp [ 1 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp10 = arg_0 ( arg1 ) ;
if ( not_empty_list ( atmp00000 ) ) {
tmp [ 0 ] = list_head ( atmp00000 ) ;
if ( term_equal ( tmp [ 0 ] , make_char ( 34 ) ) ) {
tmp [ 1 ] = list_tail ( atmp00000 ) ;
{
if ( not_empty_list ( tmp [ 1 ] ) ) {
tmp [ 2 ] = list_head ( tmp [ 1 ] ) ;
if ( term_equal ( tmp [ 2 ] , make_char ( 102 ) ) ) {
tmp [ 3 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 3 ] ) ) {
if ( term_equal ( list_head ( tmp [ 3 ] ) , make_char ( 117 ) ) ) {
tmp [ 4 ] = list_tail ( tmp [ 3 ] ) ;
if ( not_empty_list ( tmp [ 4 ] ) ) {
if ( term_equal ( list_head ( tmp [ 4 ] ) , make_char ( 110 ) ) ) {
tmp [ 5 ] = list_tail ( tmp [ 4 ] ) ;
if ( not_empty_list ( tmp [ 5 ] ) ) {
if ( term_equal ( list_head ( tmp [ 5 ] ) , make_char ( 45 ) ) ) {
tmp [ 6 ] = list_tail ( tmp [ 5 ] ) ;
if ( not_empty_list ( tmp [ 6 ] ) ) {
if ( term_equal ( list_head ( tmp [ 6 ] ) , make_char ( 119 ) ) ) {
tmp [ 7 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 7 ] ) ) {
if ( term_equal ( list_head ( tmp [ 7 ] ) , make_char ( 109 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 7 ] ) ;
if ( not_empty_list ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 97 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 8 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 112 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( is_single_element ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp010 ) ) {
tmp [ 11 ] = list_head ( atmp010 ) ;
if ( is_single_element ( atmp10 ) ) {
tmp [ 12 ] = list_head ( atmp10 ) ;
if ( check_sym ( tmp [ 12 ] , ef4sym ) ) {
tmp [ 13 ] = arg_0 ( tmp [ 12 ] ) ;
FUNC_EXIT ( make_nf1 ( ef4sym , ( * ef50 ) ( tmp [ 11 ] , make_nf1 ( ef4sym , tmp [ 13 ] ) ) ) ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 3 ] = make_char ( 99 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 3 ] ) ) {
tmp [ 4 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 4 ] ) ) {
tmp [ 5 ] = list_head ( tmp [ 4 ] ) ;
if ( term_equal ( tmp [ 5 ] , make_char ( 111 ) ) ) {
tmp [ 6 ] = list_tail ( tmp [ 4 ] ) ;
{
if ( not_empty_list ( tmp [ 6 ] ) ) {
tmp [ 7 ] = list_head ( tmp [ 6 ] ) ;
if ( term_equal ( tmp [ 7 ] , make_char ( 109 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 6 ] ) ;
{
if ( not_empty_list ( tmp [ 8 ] ) ) {
tmp [ 9 ] = list_head ( tmp [ 8 ] ) ;
if ( term_equal ( tmp [ 9 ] , make_char ( 112 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 8 ] ) ;
{
if ( is_single_element ( tmp [ 10 ] ) ) {
tmp [ 11 ] = list_head ( tmp [ 10 ] ) ;
if ( term_equal ( tmp [ 11 ] , make_char ( 34 ) ) ) {
if ( not_empty_list ( atmp010 ) ) {
tmp [ 12 ] = list_head ( atmp010 ) ;
tmp [ 13 ] = list_tail ( atmp010 ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( not_empty_list ( atmp10 ) ) {
arg0 = tmp [ 12 ] ;
arg1 = lf_AUX_ATerm_Operations13_1 ( make_list ( lf_AUX_ATerm_Operations13_2 ( make_nf2 ( ef19sym , ( constant10 ? constant10 : ( constant10 = make_nf1 ( ef2sym , ( * ef3 ) ( lf3 ( cons ( make_list ( make_char ( 34 ) ) , cons ( make_list ( make_char ( 99 ) ) , cons ( make_list ( make_char ( 111 ) ) , cons ( make_list ( make_char ( 109 ) ) , cons ( make_list ( make_char ( 112 ) ) , make_list ( make_char ( 34 ) ) ) ) ) ) ) ) ) ) ) ) , lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 13 ] ) ) ) , lf_AUX_ATerm_Operations13_1 ( make_list ( atmp10 ) ) ) ) ) ;
goto lbl_lf_AUX_ATerm_Operations13_2 ;
}
}
}
if ( is_single_element ( atmp010 ) ) {
tmp [ 12 ] = list_head ( atmp010 ) ;
if ( not_empty_list ( atmp10 ) ) {
arg0 = tmp [ 12 ] ;
arg1 = lf_AUX_ATerm_Operations13_1 ( make_list ( atmp10 ) ) ;
goto lbl_lf_AUX_ATerm_Operations13_2 ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
tmp [ 4 ] = make_char ( 119 ) ;
if ( term_equal ( tmp [ 2 ] , tmp [ 4 ] ) ) {
tmp [ 5 ] = list_tail ( tmp [ 1 ] ) ;
{
if ( not_empty_list ( tmp [ 5 ] ) ) {
tmp [ 6 ] = list_head ( tmp [ 5 ] ) ;
if ( term_equal ( tmp [ 6 ] , make_char ( 105 ) ) ) {
tmp [ 7 ] = list_tail ( tmp [ 5 ] ) ;
{
if ( not_empty_list ( tmp [ 7 ] ) ) {
tmp [ 8 ] = list_head ( tmp [ 7 ] ) ;
if ( term_equal ( tmp [ 8 ] , make_char ( 100 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 7 ] ) ;
{
if ( is_single_element ( tmp [ 9 ] ) ) {
tmp [ 10 ] = list_head ( tmp [ 9 ] ) ;
if ( term_equal ( tmp [ 10 ] , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp010 ) ) {
tmp [ 11 ] = list_head ( atmp010 ) ;
{
if ( is_single_element ( atmp10 ) ) {
tmp [ 12 ] = list_head ( atmp10 ) ;
tmp [ 13 ] = ( * ef48 ) ( ( constant11 ? constant11 : ( constant11 = make_nf0 ( ef10sym ) ) ) , tmp [ 12 ] ) ;
if ( term_equal ( tmp [ 13 ] , ( constant12 ? constant12 : ( constant12 = make_nf0 ( ef49sym ) ) ) ) ) {
arg0 = tmp [ 11 ] ;
arg1 = lf_AUX_ATerm_Operations13_1 ( make_list ( tmp [ 12 ] ) ) ;
goto lbl_lf_AUX_ATerm_Operations13_2 ;
}
if ( term_equal ( tmp [ 13 ] , ( constant4 ? constant4 : ( constant4 = make_nf0 ( ef14sym ) ) ) ) ) {
FUNC_EXIT ( tmp [ 12 ] ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
{
ATerm atmp00 = arg_0 ( arg0 ) ;
{
ATerm atmp01 = arg_1 ( arg0 ) ;
if ( check_sym ( atmp01 , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp010 = arg_0 ( atmp01 ) ;
if ( check_sym ( ltmp [ 1 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp10 = arg_0 ( arg1 ) ;
if ( not_empty_list ( atmp010 ) ) {
if ( not_empty_list ( atmp10 ) ) {
arg0 = make_nf1 ( ef1sym , atmp00 ) ;
arg1 = lf_AUX_ATerm_Operations13_1 ( cons ( make_list ( atmp010 ) , make_list ( atmp10 ) ) ) ;
goto lbl_lf_AUX_ATerm_Operations13_2 ;
}
}
}
}
}
}
}
}
}
}
if ( check_sym ( ltmp [ 0 ] , ef1sym ) ) {
{
ATerm atmp00 = arg_0 ( arg0 ) ;
if ( check_sym ( atmp00 , ef2sym ) ) {
{
ATerm atmp000 = arg_0 ( atmp00 ) ;
if ( check_sym ( atmp000 , ef3sym ) ) {
{
ATerm atmp0000 = arg_0 ( atmp000 ) ;
if ( check_sym ( atmp0000 , lf3sym ) ) {
{
ATerm atmp00000 = arg_0 ( atmp0000 ) ;
if ( check_sym ( ltmp [ 1 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp10 = arg_0 ( arg1 ) ;
if ( not_empty_list ( atmp00000 ) ) {
if ( term_equal ( list_head ( atmp00000 ) , make_char ( 34 ) ) ) {
tmp [ 0 ] = list_tail ( atmp00000 ) ;
if ( not_empty_list ( tmp [ 0 ] ) ) {
if ( term_equal ( list_head ( tmp [ 0 ] ) , make_char ( 114 ) ) ) {
tmp [ 1 ] = list_tail ( tmp [ 0 ] ) ;
if ( not_empty_list ( tmp [ 1 ] ) ) {
if ( term_equal ( list_head ( tmp [ 1 ] ) , make_char ( 101 ) ) ) {
tmp [ 2 ] = list_tail ( tmp [ 1 ] ) ;
if ( not_empty_list ( tmp [ 2 ] ) ) {
if ( term_equal ( list_head ( tmp [ 2 ] ) , make_char ( 109 ) ) ) {
tmp [ 3 ] = list_tail ( tmp [ 2 ] ) ;
if ( not_empty_list ( tmp [ 3 ] ) ) {
if ( term_equal ( list_head ( tmp [ 3 ] ) , make_char ( 111 ) ) ) {
tmp [ 4 ] = list_tail ( tmp [ 3 ] ) ;
if ( not_empty_list ( tmp [ 4 ] ) ) {
if ( term_equal ( list_head ( tmp [ 4 ] ) , make_char ( 118 ) ) ) {
tmp [ 5 ] = list_tail ( tmp [ 4 ] ) ;
if ( not_empty_list ( tmp [ 5 ] ) ) {
if ( term_equal ( list_head ( tmp [ 5 ] ) , make_char ( 101 ) ) ) {
tmp [ 6 ] = list_tail ( tmp [ 5 ] ) ;
if ( not_empty_list ( tmp [ 6 ] ) ) {
if ( term_equal ( list_head ( tmp [ 6 ] ) , make_char ( 45 ) ) ) {
tmp [ 7 ] = list_tail ( tmp [ 6 ] ) ;
if ( not_empty_list ( tmp [ 7 ] ) ) {
if ( term_equal ( list_head ( tmp [ 7 ] ) , make_char ( 101 ) ) ) {
tmp [ 8 ] = list_tail ( tmp [ 7 ] ) ;
if ( not_empty_list ( tmp [ 8 ] ) ) {
if ( term_equal ( list_head ( tmp [ 8 ] ) , make_char ( 109 ) ) ) {
tmp [ 9 ] = list_tail ( tmp [ 8 ] ) ;
if ( not_empty_list ( tmp [ 9 ] ) ) {
if ( term_equal ( list_head ( tmp [ 9 ] ) , make_char ( 112 ) ) ) {
tmp [ 10 ] = list_tail ( tmp [ 9 ] ) ;
if ( not_empty_list ( tmp [ 10 ] ) ) {
if ( term_equal ( list_head ( tmp [ 10 ] ) , make_char ( 116 ) ) ) {
tmp [ 11 ] = list_tail ( tmp [ 10 ] ) ;
if ( not_empty_list ( tmp [ 11 ] ) ) {
if ( term_equal ( list_head ( tmp [ 11 ] ) , make_char ( 121 ) ) ) {
tmp [ 12 ] = list_tail ( tmp [ 11 ] ) ;
if ( not_empty_list ( tmp [ 12 ] ) ) {
if ( term_equal ( list_head ( tmp [ 12 ] ) , make_char ( 45 ) ) ) {
tmp [ 13 ] = list_tail ( tmp [ 12 ] ) ;
if ( not_empty_list ( tmp [ 13 ] ) ) {
if ( term_equal ( list_head ( tmp [ 13 ] ) , make_char ( 103 ) ) ) {
tmp [ 14 ] = list_tail ( tmp [ 13 ] ) ;
if ( not_empty_list ( tmp [ 14 ] ) ) {
if ( term_equal ( list_head ( tmp [ 14 ] ) , make_char ( 114 ) ) ) {
tmp [ 15 ] = list_tail ( tmp [ 14 ] ) ;
if ( not_empty_list ( tmp [ 15 ] ) ) {
if ( term_equal ( list_head ( tmp [ 15 ] ) , make_char ( 97 ) ) ) {
tmp [ 16 ] = list_tail ( tmp [ 15 ] ) ;
if ( not_empty_list ( tmp [ 16 ] ) ) {
if ( term_equal ( list_head ( tmp [ 16 ] ) , make_char ( 109 ) ) ) {
tmp [ 17 ] = list_tail ( tmp [ 16 ] ) ;
if ( not_empty_list ( tmp [ 17 ] ) ) {
if ( term_equal ( list_head ( tmp [ 17 ] ) , make_char ( 109 ) ) ) {
tmp [ 18 ] = list_tail ( tmp [ 17 ] ) ;
if ( not_empty_list ( tmp [ 18 ] ) ) {
if ( term_equal ( list_head ( tmp [ 18 ] ) , make_char ( 97 ) ) ) {
tmp [ 19 ] = list_tail ( tmp [ 18 ] ) ;
if ( not_empty_list ( tmp [ 19 ] ) ) {
if ( term_equal ( list_head ( tmp [ 19 ] ) , make_char ( 114 ) ) ) {
tmp [ 20 ] = list_tail ( tmp [ 19 ] ) ;
if ( not_empty_list ( tmp [ 20 ] ) ) {
if ( term_equal ( list_head ( tmp [ 20 ] ) , make_char ( 115 ) ) ) {
tmp [ 21 ] = list_tail ( tmp [ 20 ] ) ;
if ( is_single_element ( tmp [ 21 ] ) ) {
if ( term_equal ( list_head ( tmp [ 21 ] ) , make_char ( 34 ) ) ) {
if ( is_single_element ( atmp10 ) ) {
tmp [ 22 ] = list_head ( atmp10 ) ;
FUNC_EXIT ( tmp [ 22 ] ) ;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
{
ATerm atmp00 = arg_0 ( arg0 ) ;
if ( check_sym ( ltmp [ 1 ] , lf_AUX_ATerm_Operations13_1sym ) ) {
{
ATerm atmp10 = arg_0 ( arg1 ) ;
if ( not_empty_list ( atmp10 ) ) {
FUNC_EXIT ( make_nf2 ( ef19sym , atmp00 , lf_AUX_ATerm_Operations13_1 ( make_list ( atmp10 ) ) ) ) ;
}
}
}
}
}
}
FUNC_EXIT ( make_nf2 ( lf_AUX_ATerm_Operations13_2sym , ltmp [ 0 ] , ltmp [ 1 ] ) ) ;
}
}
}
ATerm lf_AUX_ATerm_Operations13_1 ( ATerm arg0 ) {
CONS_ENTRY ( lf_AUX_ATerm_Operations13_1sym , ATmakeAppl ( lf_AUX_ATerm_Operations13_1sym , arg0 ) ) ;
CONS_EXIT ( make_nf1 ( lf_AUX_ATerm_Operations13_1sym , arg0 ) ) ;
}
ATerm lf3 ( ATerm arg0 ) {
CONS_ENTRY ( lf3sym , ATmakeAppl ( lf3sym , arg0 ) ) ;
CONS_EXIT ( make_nf1 ( lf3sym , arg0 ) ) ;
}
ATerm lf4 ( ATerm arg0 ) {
CONS_ENTRY ( lf4sym , ATmakeAppl ( lf4sym , arg0 ) ) ;
CONS_EXIT ( make_nf1 ( lf4sym , arg0 ) ) ;
}

