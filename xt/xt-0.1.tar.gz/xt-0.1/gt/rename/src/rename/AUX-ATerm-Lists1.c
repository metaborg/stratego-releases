#include  "asc-support.h"
void register_AUX_ATerm_Lists1 ( ) {
}
void resolve_AUX_ATerm_Lists1 ( ) {
}
void init_AUX_ATerm_Lists1 ( ) {
}

