#include  "asc-support.h"
void register_AUX_Boolean_Operations1 ( ) {
}
void resolve_AUX_Boolean_Operations1 ( ) {
}
void init_AUX_Boolean_Operations1 ( ) {
}

