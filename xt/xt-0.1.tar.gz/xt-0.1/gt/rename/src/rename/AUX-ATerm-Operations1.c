#include  "asc-support.h"
static Symbol lf_AUX_ATerm_Operations1_1sym ;
static ATerm lf_AUX_ATerm_Operations1_1 ( ) ;
static Symbol lf_AUX_ATerm_Operations1_2sym ;
static ATerm lf_AUX_ATerm_Operations1_2 ( ATerm arg1 ) ;
static Symbol lf_AUX_ATerm_Operations1_3sym ;
static ATerm lf_AUX_ATerm_Operations1_3 ( ATerm arg1 ) ;
void register_AUX_ATerm_Operations1 ( ) {
lf_AUX_ATerm_Operations1_1sym = ATmakeSymbol ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"fail\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))"
 , 0 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_ATerm_Operations1_1sym ) ;
lf_AUX_ATerm_Operations1_2sym = ATmakeSymbol ( "prod(id(\"ATerm-Operations\"),w(\"\"),[ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"bracket\")],w(\"\"),l(\"}\")))" , 1 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_ATerm_Operations1_2sym ) ;
lf_AUX_ATerm_Operations1_3sym = ATmakeSymbol ( "prod(id(\"ATerm-Operations\"),w(\"\"),[ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"bracket\")],w(\"\"),l(\"}\")))" , 1 , ATtrue ) ;
ATprotectSymbol ( lf_AUX_ATerm_Operations1_3sym ) ;
register_prod ( ATparse ( "prod(id(\"ATerm-Operations\"),w(\"\"),[l(\"fail\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"AFun\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"constructor\")],w(\"\"),l(\"}\")))" ) , lf_AUX_ATerm_Operations1_1 , lf_AUX_ATerm_Operations1_1sym ) ;
register_prod ( ATparse ( "prod(id(\"ATerm-Operations\"),w(\"\"),[ql(\"(\"),w(\"\"),sort(\"ATerm\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATerm\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"bracket\")],w(\"\"),l(\"}\")))" ) , lf_AUX_ATerm_Operations1_2 , lf_AUX_ATerm_Operations1_2sym ) ;
register_prod ( ATparse ( "prod(id(\"ATerm-Operations\"),w(\"\"),[ql(\"(\"),w(\"\"),sort(\"ATermList\"),w(\"\"),ql(\")\")],w(\"\"),l(\"->\"),w(\"\"),sort(\"ATermList\"),w(\"\"),attrs(l(\"{\"),w(\"\"),[l(\"bracket\")],w(\"\"),l(\"}\")))" ) , lf_AUX_ATerm_Operations1_3 , lf_AUX_ATerm_Operations1_3sym ) ;
}
void resolve_AUX_ATerm_Operations1 ( ) {
}
static ATerm constant0 = NULL ;
void init_AUX_ATerm_Operations1 ( ) {
ATprotect ( & constant0 ) ;
}
ATerm lf_AUX_ATerm_Operations1_3 ( ATerm arg0 ) {
CONS_ENTRY ( lf_AUX_ATerm_Operations1_3sym , ATmakeAppl ( lf_AUX_ATerm_Operations1_3sym , arg0 ) ) ;
CONS_EXIT ( make_nf1 ( lf_AUX_ATerm_Operations1_3sym , arg0 ) ) ;
}
ATerm lf_AUX_ATerm_Operations1_2 ( ATerm arg0 ) {
CONS_ENTRY ( lf_AUX_ATerm_Operations1_2sym , ATmakeAppl ( lf_AUX_ATerm_Operations1_2sym , arg0 ) ) ;
CONS_EXIT ( make_nf1 ( lf_AUX_ATerm_Operations1_2sym , arg0 ) ) ;
}
ATerm lf_AUX_ATerm_Operations1_1 ( ) {
CONS_ENTRY ( lf_AUX_ATerm_Operations1_1sym , ATmakeAppl0 ( lf_AUX_ATerm_Operations1_1sym ) ) ;
CONS_EXIT_CONST ( constant0 , make_nf0 ( lf_AUX_ATerm_Operations1_1sym ) ) ;
}

