\literate[{\tt IMPLODE-ASFIX}]

	This module defines a transformation from AsFix terms produced
	by the SDF2 parser to abstract syntax terms. The
	transformation removes layout and literals, collapses lexical
	terms to strings and replaces production applications by
	applications of a derived constructor name.

	See module \verb|asfix| for a signature of AsFixTerms.

	TODO: \\
	- complete list of special constructors\\

\begin{code}
module implode-asfix
imports lib asfix
\end{code}

	\paragraph{Main}

	The main strategy first removes the \verb|parsetree| wrapper
	function. It then removes layout, transforms lexical trees
	into strings and context-free trees into constructor
	applications.

\begin{code}
rules

  PT : parsetree(t, _) -> t  

strategies

  main = iowrap(implode-asfix)

  implode-asfix = 
	PT; 
        rec x(try(amb(list(x)) + implode-lexical 
                  <+ appl(id, filter(not(is-layout); x)); 
                     (OptList <+ Cns <+ Inj <+ Tuple)));
	conc-to-cons
\end{code}

	\paragraph{Implode Lexical}

	The yield of an AsFixTerm is the string consisting of the
	characters at the leaves of the tree.

\begin{code}
rules
  Kids  : appl(p, ts) -> <concat> ts
  Kids' : x -> [x]
strategies

  yield = rec x((appl(id, map(x)); Kids) <+ Kids'); implode-string

  implode-lexical = appl(prod([lex(id)],cf(id),id), id); yield
\end{code}

	\paragraph{Layout}

	A tree represents layout if it is either of sort
	\verb|cf(opt(layout))| or a literal, i.e., of sort
	\verb|lit(_)|. The strategy \verb|rm-layout| removes all
	layout from a tree.

\begin{code}
strategies

  is-layout = appl(prod(id, cf(opt(layout)) + lit(id), id), id) +
              appl(prod([lit(id)],cf(alt(id,id)),no-attrs), id)

  rm-layout = rec x(try(appl(id, filter(not(is-layout); x)) + amb(list(x))))
\end{code}

	\paragraph{Constructors}

	An application of a context-free production is transformed
	into an actual application of a constructor name to the list
	of children. The Stratego primitive \verb|mkterm| takes a pair
	of a string \verb|c| and a list of terms \verb|ts| and turns
	it into the term \verb|c(ts)|. The constructor \verb|c| is
	derived from the production. If it has a \verb|cons(c)|
	attribute that attribute is taken. Otherwise the production
	should be some derived production for regular expressions.

\begin{code}
rules

  Position : t -> position(t, p)
	     where <get-annotation>(t, "position") => p

  Cns : appl(p, ts) -> <mkterm> (c, ts)
        where <Constr0 <+ Constr1> p => c

  Constr0 : prod(_, _, as) -> x
           where <oncetd(?cons(x))> as

  Constr1 : prod([],cf(iter-star-sep(_,_)),_)     -> "Nil"
  Constr1 : prod([],cf(iter-star(_)),_)           -> "Nil"
  Constr1 : prod([cf(x)], cf(iter-sep(x,_)), _)   -> "Ins"
  Constr1 : prod([cf(x)], cf(iter(x)), _)         -> "Ins"
  Constr1 : prod([_,_,_,_,_],cf(iter-sep(_,_)),_) -> "Conc"
  Constr1 : prod([_,_,_],cf(iter(_)),_)           -> "Conc"

  Constr1 : prod([], cf(opt(_)), _)      -> "None"
  Constr1 : prod([cf(x)], cf(opt(x)), _) -> "Some"

  Constr23 : prod(args, cf(iter-sep(x, y)), _) -> c
             where <(?[cf(x)]; !"Ins" <+ ?[_,_,_,_,_]; !"Conc")> args => c

rules

  OptList : appl(prod([], cf(opt(s)), _), []) -> Nil
	    where <is-list> s

  OptList : appl(prod([cf(s)], cf(opt(s)), _), [x]) -> x
	    where <is-list> s

strategies

  list-sort =  
	iter(id) +
	iter-sep(id, id) +
	iter-star(id) + 
	iter-star-sep(id, id)

  is-list = {y: rec x(list-sort; where(new=>y) +
                      seq(list(lit(id) + layout + x)))}
\end{code}

	\paragraph{Injections}

	Injections are nodes in a tree with a single child. Such nodes
	can be ignored if they only relate syntactic information
	instead of structural information. For instance, bracket nodes
	are only necessary for syntactic purposes.
	
	Note: the \verb|?sort("<START>")| is necessary because
	\verb|sort| is also defined as a strategy operator that sorts
	lists.
\begin{code}
strategies
  injection = prod(id, ?sort("<START>"), no-attrs)

  injection = oncetd(atr("bracket"))

  injection = {x: prod([cf(iter-sep(?x,lit(id)))], 
                       cf(iter-star-sep(?x,lit(id))),no-attrs)}

  injection = prod(filter(not(cf(opt(layout)) + lit(id))); [id], 
                   cf(seq(id)), id)


rules

  Inj : appl(p, [t]) -> t
        where <injection + not(oncetd(cons(?x)))> p
\end{code}

	\paragraph{Tuples}

\begin{code}
rules

  MkTCons : (x, xs) -> TCons(x, xs)

  Tuple : appl(prod(_, cf(seq(_)), _), args) ->
	  <foldr(!TNil, MkTCons)> args
\end{code}
	
	\paragraph{Conc to Cons}

	SDF2 lists are composed by means of a binary concatenation
	operator (\verb|A+ A+ -> A+|) that we translated to
	\verb|Conc| above. In abstract syntax trees we want to
	represent lists by \verb|Cons/Nil| structures. The following
	rules achieve this transformation.

\begin{code}
rules

  CTC0 : Snoc(x, y) -> Conc(x, Ins(y))
  CTC0 : Cons(x, y) -> Conc(Ins(x), y)

  CTC1 : Conc(Conc(x, y), z) -> Conc(x, Conc(y, z))
  CTC1 : Conc(Nil, x) -> x
  CTC1 : Conc(x, Nil) -> x

  CTC2 : Conc(Ins(x), Nil) -> Cons(x, Nil)
  CTC2 : Conc(Ins(x), Ins(y)) -> Cons(x, Cons(y, Nil))
  CTC2 : Conc(Ins(x), Cons(y, z)) -> Cons(x, Cons(y, z))

  CTC3 : Ins(x) -> Cons(x, Nil)

  CTC4 : Conc(Cons(x, y), z) -> Cons(x, Conc(y, z))

signature
  operations
    Ins  : a -> List(a)
    Conc : List(a) * List(a) -> List(a)
    Snoc : List(a) * a -> List(a)

    position : a * List(b) -> a

strategies

  conc-to-cons = rec x(repeat(CTC0 + CTC1 + Conc(CTC0, id)); 
                       (Conc(id, x) <+ all(x)); 
                       try(CTC2; Cons(x, id) + CTC3))
\end{code}
