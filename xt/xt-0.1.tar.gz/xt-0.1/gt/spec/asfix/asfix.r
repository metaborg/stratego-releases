\literate[{\tt ASFIX}]

	Abstract syntax for parse tree representation of SDF2 parsers.

\begin{code}
module asfix
signature
  sorts Sort
  operations
    layout        : Sort
    cf            : Sort -> Sort
    lex           : Sort -> Sort
    opt           : Sort -> Sort
    seq           : Sort -> Sort
    lit           : String -> Sort
    iter-sep      : Sort * Sort -> Sort
    iter-star-sep : Sort * Sort -> Sort
    iter          : Sort -> Sort
    iter-star     : Sort -> Sort
    alt           : Sort * Sort -> Sort
\end{code}

\begin{code}
  sorts Attribute 
  operations
    atr      : String -> Attribute
    cons     : String -> Attribute
    no-attrs : List(Attribute)
\end{code}

\begin{code}
  sorts Prod AsFixTerm
  operations
    prod   : List(Sort) * Sort * List(Attribute) -> Prod
    appl   : Prod * List(AsFixTerm) -> AsFixTerm
    amb    : List(AsFixTerm) -> AsFixTerm
\end{code}

	Note: integers are also AsFixTerms

\begin{code}
  sorts ParseTree
  operations
    parsetree : AsFixTerm * Int -> ParseTree
\end{code}
