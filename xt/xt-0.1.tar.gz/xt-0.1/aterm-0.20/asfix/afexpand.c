#include <stdio.h>
#include <stdarg.h>
#include "AsFix-init-patterns.h"
#include "aterm2.h"
#include "AsFix.h"
#include "deprecated.h"
#include "aterm-macs.h"

extern ATerm pattern_asfix_module;
extern ATerm pattern_asfix_term;

void usage(char *prg, int err)
{
  FILE *f = stdout;

  if(err)
    f = stderr;

  ATfprintf(f, "usage: %s [input [output]]\n", prg);
  ATfprintf(f, "when input is not specified, stdin is used.\n");
  ATfprintf(f, "when output is not specified, stdout is used.\n");

  if(err)
    exit(1);
}

int main(int argc, char *argv[])
{
  ATerm tin, result = NULL;
  FILE *in = stdin, *out = stdout;
  ATerm bottomOfStack;

  if(argc > 3)
    usage(argv[0], 1);

  if(argc > 1)
    in = fopen(argv[1], "r");
  if(argc > 2)
    out = fopen(argv[2], "w");

  if(!in)
    ATerror("cannot open input file %s\n", argv[1]);
  if(!out)
    ATerror("cannot open output file %s", argv[2]);

  AFinit(argc, argv, &bottomOfStack);
 
  AFinitAsFixPatterns();

  tin = ATreadFromFile(stdin);
  if(ATmatchTerm(tin, pattern_asfix_module, 
                 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)) {
    result = AFexpandModule(tin);
  } else if(ATmatchTerm(tin, pattern_asfix_term, 
                        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)) {
    result = AFexpandTerm(tin);
  } else {
    ATerror("term is not an asfix term/module.\n");
  }

  ATwriteToTextFile(result, stdout);

  return 0;
}
