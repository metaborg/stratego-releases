/*
\subsection{AsFix abbreviations}

The abbreviation mechanism will probably be abandoned when
most tools can cope with sharing.
*/

#ifndef ABBREVS_H
#define ABBREVS_H

#include "aterm1.h"
#include "aterm2.h"

/* \Function{AFexpandEqs}{ATerm }{ATerm eqs, ATermList abbrevs}{
Expand all abbreviations in a set of AsFix equations.} */
ATerm AFexpandEqs(ATerm eqs, ATermList abbrevs);

/* \Function{AFexpandModule}{ATerm }{ATerm module}{
Expand all abbreviations in an AsFix module.} */
ATerm AFexpandModule(ATerm module);

/* \Function{AFExpandTerm}{ATerm }{ATerm term}{Expand all
abbreviations in a AsFix term.} */
ATerm AFexpandTerm(ATerm term);

/* \Function{AFcollapseEqs}{ATerm }{ATerm eqs, ATermList *abbrevs}{
Collapse all abbreviations in a set of AsFix equations.} */
ATerm AFcollapseEqs(ATerm eqs, ATermList *abbrevs);

/* \Function{AFcollapseModule}{ATerm }{ATerm module}{
Collapse all abbreviations in an AsFix module.} */
ATerm AFcollapseModule(ATerm module);

/* \Function{AFCollapseTerm}{ATerm }{ATerm term}{Collapse all
abbreviations in a AsFix term.} */
ATerm AFcollapseTerm(ATerm term);

#endif
