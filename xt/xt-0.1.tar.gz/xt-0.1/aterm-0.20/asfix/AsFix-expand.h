#include "aterm2.h"

ATerm AFexpandModuleToAsFix(ATerm term, char *name, char* module_name);
ATerm AFexpandTermToAsFix(ATerm mod, char *name, char* module_name);
void AFinitExpansionTerms();
