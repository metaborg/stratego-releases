/*
The module {\tt asfix2src} defines functions that rebuild the original
the original source text represented by an asfix module/term.
*/

#include "aterm2.h"

int AFsourceSize(ATerm asfix);
int AFsource(ATerm asfix, char *buf);
char *AFsourceToBuf(ATerm asfix);
void AFsourceToFile(ATerm asfix, FILE *file);
