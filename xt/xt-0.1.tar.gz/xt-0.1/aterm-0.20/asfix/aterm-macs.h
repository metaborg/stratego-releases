#ifndef ATERM_MAC_H
#define ATERM_MAC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "encoding.h"
#include "abool.h"
#include "aterm2.h"

/* 
t_is_... macros

\Macro{t\_is\_appl}{ATbool }{ATerm }{Check if a term is an application.}
*/

#define t_is_asfix_appl(t) (ATgetType(t) == AT_APPL && ATgetSymbol((ATermAppl) t) == symbol_asfix_appl)
#define t_is_appl(t) (ATgetType(t) == AT_APPL)

/*
\Macro{t\_is\_list}{ATbool }{ATerm }{Check if a term is a list.}
*/

#define t_is_asfix_list(t) (ATgetType(t) == AT_LIST)

#define t_is_asfix_int(t) (ATgetType(t) == AT_INT)

#define asfix_str_eq(s,t)      (!(strcmp(s,t)))

#define strprefix(a,b) (strncmp(a,b,strlen(b)) == 0)

#endif
