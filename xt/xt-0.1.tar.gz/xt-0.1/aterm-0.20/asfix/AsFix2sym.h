/*
The module {\tt asfix2sym} defines functions that transform
asfix productions and iters into symbols. These symbols can
then be used when compiling AsFix to epic/rnx
*/

#include "aterm2.h"
#include <malloc.h>

Symbol AFprod2RNxSymbol(ATerm prod);
Symbol AFiter2RNxSymbol(ATerm iter);
Symbol AFsort2RNxSymbol(ATerm sort);
