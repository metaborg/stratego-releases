
README with version 0.6 of the aterm library.
=============================================

This library implements the ATerm datatype as described in ...
This distribution also contains a first draft of a paper describing
the ATerm datatype and its implementation in this library.

The ATerm library needs GNU-make in order to compile correctly.
You can retrieve the latest version of GNU-make from your closes
GNU mirror. In the Netherlands for instance, you could try:
ftp://ftp.nl.net/pub/gnu.

Installation should be a matter of simply configuring and making:
./configure --prefix <installation directory, i.e. /usr/local>
gmake
gmake install

If you have any questions, find any problems or are missing some
features in this library, please let us know. You can contact us at:

Pieter Olivier,                             Hayco de Jong,
Programming Research Group,                 Programming Research Group,
University of Amsterdam.                    University of Amsterdam,
e-mail: olivierp@wins.uva.nl                e-mail: jong@wins.uva.nl
tel.:  +31 20 5257590                       tel.:  +31 20 5257590



Miscellaneous remarks for old ToolBus or aterm-lib users
--------------------------------------------------------

- tifstoc is the new aterm version of the old ctif.
  This to avoid clashes with ctif in the ToolBus distribution.

