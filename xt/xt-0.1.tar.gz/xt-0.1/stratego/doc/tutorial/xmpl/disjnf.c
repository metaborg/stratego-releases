#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(t_9);
  goto main;
  main :
  Cpush(u_0);
  BuildFun("stdin",0);
  Rpush(v_0);
  goto n_23;
  v_0 :
  Rpush(w_0);
  goto q_23;
  w_0 :
  Rpush(x_0);
  goto s_23;
  x_0 :
  Rpush(y_0);
  goto t_23;
  y_0 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stdout",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(z_0);
  goto o_23;
  z_0 :
  Cpop();
  goto t_0;
  u_0 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(a_1);
  goto p_23;
  a_1 :
  t_0 :
  Return();
  n_23 :
  _ST_ReadFromFile();
  Return();
  o_23 :
  _ST_WriteToTextFile();
  Return();
  p_23 :
  _ST_printnl();
  Return();
  q_23 :
  Rpush(b_1);
  o_20 :
  AllInit();
  c_1 :
  AllNextSon(&&d_1);
  Rpush(e_1);
  goto o_20;
  e_1 :
  goto c_1;
  d_1 :
  AllBuild();
  Cpush(g_1);
  Cpush(i_1);
  h_1 :
  Rpush(j_1);
  goto r_23;
  j_1 :
  Tduplinv();
  goto h_1;
  i_1 :
  Cpop();
  goto f_1;
  g_1 :
  Cpush(l_1);
  k_1 :
  Rpush(m_1);
  goto r_23;
  m_1 :
  Tduplinv();
  goto k_1;
  l_1 :
  f_1 :
  Return();
  b_1 :
  Return();
  r_23 :
  Epushd(0,15);
  MatchFunFC("Not",&&h_2);
  Arg(0);
  MatchFunFC("True",&&j_2);
  Tpop();
  Rpush(k_2);
  goto a_0;
  k_2 :
  goto i_2;
  j_2 :
  MatchFunFC("False",&&l_2);
  Tpop();
  Rpush(m_2);
  goto b_0;
  m_2 :
  goto i_2;
  l_2 :
  goto fail;
  i_2 :
  goto g_2;
  h_2 :
  MatchFunFC("And",&&n_2);
  Arg(0);
  MatchFunFC("True",&&p_2);
  MatchVard(0,2);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&r_2);
  MatchVard(0,1);
  Tpop();
  Cpush(t_2);
  Rpush(u_2);
  goto c_0;
  u_2 :
  Cpop();
  goto s_2;
  t_2 :
  Rpush(v_2);
  goto d_0;
  v_2 :
  s_2 :
  goto q_2;
  r_2 :
  MatchFunFC("False",&&w_2);
  MatchVard(0,1);
  Tpop();
  Cpush(y_2);
  Rpush(z_2);
  goto c_0;
  z_2 :
  Cpop();
  goto x_2;
  y_2 :
  Rpush(a_3);
  goto f_0;
  a_3 :
  x_2 :
  goto q_2;
  w_2 :
  MatchVard(0,1);
  Tpop();
  Rpush(b_3);
  goto c_0;
  b_3 :
  q_2 :
  goto o_2;
  p_2 :
  MatchFunFC("False",&&c_3);
  MatchVard(0,2);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&e_3);
  MatchVard(0,3);
  Tpop();
  Cpush(g_3);
  Rpush(h_3);
  goto d_0;
  h_3 :
  Cpop();
  goto f_3;
  g_3 :
  Rpush(i_3);
  goto e_0;
  i_3 :
  f_3 :
  goto d_3;
  e_3 :
  MatchFunFC("False",&&j_3);
  MatchVard(0,3);
  Tpop();
  Cpush(l_3);
  Rpush(m_3);
  goto e_0;
  m_3 :
  Cpop();
  goto k_3;
  l_3 :
  Rpush(n_3);
  goto f_0;
  n_3 :
  k_3 :
  goto d_3;
  j_3 :
  MatchVard(0,3);
  Tpop();
  Rpush(o_3);
  goto e_0;
  o_3 :
  d_3 :
  goto o_2;
  c_3 :
  MatchVard(0,2);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&q_3);
  Tpop();
  Rpush(r_3);
  goto d_0;
  r_3 :
  goto p_3;
  q_3 :
  MatchFunFC("False",&&s_3);
  Tpop();
  Rpush(t_3);
  goto f_0;
  t_3 :
  goto p_3;
  s_3 :
  goto fail;
  p_3 :
  o_2 :
  goto g_2;
  n_2 :
  MatchFunFC("Or",&&u_3);
  Arg(0);
  MatchFunFC("True",&&w_3);
  MatchVard(0,6);
  MatchVard(0,8);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&y_3);
  MatchVard(0,5);
  Tpop();
  Cpush(a_4);
  Rpush(b_4);
  goto g_0;
  b_4 :
  Cpop();
  goto z_3;
  a_4 :
  Rpush(c_4);
  goto h_0;
  c_4 :
  z_3 :
  goto x_3;
  y_3 :
  MatchFunFC("False",&&d_4);
  MatchVard(0,5);
  Tpop();
  Cpush(f_4);
  Rpush(g_4);
  goto g_0;
  g_4 :
  Cpop();
  goto e_4;
  f_4 :
  Rpush(h_4);
  goto j_0;
  h_4 :
  e_4 :
  goto x_3;
  d_4 :
  MatchVard(0,5);
  Tpop();
  Rpush(i_4);
  goto g_0;
  i_4 :
  x_3 :
  goto v_3;
  w_3 :
  MatchFunFC("False",&&j_4);
  MatchVard(0,6);
  MatchVard(0,8);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&l_4);
  MatchVard(0,7);
  Tpop();
  Cpush(n_4);
  Rpush(o_4);
  goto h_0;
  o_4 :
  Cpop();
  goto m_4;
  n_4 :
  Rpush(p_4);
  goto i_0;
  p_4 :
  m_4 :
  goto k_4;
  l_4 :
  MatchFunFC("False",&&q_4);
  MatchVard(0,7);
  Tpop();
  Cpush(s_4);
  Rpush(t_4);
  goto i_0;
  t_4 :
  Cpop();
  goto r_4;
  s_4 :
  Rpush(u_4);
  goto j_0;
  u_4 :
  r_4 :
  goto k_4;
  q_4 :
  MatchVard(0,7);
  Tpop();
  Rpush(v_4);
  goto i_0;
  v_4 :
  k_4 :
  goto v_3;
  j_4 :
  MatchVard(0,6);
  MatchVard(0,8);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&x_4);
  Tpop();
  Rpush(y_4);
  goto h_0;
  y_4 :
  goto w_4;
  x_4 :
  MatchFunFC("False",&&z_4);
  Tpop();
  Rpush(a_5);
  goto j_0;
  a_5 :
  goto w_4;
  z_4 :
  goto fail;
  w_4 :
  v_3 :
  goto g_2;
  u_3 :
  MatchFunFC("Impl",&&b_5);
  Arg(0);
  MatchFunFC("False",&&d_5);
  MatchVard(0,10);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&f_5);
  MatchVard(0,11);
  Tpop();
  Cpush(h_5);
  Rpush(i_5);
  goto l_0;
  i_5 :
  Cpop();
  goto g_5;
  h_5 :
  Rpush(j_5);
  goto m_0;
  j_5 :
  g_5 :
  goto e_5;
  f_5 :
  MatchFunFC("False",&&k_5);
  MatchVard(0,11);
  Tpop();
  Cpush(m_5);
  Rpush(n_5);
  goto m_0;
  n_5 :
  Cpop();
  goto l_5;
  m_5 :
  Rpush(o_5);
  goto n_0;
  o_5 :
  l_5 :
  goto e_5;
  k_5 :
  MatchVard(0,11);
  Tpop();
  Rpush(p_5);
  goto m_0;
  p_5 :
  e_5 :
  goto c_5;
  d_5 :
  MatchFunFC("True",&&q_5);
  MatchVard(0,10);
  Tpop();
  Arg(1);
  MatchFunFC("True",&&s_5);
  MatchVard(0,9);
  Tpop();
  Cpush(u_5);
  Rpush(v_5);
  goto k_0;
  v_5 :
  Cpop();
  goto t_5;
  u_5 :
  Rpush(w_5);
  goto l_0;
  w_5 :
  t_5 :
  goto r_5;
  s_5 :
  MatchFunFC("False",&&x_5);
  MatchVard(0,9);
  Tpop();
  Cpush(z_5);
  Rpush(a_6);
  goto k_0;
  a_6 :
  Cpop();
  goto y_5;
  z_5 :
  Rpush(b_6);
  goto o_0;
  b_6 :
  y_5 :
  goto r_5;
  x_5 :
  MatchVard(0,9);
  Tpop();
  Rpush(c_6);
  goto k_0;
  c_6 :
  r_5 :
  goto c_5;
  q_5 :
  MatchVard(0,10);
  Tpop();
  Arg(1);
  MatchFun("True");
  Tpop();
  Rpush(d_6);
  goto l_0;
  d_6 :
  c_5 :
  goto g_2;
  b_5 :
  MatchFunFC("Eq",&&e_6);
  Arg(0);
  MatchFunFC("False",&&g_6);
  MatchVard(0,13);
  MatchVard(0,15);
  Tpop();
  Arg(1);
  MatchFunFC("False",&&i_6);
  MatchVard(0,12);
  Tpop();
  Cpush(k_6);
  Rpush(l_6);
  goto p_0;
  l_6 :
  Cpop();
  goto j_6;
  k_6 :
  Rpush(m_6);
  goto q_0;
  m_6 :
  j_6 :
  goto h_6;
  i_6 :
  MatchFunFC("True",&&n_6);
  MatchVard(0,12);
  Tpop();
  Cpush(p_6);
  Rpush(q_6);
  goto p_0;
  q_6 :
  Cpop();
  goto o_6;
  p_6 :
  Rpush(r_6);
  goto s_0;
  r_6 :
  o_6 :
  goto h_6;
  n_6 :
  MatchVard(0,12);
  Tpop();
  Rpush(s_6);
  goto p_0;
  s_6 :
  h_6 :
  goto f_6;
  g_6 :
  MatchFunFC("True",&&t_6);
  MatchVard(0,13);
  MatchVard(0,15);
  Tpop();
  Arg(1);
  MatchFunFC("False",&&v_6);
  MatchVard(0,14);
  Tpop();
  Cpush(x_6);
  Rpush(y_6);
  goto q_0;
  y_6 :
  Cpop();
  goto w_6;
  x_6 :
  Rpush(z_6);
  goto r_0;
  z_6 :
  w_6 :
  goto u_6;
  v_6 :
  MatchFunFC("True",&&a_7);
  MatchVard(0,14);
  Tpop();
  Cpush(c_7);
  Rpush(d_7);
  goto r_0;
  d_7 :
  Cpop();
  goto b_7;
  c_7 :
  Rpush(e_7);
  goto s_0;
  e_7 :
  b_7 :
  goto u_6;
  a_7 :
  MatchVard(0,14);
  Tpop();
  Rpush(f_7);
  goto r_0;
  f_7 :
  u_6 :
  goto f_6;
  t_6 :
  MatchVard(0,13);
  MatchVard(0,15);
  Tpop();
  Arg(1);
  MatchFunFC("False",&&h_7);
  Tpop();
  Rpush(i_7);
  goto q_0;
  i_7 :
  goto g_7;
  h_7 :
  MatchFunFC("True",&&j_7);
  Tpop();
  Rpush(k_7);
  goto s_0;
  k_7 :
  goto g_7;
  j_7 :
  goto fail;
  g_7 :
  f_6 :
  goto g_2;
  e_6 :
  goto fail;
  g_2 :
  goto f_2;
  s_0 :
  BuildVard(0,15);
  Return();
  f_2 :
  goto e_2;
  r_0 :
  BuildVard(0,14);
  Return();
  e_2 :
  goto d_2;
  q_0 :
  BuildVard(0,13);
  Tpush();
  BuildFun("Not",1);
  Return();
  d_2 :
  goto c_2;
  p_0 :
  BuildVard(0,12);
  Tpush();
  BuildFun("Not",1);
  Return();
  c_2 :
  goto b_2;
  o_0 :
  BuildFun("False",0);
  Return();
  b_2 :
  goto a_2;
  n_0 :
  BuildFun("True",0);
  Return();
  a_2 :
  goto z_1;
  m_0 :
  BuildFun("True",0);
  Return();
  z_1 :
  goto y_1;
  l_0 :
  BuildFun("True",0);
  Return();
  y_1 :
  goto x_1;
  k_0 :
  BuildVard(0,9);
  Return();
  x_1 :
  goto w_1;
  j_0 :
  BuildVard(0,8);
  Return();
  w_1 :
  goto v_1;
  i_0 :
  BuildVard(0,7);
  Return();
  v_1 :
  goto u_1;
  h_0 :
  BuildFun("True",0);
  Return();
  u_1 :
  goto t_1;
  g_0 :
  BuildFun("True",0);
  Return();
  t_1 :
  goto s_1;
  f_0 :
  BuildFun("False",0);
  Return();
  s_1 :
  goto r_1;
  e_0 :
  BuildFun("False",0);
  Return();
  r_1 :
  goto q_1;
  d_0 :
  BuildVard(0,2);
  Return();
  q_1 :
  goto p_1;
  c_0 :
  BuildVard(0,1);
  Return();
  p_1 :
  goto o_1;
  b_0 :
  BuildFun("True",0);
  Return();
  o_1 :
  goto n_1;
  a_0 :
  BuildFun("False",0);
  Return();
  n_1 :
  Epopd(0,15);
  Return();
  s_23 :
  Rpush(l_7);
  s_21 :
  Cpush(n_7);
  Cpush(p_7);
  Cpush(r_7);
  Epushd(0,2);
  MatchFun("Impl");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,2);
  Cpop();
  goto q_7;
  r_7 :
  Epushd(0,2);
  MatchFun("Eq");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("Impl",2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Impl",2);
  Tpush();
  BuildFun("And",2);
  Epopd(0,2);
  q_7 :
  Cpop();
  goto o_7;
  p_7 :
  o_7 :
  Cpop();
  goto m_7;
  n_7 :
  Cpush(t_7);
  Cpush(v_7);
  Epushd(0,2);
  MatchFun("Impl");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,2);
  Cpop();
  goto u_7;
  v_7 :
  Epushd(0,2);
  MatchFun("Eq");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("Impl",2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Impl",2);
  Tpush();
  BuildFun("And",2);
  Epopd(0,2);
  u_7 :
  Cpop();
  goto s_7;
  t_7 :
  s_7 :
  m_7 :
  AllInit();
  w_7 :
  AllNextSon(&&x_7);
  Rpush(y_7);
  goto s_21;
  y_7 :
  goto w_7;
  x_7 :
  AllBuild();
  Return();
  l_7 :
  Return();
  t_23 :
  Rpush(z_7);
  b_22 :
  Rpush(a_8);
  goto u_23;
  a_8 :
  AllInit();
  b_8 :
  AllNextSon(&&c_8);
  Rpush(d_8);
  goto b_22;
  d_8 :
  goto b_8;
  c_8 :
  AllBuild();
  Rpush(e_8);
  goto v_23;
  e_8 :
  Return();
  z_7 :
  Return();
  u_23 :
  Cpush(g_8);
  Cpush(i_8);
  h_8 :
  Epushd(0,1);
  MatchFun("Not");
  Arg(0);
  MatchFun("Not");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Tduplinv();
  goto h_8;
  i_8 :
  Cpop();
  goto f_8;
  g_8 :
  Rpush(j_8);
  e_22 :
  Cpush(l_8);
  Cpush(n_8);
  Epushd(0,1);
  MatchFun("Not");
  Arg(0);
  MatchFun("Not");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Rpush(o_8);
  goto e_22;
  o_8 :
  Cpop();
  goto m_8;
  n_8 :
  m_8 :
  Cpop();
  goto k_8;
  l_8 :
  Cpush(q_8);
  Epushd(0,1);
  MatchFun("Not");
  Arg(0);
  MatchFun("Not");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Rpush(r_8);
  goto e_22;
  r_8 :
  Cpop();
  goto p_8;
  q_8 :
  p_8 :
  k_8 :
  Return();
  j_8 :
  f_8 :
  Cpush(t_8);
  Cpush(v_8);
  Cpush(x_8);
  Epushd(0,2);
  MatchFun("Not");
  Arg(0);
  MatchFun("And");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,2);
  Cpop();
  goto w_8;
  x_8 :
  Epushd(0,2);
  MatchFun("Not");
  Arg(0);
  MatchFun("Or");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildFun("And",2);
  Epopd(0,2);
  w_8 :
  Cpop();
  goto u_8;
  v_8 :
  u_8 :
  Cpop();
  goto s_8;
  t_8 :
  Cpush(z_8);
  Cpush(b_9);
  Epushd(0,2);
  MatchFun("Not");
  Arg(0);
  MatchFun("And");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,2);
  Cpop();
  goto a_9;
  b_9 :
  Epushd(0,2);
  MatchFun("Not");
  Arg(0);
  MatchFun("Or");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Not",1);
  Tpush();
  BuildFun("And",2);
  Epopd(0,2);
  a_9 :
  Cpop();
  goto y_8;
  z_8 :
  y_8 :
  s_8 :
  Return();
  v_23 :
  Rpush(c_9);
  e_17 :
  Cpush(e_9);
  Cpush(g_9);
  Cpush(i_9);
  Epushd(0,3);
  MatchFun("And");
  Arg(0);
  MatchFun("Or");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,3);
  Cpop();
  goto h_9;
  i_9 :
  Epushd(0,3);
  MatchFun("And");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Or");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,3);
  h_9 :
  AllInit();
  j_9 :
  AllNextSon(&&k_9);
  Rpush(l_9);
  goto e_17;
  l_9 :
  goto j_9;
  k_9 :
  AllBuild();
  Cpop();
  goto f_9;
  g_9 :
  f_9 :
  Cpop();
  goto d_9;
  e_9 :
  Cpush(n_9);
  Cpush(p_9);
  Epushd(0,3);
  MatchFun("And");
  Arg(0);
  MatchFun("Or");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,3);
  Cpop();
  goto o_9;
  p_9 :
  Epushd(0,3);
  MatchFun("And");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Or");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("And",2);
  Tpush();
  BuildFun("Or",2);
  Epopd(0,3);
  o_9 :
  AllInit();
  q_9 :
  AllNextSon(&&r_9);
  Rpush(s_9);
  goto e_17;
  s_9 :
  goto q_9;
  r_9 :
  AllBuild();
  Cpop();
  goto m_9;
  n_9 :
  m_9 :
  d_9 :
  Return();
  c_9 :
  Return();
  t_9 :
DOIT_END
