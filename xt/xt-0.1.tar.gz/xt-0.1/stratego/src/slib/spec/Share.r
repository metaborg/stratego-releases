module Share
imports lib share

strategies

  main = stdio(share(\ x -> Var(x)\, 
		     all(fail), 
                     \ (x,e,e') -> Let(x, e, e') \ ))