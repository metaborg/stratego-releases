#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(v_10);
  goto main;
  main :
  Epushd(0,9);
  Cpush(j_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  OneNextSon();
  Rpush(k_0);
  z_47 :
  Cpush(m_0);
  Rpush(n_0);
  goto h_50;
  n_0 :
  Cpop();
  goto l_0;
  m_0 :
  Cpush(p_0);
  Cpush(r_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto q_0;
  r_0 :
  Cpush(t_0);
  Rpush(u_0);
  goto i_50;
  u_0 :
  Cpop();
  goto s_0;
  t_0 :
  Cpush(w_0);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto v_0;
  w_0 :
  Cpush(y_0);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto x_0;
  y_0 :
  Cpush(a_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-i");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,3);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto z_0;
  a_1 :
  Cpush(c_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-o");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,4);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto b_1;
  c_1 :
  Cpush(e_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto d_1;
  e_1 :
  Cpush(g_1);
  Rpush(h_1);
  goto i_50;
  h_1 :
  Cpop();
  goto f_1;
  g_1 :
  Cpush(j_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto i_1;
  j_1 :
  Cpush(l_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto k_1;
  l_1 :
  Cpush(n_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto m_1;
  n_1 :
  Cpush(p_1);
  Rpush(q_1);
  goto i_50;
  q_1 :
  Cpop();
  goto o_1;
  p_1 :
  Cpush(s_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto r_1;
  s_1 :
  Cpush(u_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto t_1;
  u_1 :
  Cpush(w_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto v_1;
  w_1 :
  Cpush(y_1);
  Rpush(z_1);
  goto i_50;
  z_1 :
  Cpop();
  goto x_1;
  y_1 :
  Cpush(b_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto a_2;
  b_2 :
  Cpush(d_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto c_2;
  d_2 :
  Cpush(f_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto e_2;
  f_2 :
  Cpush(h_2);
  Rpush(i_2);
  goto i_50;
  i_2 :
  Cpop();
  goto g_2;
  h_2 :
  Cpush(k_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto j_2;
  k_2 :
  Cpush(m_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto l_2;
  m_2 :
  Cpush(o_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto n_2;
  o_2 :
  Cpush(q_2);
  Rpush(r_2);
  goto i_50;
  r_2 :
  Cpop();
  goto p_2;
  q_2 :
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  AllBuild();
  p_2 :
  n_2 :
  l_2 :
  j_2 :
  g_2 :
  e_2 :
  c_2 :
  a_2 :
  x_1 :
  v_1 :
  t_1 :
  r_1 :
  o_1 :
  m_1 :
  k_1 :
  i_1 :
  f_1 :
  d_1 :
  b_1 :
  z_0 :
  x_0 :
  v_0 :
  s_0 :
  q_0 :
  Rpush(s_2);
  goto z_47;
  s_2 :
  Cpop();
  goto o_0;
  p_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(t_2);
  goto z_47;
  t_2 :
  AllBuild();
  o_0 :
  l_0 :
  Return();
  k_0 :
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto i_0;
  j_0 :
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildStr("");
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(u_2);
  goto o_50;
  u_2 :
  Tpop();
  Rpush(v_2);
  goto j_50;
  v_2 :
  BuildInt(1);
  Rpush(w_2);
  goto p_50;
  w_2 :
  i_0 :
  Cpush(y_2);
  Tdupl();
  BuildVard(0,7);
  Tpop();
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(z_2);
  goto o_50;
  z_2 :
  Tpop();
  Rpush(a_3);
  goto j_50;
  a_3 :
  BuildInt(1);
  Rpush(b_3);
  goto p_50;
  b_3 :
  Cpop();
  goto x_2;
  y_2 :
  Cpush(d_3);
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  Cpush(f_3);
  BuildVard(0,3);
  Cpop();
  goto e_3;
  f_3 :
  BuildFun("stdin",0);
  e_3 :
  Rpush(g_3);
  goto k_50;
  g_3 :
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Tdupl();
  Rpush(h_3);
  goto l_50;
  h_3 :
  Tpop();
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Rpush(i_3);
  goto q_50;
  i_3 :
  Tdupl();
  Rpush(j_3);
  goto l_50;
  j_3 :
  MatchVard(0,9);
  Tpop();
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(l_3);
  BuildVard(0,4);
  Cpop();
  goto k_3;
  l_3 :
  BuildFun("stdout",0);
  k_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(n_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(o_3);
  goto m_50;
  o_3 :
  Cpop();
  goto m_3;
  n_3 :
  Rpush(p_3);
  goto n_50;
  p_3 :
  m_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting succeeded (");
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildStr(" secs)");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(q_3);
  goto o_50;
  q_3 :
  BuildInt(0);
  Rpush(r_3);
  goto p_50;
  r_3 :
  Cpop();
  goto c_3;
  d_3 :
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(t_3);
  BuildVard(0,4);
  Cpop();
  goto s_3;
  t_3 :
  BuildFun("stdout",0);
  s_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(v_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(w_3);
  goto m_50;
  w_3 :
  Cpop();
  goto u_3;
  v_3 :
  Rpush(x_3);
  goto n_50;
  x_3 :
  u_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(y_3);
  goto o_50;
  y_3 :
  BuildInt(1);
  Rpush(z_3);
  goto p_50;
  z_3 :
  c_3 :
  x_2 :
  Epopd(0,9);
  Return();
  h_50 :
  MatchFun("Nil");
  Return();
  i_50 :
  MatchFun("None");
  Return();
  j_50 :
  Tdupl();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stderr",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  Epushd(3,1);
  MatchVard(3,1);
  BuildVard(3,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(a_4);
  goto o_50;
  a_4 :
  Tpop();
  Return();
  k_50 :
  _ST_ReadFromFile();
  Return();
  l_50 :
  _ST_dtime();
  Return();
  m_50 :
  _ST_WriteToBinaryFile();
  Return();
  n_50 :
  _ST_WriteToTextFile();
  Return();
  o_50 :
  _ST_printnl();
  Return();
  p_50 :
  _ST_exit();
  Return();
  q_50 :
  Rpush(b_4);
  w_48 :
  Cpush(d_4);
  c_4 :
  Rpush(e_4);
  goto r_50;
  e_4 :
  Tduplinv();
  goto c_4;
  d_4 :
  AllInit();
  f_4 :
  AllNextSon(&&g_4);
  Rpush(h_4);
  goto w_48;
  h_4 :
  goto f_4;
  g_4 :
  AllBuild();
  Cpush(j_4);
  i_4 :
  Rpush(k_4);
  goto r_50;
  k_4 :
  Tduplinv();
  goto i_4;
  j_4 :
  Return();
  b_4 :
  Return();
  r_50 :
  Cpush(m_4);
  Rpush(n_4);
  goto s_50;
  n_4 :
  Cpop();
  goto l_4;
  m_4 :
  Cpush(p_4);
  Rpush(q_4);
  goto t_50;
  q_4 :
  Cpop();
  goto o_4;
  p_4 :
  Cpush(s_4);
  Rpush(t_4);
  goto u_50;
  t_4 :
  Cpop();
  goto r_4;
  s_4 :
  Cpush(v_4);
  Rpush(w_4);
  goto v_50;
  w_4 :
  Cpop();
  goto u_4;
  v_4 :
  Cpush(y_4);
  Rpush(z_4);
  goto w_50;
  z_4 :
  Cpop();
  goto x_4;
  y_4 :
  Cpush(b_5);
  Rpush(c_5);
  goto x_50;
  c_5 :
  Cpop();
  goto a_5;
  b_5 :
  Rpush(d_5);
  goto y_50;
  d_5 :
  a_5 :
  x_4 :
  u_4 :
  r_4 :
  o_4 :
  l_4 :
  Return();
  s_50 :
  Cpush(f_5);
  Epushd(0,0);
  MatchFun("Test");
  Arg(0);
  MatchFun("Id");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,0);
  Cpop();
  goto e_5;
  f_5 :
  Cpush(h_5);
  Epushd(0,0);
  MatchFun("Not");
  Arg(0);
  MatchFun("Id");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,0);
  Cpop();
  goto g_5;
  h_5 :
  Cpush(j_5);
  Epushd(0,1);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Id");
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto i_5;
  j_5 :
  Cpush(l_5);
  Epushd(0,1);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Id");
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto k_5;
  l_5 :
  Cpush(n_5);
  Epushd(0,1);
  MatchFun("Choice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Id");
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto m_5;
  n_5 :
  Cpush(p_5);
  Epushd(0,1);
  MatchFun("Choice");
  Arg(0);
  MatchFun("Id");
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto o_5;
  p_5 :
  Cpush(r_5);
  Epushd(0,1);
  MatchFun("LChoice");
  Arg(0);
  MatchFun("Id");
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildFun("Id",0);
  Epopd(0,1);
  Cpop();
  goto q_5;
  r_5 :
  Cpush(t_5);
  Epushd(0,1);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Id");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,1);
  Cpop();
  goto s_5;
  t_5 :
  Cpush(v_5);
  Epushd(0,1);
  MatchFun("Rec");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Id");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,1);
  Cpop();
  goto u_5;
  v_5 :
  Cpush(x_5);
  Epushd(0,0);
  MatchFun("All");
  Arg(0);
  MatchFun("Id");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,0);
  Cpop();
  goto w_5;
  x_5 :
  Cpush(z_5);
  Epushd(0,1);
  MatchFun("Path");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Id");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,1);
  Cpop();
  goto y_5;
  z_5 :
  Cpush(b_6);
  Epushd(0,0);
  MatchFun("Where");
  Arg(0);
  MatchFun("Id");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,0);
  Cpop();
  goto a_6;
  b_6 :
  Cpush(d_6);
  Epushd(0,2);
  MatchFun("Cong");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Rpush(e_6);
  j_49 :
  Cpush(g_6);
  Rpush(h_6);
  goto h_50;
  h_6 :
  Cpop();
  goto f_6;
  g_6 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("Id");
  OneNextSon();
  Rpush(i_6);
  goto j_49;
  i_6 :
  AllBuild();
  f_6 :
  Return();
  e_6 :
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Fun",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Id",0);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,2);
  Cpop();
  goto c_6;
  d_6 :
  Epushd(0,2);
  MatchFunFC("CongWld",&&n_6);
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Rpush(o_6);
  goto a_0;
  o_6 :
  goto m_6;
  n_6 :
  MatchFunFC("App",&&p_6);
  Arg(0);
  MatchFun("Id");
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Rpush(q_6);
  goto b_0;
  q_6 :
  goto m_6;
  p_6 :
  MatchFunFC("Match",&&r_6);
  Arg(0);
  MatchFun("Wld");
  Tpop();
  Rpush(s_6);
  goto c_0;
  s_6 :
  goto m_6;
  r_6 :
  goto fail;
  m_6 :
  goto l_6;
  c_0 :
  BuildFun("Id",0);
  Return();
  l_6 :
  goto k_6;
  b_0 :
  BuildVard(0,2);
  Return();
  k_6 :
  goto j_6;
  a_0 :
  Tdupl();
  BuildVard(0,1);
  Rpush(t_6);
  l_49 :
  Cpush(v_6);
  Rpush(w_6);
  goto h_50;
  w_6 :
  Cpop();
  goto u_6;
  v_6 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("Id");
  OneNextSon();
  Rpush(x_6);
  goto l_49;
  x_6 :
  AllBuild();
  u_6 :
  Return();
  t_6 :
  Tpop();
  BuildFun("Id",0);
  Return();
  j_6 :
  Epopd(0,2);
  c_6 :
  a_6 :
  y_5 :
  w_5 :
  u_5 :
  s_5 :
  q_5 :
  o_5 :
  m_5 :
  k_5 :
  i_5 :
  g_5 :
  e_5 :
  Return();
  t_50 :
  Cpush(z_6);
  Epushd(0,0);
  MatchFun("Test");
  Arg(0);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,0);
  Cpop();
  goto y_6;
  z_6 :
  Cpush(b_7);
  Epushd(0,0);
  MatchFun("Not");
  Arg(0);
  MatchFun("Fail");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,0);
  Cpop();
  goto a_7;
  b_7 :
  Cpush(d_7);
  Epushd(0,1);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Fail");
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,1);
  Cpop();
  goto c_7;
  d_7 :
  Cpush(f_7);
  Epushd(0,1);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,1);
  Cpop();
  goto e_7;
  f_7 :
  Cpush(h_7);
  Epushd(0,1);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,1);
  Cpop();
  goto g_7;
  h_7 :
  Cpush(j_7);
  Epushd(0,1);
  MatchFun("Rec");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,1);
  Cpop();
  goto i_7;
  j_7 :
  Cpush(l_7);
  Epushd(0,0);
  MatchFun("Some");
  Arg(0);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,0);
  Cpop();
  goto k_7;
  l_7 :
  Cpush(n_7);
  Epushd(0,0);
  MatchFun("One");
  Arg(0);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,0);
  Cpop();
  goto m_7;
  n_7 :
  Cpush(p_7);
  Epushd(0,1);
  MatchFun("Path");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Fail");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,1);
  Cpop();
  goto o_7;
  p_7 :
  Cpush(r_7);
  Epushd(0,2);
  MatchFun("Cong");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tdupl();
  s_7 :
  MatchFun("Cons");
  Cpush(t_7);
  Arg(0);
  MatchFun("Fail");
  Tpop();
  Cpop();
  goto u_7;
  t_7 :
  Arg(1);
  Tdrop();
  goto s_7;
  u_7 :
  Tpop();
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,2);
  Cpop();
  goto q_7;
  r_7 :
  Epushd(0,4);
  MatchFunFC("Choice",&&b_8);
  Arg(0);
  MatchFunFC("Fail",&&d_8);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFunFC("Fail",&&f_8);
  MatchVard(0,1);
  Tpop();
  Cpush(h_8);
  Rpush(i_8);
  goto d_0;
  i_8 :
  Cpop();
  goto g_8;
  h_8 :
  Rpush(j_8);
  goto e_0;
  j_8 :
  g_8 :
  goto e_8;
  f_8 :
  MatchVard(0,1);
  Tpop();
  Rpush(k_8);
  goto d_0;
  k_8 :
  e_8 :
  goto c_8;
  d_8 :
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Fail");
  Tpop();
  Rpush(l_8);
  goto e_0;
  l_8 :
  c_8 :
  goto a_8;
  b_8 :
  MatchFunFC("LChoice",&&m_8);
  Arg(0);
  MatchFunFC("Fail",&&o_8);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFunFC("Fail",&&q_8);
  MatchVard(0,3);
  Tpop();
  Cpush(s_8);
  Rpush(t_8);
  goto f_0;
  t_8 :
  Cpop();
  goto r_8;
  s_8 :
  Rpush(u_8);
  goto g_0;
  u_8 :
  r_8 :
  goto p_8;
  q_8 :
  MatchVard(0,3);
  Tpop();
  Rpush(v_8);
  goto f_0;
  v_8 :
  p_8 :
  goto n_8;
  o_8 :
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("Fail");
  Tpop();
  Rpush(w_8);
  goto g_0;
  w_8 :
  n_8 :
  goto a_8;
  m_8 :
  MatchFunFC("Where",&&x_8);
  Arg(0);
  MatchFun("Fail");
  Tpop();
  Rpush(y_8);
  goto h_0;
  y_8 :
  goto a_8;
  x_8 :
  goto fail;
  a_8 :
  goto z_7;
  h_0 :
  BuildFun("Fail",0);
  Return();
  z_7 :
  goto y_7;
  g_0 :
  BuildVard(0,4);
  Return();
  y_7 :
  goto x_7;
  f_0 :
  BuildVard(0,3);
  Return();
  x_7 :
  goto w_7;
  e_0 :
  BuildVard(0,2);
  Return();
  w_7 :
  goto v_7;
  d_0 :
  BuildVard(0,1);
  Return();
  v_7 :
  Epopd(0,4);
  q_7 :
  o_7 :
  m_7 :
  k_7 :
  i_7 :
  g_7 :
  e_7 :
  c_7 :
  a_7 :
  y_6 :
  Return();
  u_50 :
  Cpush(a_9);
  Epushd(0,3);
  MatchFun("Choice");
  Arg(0);
  MatchFun("Choice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Choice",2);
  Tpush();
  BuildFun("Choice",2);
  Epopd(0,3);
  Cpop();
  goto z_8;
  a_9 :
  Cpush(c_9);
  Epushd(0,3);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,3);
  Cpop();
  goto b_9;
  c_9 :
  Epushd(0,3);
  MatchFun("LChoice");
  Arg(0);
  MatchFun("LChoice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("LChoice",2);
  Tpush();
  BuildFun("LChoice",2);
  Epopd(0,3);
  b_9 :
  z_8 :
  Return();
  v_50 :
  Cpush(e_9);
  Epushd(0,1);
  MatchFun("Choice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto d_9;
  e_9 :
  Cpush(g_9);
  Epushd(0,1);
  MatchFun("LChoice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto f_9;
  g_9 :
  Cpush(i_9);
  Epushd(0,1);
  MatchFun("Where");
  Arg(0);
  MatchFun("Where");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Where",1);
  Epopd(0,1);
  Cpop();
  goto h_9;
  i_9 :
  Cpush(k_9);
  Epushd(0,1);
  MatchFun("Not");
  Arg(0);
  MatchFun("Not");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Test",1);
  Epopd(0,1);
  Cpop();
  goto j_9;
  k_9 :
  Cpush(m_9);
  Epushd(0,1);
  MatchFun("Test");
  Arg(0);
  MatchFun("Test");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Test",1);
  Epopd(0,1);
  Cpop();
  goto l_9;
  m_9 :
  Epushd(0,3);
  MatchFun("Where");
  Arg(0);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Where");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Build");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Where",1);
  Epopd(0,3);
  l_9 :
  j_9 :
  h_9 :
  f_9 :
  d_9 :
  Return();
  w_50 :
  Cpush(o_9);
  Epushd(0,3);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(p_9);
  b_50 :
  Cpush(r_9);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(s_9);
  goto b_50;
  s_9 :
  AllBuild();
  Cpop();
  goto q_9;
  r_9 :
  Rpush(t_9);
  goto h_50;
  t_9 :
  BuildVard(2,1);
  q_9 :
  Return();
  p_9 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Scope",2);
  Epopd(1,1);
  Epopd(0,3);
  Cpop();
  goto n_9;
  o_9 :
  Cpush(v_9);
  Epushd(0,4);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(w_9);
  e_50 :
  Cpush(y_9);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(z_9);
  goto e_50;
  z_9 :
  AllBuild();
  Cpop();
  goto x_9;
  y_9 :
  Rpush(a_10);
  goto h_50;
  a_10 :
  BuildVard(2,1);
  x_9 :
  Return();
  w_9 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Scope",2);
  Epopd(1,1);
  Epopd(0,4);
  Cpop();
  goto u_9;
  v_9 :
  Epushd(0,3);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("CountRule");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("CountRule",1);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Scope",2);
  Epopd(0,3);
  u_9 :
  n_9 :
  Return();
  x_50 :
  Cpush(c_10);
  Epushd(0,3);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Path");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Path");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Path",2);
  Epopd(0,3);
  Cpop();
  goto b_10;
  c_10 :
  Cpush(e_10);
  Epushd(0,3);
  MatchFun("LChoice");
  Arg(0);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("LChoice",2);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,3);
  Cpop();
  goto d_10;
  e_10 :
  Cpush(g_10);
  Epushd(0,4);
  MatchFun("LChoice");
  Arg(0);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("LChoice");
  Arg(0);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("LChoice",2);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("LChoice",2);
  Epopd(0,4);
  Cpop();
  goto f_10;
  g_10 :
  Epushd(0,3);
  MatchFun("Seq");
  Arg(0);
  MatchFun("LChoice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("CountRule");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("CountRule",1);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("CountRule",1);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("LChoice",2);
  Epopd(0,3);
  f_10 :
  d_10 :
  b_10 :
  Return();
  y_50 :
  Epushd(0,5);
  MatchFun("Choice");
  Arg(0);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tdupl();
  BuildVard(0,4);
  Rpush(h_10);
  g_50 :
  Cpush(j_10);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildFun("Fail",0);
  Cpop();
  goto i_10;
  j_10 :
  Cpush(l_10);
  Epushd(1,1);
  Cpush(q_10);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildFun("Fail",0);
  OneNextSon();
  MatchVard(1,1);
  AllBuild();
  Cpop();
  goto m_10;
  q_10 :
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  MatchVard(1,1);
  OneNextSon();
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildFun("Fail",0);
  AllBuild();
  m_10 :
  BuildVard(1,1);
  Epopd(1,1);
  Cpop();
  goto k_10;
  l_10 :
  Cpush(s_10);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(t_10);
  goto g_50;
  t_10 :
  OneNextSon();
  AllBuild();
  Cpop();
  goto r_10;
  s_10 :
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(u_10);
  goto g_50;
  u_10 :
  AllBuild();
  r_10 :
  k_10 :
  i_10 :
  Return();
  h_10 :
  MatchVard(0,5);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Choice",2);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Choice",2);
  Epopd(0,5);
  Return();
  v_10 :
DOIT_END
