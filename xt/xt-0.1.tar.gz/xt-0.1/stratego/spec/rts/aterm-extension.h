/*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

/* $Id: aterm-extension.h,v 1.2 2000/01/19 16:24:00 visser Exp $ */

#include <aterm2.h>

/* Extension of ATerm library */

#define t_string(t) ATgetName(ATgetSymbol(t))

#define t_is_appl(t) (ATgetType(t) == AT_APPL)

#define t_is_string(t) (t_is_appl(t) && ATisQuoted(ATgetSymbol(t)))

#define ATisReal(t) (ATgetType(t) == AT_REAL)
#define ATisInt(t)  (ATgetType(t) == AT_INT)

ATerm list_to_consnil(ATerm t);
ATerm list_to_tconstnil(ATerm t);
ATerm list_to_consnil_op(ATermList t);
ATerm list_to_consnil_shallow(ATerm t);
ATerm list_to_tconstnil_op(ATermList t);
ATerm consnil_to_list(ATerm t);
ATerm consnil_to_list_shallow(ATerm t);
ATerm tuple_cong(ATermList t);
ATerm list_cong(ATermList t);

ATerm ATmakeString(char *name);
ATerm ATmakeStringQ(char *name);
ATbool ATisString(ATerm t);
ATbool ATisThisString(ATerm t, char *name);
ATermList ATmap(ATermList l, ATerm (* f)(ATerm));
ATbool AThasName(ATerm t, char *name);

ATerm App0(char *name);
ATerm App1(char *name, ATerm arg1);
ATerm App2(char *name, ATerm arg1, ATerm arg2);
ATerm App3(char *name, ATerm arg1, ATerm arg2, ATerm arg3);
ATerm App4(char *name, ATerm arg1, ATerm arg2, ATerm arg3, ATerm arg4);

ATerm AppN(char *name, ATermList args);

#define ATisInt(t) (ATgetType(t) == AT_INT)
