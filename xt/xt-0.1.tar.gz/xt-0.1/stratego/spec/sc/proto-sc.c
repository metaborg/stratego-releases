#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(j_12);
  goto main;
  main :
  Rpush(a_0);
  goto g_44;
  a_0 :
  Cpush(c_0);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Tdupl();
  d_0 :
  MatchFun("Cons");
  Cpush(e_0);
  Arg(0);
  MatchFun("HELP");
  Tpop();
  Cpop();
  goto f_0;
  e_0 :
  Arg(1);
  Tdrop();
  goto d_0;
  f_0 :
  Tpop();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_0);
  goto x_44;
  g_0 :
  AllBuild();
  AllBuild();
  Rpush(h_0);
  goto j_44;
  h_0 :
  Cpop();
  goto b_0;
  c_0 :
  Cpush(j_0);
  Cpush(l_0);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Tdupl();
  m_0 :
  MatchFun("Cons");
  Cpush(n_0);
  Arg(0);
  MatchFun("CC");
  Tpop();
  Cpop();
  goto o_0;
  n_0 :
  Arg(1);
  Tdrop();
  goto m_0;
  o_0 :
  Tpop();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".c");
  OneNextSon();
  Rpush(p_0);
  goto x_44;
  p_0 :
  AllBuild();
  AllBuild();
  OneNextSon();
  Rpush(q_0);
  goto x_44;
  q_0 :
  AllBuild();
  AllBuild();
  Cpop();
  goto k_0;
  l_0 :
  Rpush(r_0);
  goto k_44;
  r_0 :
  Rpush(s_0);
  goto p_44;
  s_0 :
  k_0 :
  Rpush(t_0);
  goto q_44;
  t_0 :
  Rpush(u_0);
  goto r_44;
  u_0 :
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Tdupl();
  v_0 :
  MatchFun("Cons");
  Cpush(w_0);
  Arg(0);
  MatchFun("NORM");
  Tpop();
  Cpop();
  goto g_1;
  w_0 :
  Arg(1);
  Tdrop();
  goto v_0;
  g_1 :
  Tpop();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(h_1);
  goto x_44;
  h_1 :
  AllBuild();
  AllBuild();
  Cpop();
  goto i_0;
  j_0 :
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildStr(".tree");
  Tpush();
  BuildStr(".s");
  Tpush();
  BuildStr(".so1");
  Tpush();
  BuildStr(".so2");
  Tpush();
  BuildStr(".i1");
  Tpush();
  BuildStr(".i");
  Tpush();
  BuildStr(".o");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(i_1);
  i_28 :
  Cpush(k_1);
  Epushd(2,0);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildFun("Nil",0);
  Epopd(2,0);
  Cpop();
  goto j_1;
  k_1 :
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(2,2);
  Tpush();
  BuildVard(2,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,3);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(l_1);
  goto l_44;
  l_1 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(m_1);
  goto i_28;
  m_1 :
  OneNextSon();
  Rpush(n_1);
  goto x_44;
  n_1 :
  AllBuild();
  AllBuild();
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,1);
  Tpush();
  BuildVard(2,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(2,2);
  j_1 :
  Return();
  i_1 :
  MatchVard(1,1);
  BuildStr("rm");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(o_1);
  goto o_44;
  o_1 :
  Epopd(0,1);
  OneNextSon();
  Rpush(p_1);
  goto x_44;
  p_1 :
  AllBuild();
  AllBuild();
  BuildFun("stderr",0);
  Tpush();
  BuildStr("compilation succeeded");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(q_1);
  goto y_44;
  q_1 :
  BuildInt(0);
  Rpush(r_1);
  goto z_44;
  r_1 :
  i_0 :
  b_0 :
  Return();
  g_44 :
  Epushd(0,9);
  Tdupl();
  Rpush(s_1);
  j_28 :
  Cpush(u_1);
  Rpush(v_1);
  goto h_44;
  v_1 :
  Cpop();
  goto t_1;
  u_1 :
  Cpush(x_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-I");
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(y_1);
  goto j_28;
  y_1 :
  AllBuild();
  AllBuild();
  Cpop();
  goto w_1;
  x_1 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(z_1);
  goto j_28;
  z_1 :
  w_1 :
  t_1 :
  Return();
  s_1 :
  MatchVard(0,3);
  Tpop();
  Tdupl();
  Rpush(a_2);
  m_28 :
  Cpush(c_2);
  Rpush(d_2);
  goto h_44;
  d_2 :
  Cpop();
  goto b_2;
  c_2 :
  Cpush(f_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-CI");
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_2);
  goto m_28;
  g_2 :
  AllBuild();
  Cpop();
  goto e_2;
  f_2 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(h_2);
  goto m_28;
  h_2 :
  e_2 :
  b_2 :
  Return();
  a_2 :
  MatchVard(0,4);
  Tpop();
  Tdupl();
  Rpush(i_2);
  r_28 :
  Cpush(k_2);
  Rpush(l_2);
  goto h_44;
  l_2 :
  Cpop();
  goto j_2;
  k_2 :
  Cpush(n_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-CL");
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(o_2);
  goto r_28;
  o_2 :
  AllBuild();
  Cpop();
  goto m_2;
  n_2 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(p_2);
  goto r_28;
  p_2 :
  m_2 :
  j_2 :
  Return();
  i_2 :
  MatchVard(0,5);
  Tpop();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  OneNextSon();
  Rpush(q_2);
  x_32 :
  Cpush(s_2);
  Rpush(t_2);
  goto h_44;
  t_2 :
  Cpop();
  goto r_2;
  s_2 :
  Cpush(c_3);
  Cpush(e_3);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-e");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,2);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto d_3;
  e_3 :
  Cpush(g_3);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-I");
  OneNextSon();
  MatchFun("Cons");
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto f_3;
  g_3 :
  Cpush(i_3);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-CI");
  OneNextSon();
  MatchFun("Cons");
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto h_3;
  i_3 :
  Cpush(k_3);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-CL");
  OneNextSon();
  MatchFun("Cons");
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto j_3;
  k_3 :
  Cpush(m_3);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-CC");
  MatchVard(0,6);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto l_3;
  m_3 :
  Cpush(o_3);
  Rpush(p_3);
  goto i_44;
  p_3 :
  Cpop();
  goto n_3;
  o_3 :
  Cpush(r_3);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-CC");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto q_3;
  r_3 :
  Cpush(t_3);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Cpush(v_3);
  MatchString("-h");
  Cpop();
  goto u_3;
  v_3 :
  Cpush(x_3);
  MatchString("-?");
  Cpop();
  goto w_3;
  x_3 :
  MatchString("--help");
  MatchVard(0,7);
  w_3 :
  u_3 :
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto s_3;
  t_3 :
  Cpush(z_3);
  Rpush(a_4);
  goto i_44;
  a_4 :
  Cpop();
  goto y_3;
  z_3 :
  Cpush(c_4);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  Cpush(e_4);
  MatchString("-h");
  Cpop();
  goto d_4;
  e_4 :
  Cpush(g_4);
  MatchString("-?");
  Cpop();
  goto f_4;
  g_4 :
  MatchString("--help");
  MatchVard(0,7);
  f_4 :
  d_4 :
  AllBuild();
  Cpop();
  goto b_4;
  c_4 :
  Cpush(i_4);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-norm");
  MatchVard(0,8);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto h_4;
  i_4 :
  Cpush(k_4);
  Rpush(l_4);
  goto i_44;
  l_4 :
  Cpop();
  goto j_4;
  k_4 :
  Cpush(n_4);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-norm");
  MatchVard(0,8);
  AllBuild();
  Cpop();
  goto m_4;
  n_4 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-i");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,9);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  m_4 :
  j_4 :
  h_4 :
  b_4 :
  y_3 :
  s_3 :
  q_3 :
  n_3 :
  l_3 :
  j_3 :
  h_3 :
  f_3 :
  d_3 :
  Rpush(o_4);
  goto x_32;
  o_4 :
  Cpop();
  goto u_2;
  c_3 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(p_4);
  goto x_32;
  p_4 :
  AllBuild();
  u_2 :
  r_2 :
  Return();
  q_2 :
  AllBuild();
  Epushd(1,3);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  BuildFun("TNil",0);
  Cpush(r_4);
  BuildVard(0,6);
  BuildFun("CC",0);
  Cpop();
  goto q_4;
  r_4 :
  BuildFun("ALL",0);
  q_4 :
  MatchVard(1,3);
  Epushd(2,1);
  BuildFun("TNil",0);
  Cpush(t_4);
  BuildVard(0,7);
  BuildFun("HELP",0);
  Cpop();
  goto s_4;
  t_4 :
  BuildFun("NOHELP",0);
  s_4 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildFun("TNil",0);
  Cpush(v_4);
  BuildVard(0,8);
  BuildFun("NORM",0);
  Cpop();
  goto u_4;
  v_4 :
  BuildFun("RM",0);
  u_4 :
  MatchVard(3,1);
  BuildVard(0,2);
  Tpush();
  BuildFun("ExecDir",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("InclDir",1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("CInclDir",1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("CLibDir",1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildStr(".r");
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,3);
  Epopd(0,9);
  Return();
  h_44 :
  MatchFun("Nil");
  Return();
  i_44 :
  MatchFun("None");
  Return();
  j_44 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : sc [-I dir] [-CI dir] [-CL dir] [-CC] [-h] spec");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(w_4);
  goto y_44;
  w_4 :
  Return();
  k_44 :
  Epushd(0,3);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(x_4);
  b_33 :
  Cpush(z_4);
  Rpush(a_5);
  goto h_44;
  a_5 :
  Cpop();
  goto y_4;
  z_4 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Cpush(c_5);
  Cpush(e_5);
  MatchFun("InclDir");
  TravInit();
  OneNextSon();
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto d_5;
  e_5 :
  MatchFun("ExecDir");
  TravInit();
  OneNextSon();
  MatchVard(0,3);
  AllBuild();
  d_5 :
  Cpop();
  goto b_5;
  c_5 :
  b_5 :
  OneNextSon();
  Rpush(f_5);
  goto b_33;
  f_5 :
  AllBuild();
  y_4 :
  Return();
  x_4 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_5);
  goto x_44;
  g_5 :
  AllBuild();
  AllBuild();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Epushd(1,2);
  Tdupl();
  Rpush(h_5);
  goto l_44;
  h_5 :
  MatchVard(1,1);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".tree");
  OneNextSon();
  Rpush(i_5);
  goto x_44;
  i_5 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(j_5);
  goto l_44;
  j_5 :
  MatchVard(1,2);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/parse-stratego");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,3);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(k_5);
  goto l_44;
  k_5 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildStr("-silent");
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Cons",2);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(l_5);
  h_34 :
  Cpush(n_5);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(o_5);
  goto h_34;
  o_5 :
  AllBuild();
  Cpop();
  goto m_5;
  n_5 :
  Rpush(p_5);
  goto h_44;
  p_5 :
  BuildVard(4,1);
  m_5 :
  Return();
  l_5 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(q_5);
  goto o_44;
  q_5 :
  Tpop();
  Epopd(1,2);
  OneNextSon();
  Rpush(r_5);
  goto x_44;
  r_5 :
  AllBuild();
  AllBuild();
  Epopd(0,3);
  Return();
  l_44 :
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(s_5);
  goto m_44;
  s_5 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(t_5);
  goto m_44;
  t_5 :
  OneNextSon();
  Rpush(u_5);
  goto x_44;
  u_5 :
  AllBuild();
  AllBuild();
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,2);
  Rpush(v_5);
  k_34 :
  Cpush(x_5);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(y_5);
  goto k_34;
  y_5 :
  AllBuild();
  Cpop();
  goto w_5;
  x_5 :
  Rpush(z_5);
  goto h_44;
  z_5 :
  BuildVard(0,1);
  w_5 :
  Return();
  v_5 :
  Epopd(0,2);
  Rpush(a_6);
  goto n_44;
  a_6 :
  Return();
  m_44 :
  _ST_explode_string();
  Return();
  n_44 :
  _ST_implode_string();
  Return();
  o_44 :
  _ST_call();
  Return();
  p_44 :
  Epushd(0,1);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(b_6);
  m_34 :
  Cpush(d_6);
  Rpush(e_6);
  goto h_44;
  e_6 :
  Cpop();
  goto c_6;
  d_6 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Cpush(g_6);
  MatchFun("ExecDir");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  AllBuild();
  Cpop();
  goto f_6;
  g_6 :
  f_6 :
  OneNextSon();
  Rpush(h_6);
  goto m_34;
  h_6 :
  AllBuild();
  c_6 :
  Return();
  b_6 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(i_6);
  goto x_44;
  i_6 :
  AllBuild();
  AllBuild();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Epushd(1,14);
  Tdupl();
  Rpush(j_6);
  goto l_44;
  j_6 :
  MatchVard(1,1);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".s");
  OneNextSon();
  Rpush(k_6);
  goto x_44;
  k_6 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(l_6);
  goto l_44;
  l_6 :
  MatchVard(1,2);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/frontend");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(m_6);
  goto l_44;
  m_6 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(n_6);
  c_42 :
  Cpush(p_6);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(q_6);
  goto c_42;
  q_6 :
  AllBuild();
  Cpop();
  goto o_6;
  p_6 :
  Rpush(r_6);
  goto h_44;
  r_6 :
  BuildVard(4,1);
  o_6 :
  Return();
  n_6 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(s_6);
  goto o_44;
  s_6 :
  Tpop();
  Tdupl();
  Rpush(t_6);
  goto l_44;
  t_6 :
  MatchVard(1,3);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".so1");
  OneNextSon();
  Rpush(u_6);
  goto x_44;
  u_6 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(v_6);
  goto l_44;
  v_6 :
  MatchVard(1,4);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/optimizer");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(w_6);
  goto l_44;
  w_6 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(x_6);
  d_42 :
  Cpush(z_6);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(a_7);
  goto d_42;
  a_7 :
  AllBuild();
  Cpop();
  goto y_6;
  z_6 :
  Rpush(b_7);
  goto h_44;
  b_7 :
  BuildVard(4,1);
  y_6 :
  Return();
  x_6 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(c_7);
  goto o_44;
  c_7 :
  Tpop();
  Tdupl();
  Rpush(d_7);
  goto l_44;
  d_7 :
  MatchVard(1,5);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".so2");
  OneNextSon();
  Rpush(e_7);
  goto x_44;
  e_7 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(f_7);
  goto l_44;
  f_7 :
  MatchVard(1,6);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/matching-tree");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(g_7);
  goto l_44;
  g_7 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,5);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,6);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(h_7);
  e_42 :
  Cpush(j_7);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(k_7);
  goto e_42;
  k_7 :
  AllBuild();
  Cpop();
  goto i_7;
  j_7 :
  Rpush(l_7);
  goto h_44;
  l_7 :
  BuildVard(4,1);
  i_7 :
  Return();
  h_7 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(m_7);
  goto o_44;
  m_7 :
  Tpop();
  Tdupl();
  Rpush(n_7);
  goto l_44;
  n_7 :
  MatchVard(1,7);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".so1");
  OneNextSon();
  Rpush(o_7);
  goto x_44;
  o_7 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(p_7);
  goto l_44;
  p_7 :
  MatchVard(1,8);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/optimizer");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(q_7);
  goto l_44;
  q_7 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,7);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,8);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(r_7);
  f_42 :
  Cpush(t_7);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(u_7);
  goto f_42;
  u_7 :
  AllBuild();
  Cpop();
  goto s_7;
  t_7 :
  Rpush(v_7);
  goto h_44;
  v_7 :
  BuildVard(4,1);
  s_7 :
  Return();
  r_7 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(w_7);
  goto o_44;
  w_7 :
  Tpop();
  Tdupl();
  Rpush(x_7);
  goto l_44;
  x_7 :
  MatchVard(1,9);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".i1");
  OneNextSon();
  Rpush(y_7);
  goto x_44;
  y_7 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(z_7);
  goto l_44;
  z_7 :
  MatchVard(1,10);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/backend");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(a_8);
  goto l_44;
  a_8 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,9);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,10);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(b_8);
  g_42 :
  Cpush(d_8);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(e_8);
  goto g_42;
  e_8 :
  AllBuild();
  Cpop();
  goto c_8;
  d_8 :
  Rpush(f_8);
  goto h_44;
  f_8 :
  BuildVard(4,1);
  c_8 :
  Return();
  b_8 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(g_8);
  goto o_44;
  g_8 :
  Tpop();
  Tdupl();
  Rpush(h_8);
  goto l_44;
  h_8 :
  MatchVard(1,11);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".i");
  OneNextSon();
  Rpush(i_8);
  goto x_44;
  i_8 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(j_8);
  goto l_44;
  j_8 :
  MatchVard(1,12);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("/postprocess");
  Epushd(3,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Rpush(k_8);
  goto l_44;
  k_8 :
  Epopd(3,1);
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,11);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,12);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(l_8);
  h_42 :
  Cpush(n_8);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(o_8);
  goto h_42;
  o_8 :
  AllBuild();
  Cpop();
  goto m_8;
  n_8 :
  Rpush(p_8);
  goto h_44;
  p_8 :
  BuildVard(4,1);
  m_8 :
  Return();
  l_8 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(q_8);
  goto o_44;
  q_8 :
  Tpop();
  Tdupl();
  Rpush(r_8);
  goto l_44;
  r_8 :
  MatchVard(1,13);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".c");
  OneNextSon();
  Rpush(s_8);
  goto x_44;
  s_8 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(t_8);
  goto l_44;
  t_8 :
  MatchVard(1,14);
  Tpop();
  Tdupl();
  Epushd(2,1);
  BuildFun("TNil",0);
  BuildStr("pp-instructions");
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  BuildFun("TNil",0);
  BuildFun("Nil",0);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildStr("-i");
  Tpush();
  BuildVard(1,13);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(1,14);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(u_8);
  i_42 :
  Cpush(w_8);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(x_8);
  goto i_42;
  x_8 :
  AllBuild();
  Cpop();
  goto v_8;
  w_8 :
  Rpush(y_8);
  goto h_44;
  y_8 :
  BuildVard(4,1);
  v_8 :
  Return();
  u_8 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Rpush(z_8);
  goto o_44;
  z_8 :
  Tpop();
  Epopd(1,14);
  OneNextSon();
  Rpush(a_9);
  goto x_44;
  a_9 :
  AllBuild();
  AllBuild();
  Epopd(0,1);
  Return();
  q_44 :
  Epushd(0,4);
  Tdupl();
  BuildFun("stderr",0);
  Tpush();
  BuildStr("compiling");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(b_9);
  goto y_44;
  b_9 :
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(c_9);
  k_42 :
  Cpush(e_9);
  Rpush(f_9);
  goto h_44;
  f_9 :
  Cpop();
  goto d_9;
  e_9 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Cpush(h_9);
  MatchFun("CInclDir");
  TravInit();
  OneNextSon();
  MatchVard(0,4);
  AllBuild();
  Cpop();
  goto g_9;
  h_9 :
  g_9 :
  OneNextSon();
  Rpush(i_9);
  goto k_42;
  i_9 :
  AllBuild();
  d_9 :
  Return();
  c_9 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(j_9);
  goto x_44;
  j_9 :
  AllBuild();
  AllBuild();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Tdupl();
  Rpush(k_9);
  goto l_44;
  k_9 :
  MatchVard(0,2);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr(".o");
  OneNextSon();
  Rpush(l_9);
  goto x_44;
  l_9 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(m_9);
  goto l_44;
  m_9 :
  MatchVard(0,3);
  Tpop();
  Tdupl();
  BuildVard(0,4);
  Tpush();
  BuildStr("-c");
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,2);
  Rpush(n_9);
  w_42 :
  Cpush(p_9);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(q_9);
  goto w_42;
  q_9 :
  AllBuild();
  Cpop();
  goto o_9;
  p_9 :
  Rpush(r_9);
  goto h_44;
  r_9 :
  BuildVard(1,1);
  o_9 :
  Return();
  n_9 :
  MatchVard(1,3);
  BuildStr("gcc");
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(s_9);
  goto o_44;
  s_9 :
  Epopd(1,3);
  Tpop();
  OneNextSon();
  Rpush(t_9);
  goto x_44;
  t_9 :
  AllBuild();
  AllBuild();
  Epopd(0,4);
  Return();
  r_44 :
  Epushd(0,4);
  Tdupl();
  BuildFun("stderr",0);
  Tpush();
  BuildStr("linking");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(u_9);
  goto y_44;
  u_9 :
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(v_9);
  y_42 :
  Cpush(x_9);
  Rpush(y_9);
  goto h_44;
  y_9 :
  Cpop();
  goto w_9;
  x_9 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Cpush(a_10);
  Cpush(l_10);
  MatchFun("Dir");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  AllBuild();
  Cpop();
  goto b_10;
  l_10 :
  MatchFun("CLibDir");
  TravInit();
  OneNextSon();
  MatchVard(0,4);
  AllBuild();
  b_10 :
  Cpop();
  goto z_9;
  a_10 :
  z_9 :
  OneNextSon();
  Rpush(m_10);
  goto y_42;
  m_10 :
  AllBuild();
  w_9 :
  Return();
  v_9 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(n_10);
  goto x_44;
  n_10 :
  AllBuild();
  AllBuild();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Tdupl();
  Rpush(o_10);
  goto l_44;
  o_10 :
  MatchVard(0,2);
  Tpop();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  BuildStr("");
  OneNextSon();
  Rpush(p_10);
  goto x_44;
  p_10 :
  AllBuild();
  AllBuild();
  Tdupl();
  Rpush(q_10);
  goto l_44;
  q_10 :
  MatchVard(0,3);
  Tpop();
  Tdupl();
  Epushd(1,4);
  BuildVard(0,4);
  Rpush(r_10);
  o_43 :
  Cpush(w_10);
  Rpush(x_10);
  goto h_44;
  x_10 :
  Cpop();
  goto s_10;
  w_10 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(y_10);
  goto s_44;
  y_10 :
  OneNextSon();
  Rpush(z_10);
  goto o_43;
  z_10 :
  AllBuild();
  s_10 :
  Return();
  r_10 :
  Rpush(a_11);
  goto w_44;
  a_11 :
  MatchVard(1,1);
  BuildVard(0,2);
  Tpush();
  BuildStr("-o");
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,3);
  Rpush(b_11);
  p_43 :
  Cpush(d_11);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(e_11);
  goto p_43;
  e_11 :
  AllBuild();
  Cpop();
  goto c_11;
  d_11 :
  Rpush(f_11);
  goto h_44;
  f_11 :
  BuildVard(1,2);
  c_11 :
  Return();
  b_11 :
  MatchVard(1,4);
  BuildStr("gcc");
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(g_11);
  goto o_44;
  g_11 :
  Epopd(1,4);
  Tpop();
  OneNextSon();
  Rpush(h_11);
  goto x_44;
  h_11 :
  AllBuild();
  AllBuild();
  Epopd(0,4);
  Return();
  s_44 :
  Rpush(i_11);
  goto m_44;
  i_11 :
  Epushd(0,1);
  MatchVard(0,1);
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,1);
  Rpush(j_11);
  p_15 :
  Cpush(l_11);
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(m_11);
  goto t_44;
  m_11 :
  Rpush(n_11);
  goto n_44;
  n_11 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Rpush(o_11);
  goto t_44;
  o_11 :
  Epopd(0,2);
  Cpop();
  goto k_11;
  l_11 :
  Rpush(p_11);
  goto u_44;
  p_11 :
  Rpush(q_11);
  goto p_15;
  q_11 :
  k_11 :
  Return();
  j_11 :
  Return();
  t_44 :
  Epushd(0,1);
  MatchVard(0,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,1);
  Cpush(s_11);
  r_11 :
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,3);
  Tduplinv();
  goto r_11;
  s_11 :
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Return();
  u_44 :
  Cpush(u_11);
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchInt(32);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(v_11);
  goto t_44;
  v_11 :
  Rpush(w_11);
  goto n_44;
  w_11 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Epopd(0,3);
  Cpop();
  goto t_11;
  u_11 :
  Epushd(0,4);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,4);
  Tpush();
  BuildInt(32);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(x_11);
  Tdupl();
  Rpush(y_11);
  goto v_44;
  y_11 :
  Cpop();
  Crestore();
  Cjump();
  x_11 :
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,4);
  t_11 :
  Return();
  v_44 :
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epopd(0,1);
  Return();
  w_44 :
  Rpush(z_11);
  i_19 :
  Cpush(b_12);
  Rpush(c_12);
  goto h_44;
  c_12 :
  Cpop();
  goto a_12;
  b_12 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  Rpush(d_12);
  f_44 :
  Cpush(f_12);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_12);
  goto f_44;
  g_12 :
  AllBuild();
  Cpop();
  goto e_12;
  f_12 :
  Rpush(h_12);
  goto h_44;
  h_12 :
  BuildVard(0,1);
  Rpush(i_12);
  goto i_19;
  i_12 :
  e_12 :
  Return();
  d_12 :
  Epopd(0,2);
  a_12 :
  Return();
  z_11 :
  Return();
  x_44 :
  MatchFun("TNil");
  Return();
  y_44 :
  _ST_printnl();
  Return();
  z_44 :
  _ST_exit();
  Return();
  j_12 :
DOIT_END
