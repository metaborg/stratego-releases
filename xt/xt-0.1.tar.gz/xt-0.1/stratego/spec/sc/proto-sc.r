\literate[{\tt SC}: Stratego Compiler]

% Copyright (C) 1998, 1999, 2000 Eelco Visser <visser@acm.org>
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
% 02111-1307, USA.


\begin{code}
module sc
imports lib
signature
  sorts Option
  operations
    Dir      : String -> Option
    ExecDir  : String -> Option
    InclDir  : String -> Option
    CInclDir : String -> Option
    CLibDir  : String -> Option
strategies

  main = process-options;
	 (((fetch(?HELP()), id); sc-usage) <+ (
	 ((fetch(?CC()), (id, !".c"))
	  <+ (parse;
              core));
	 cc1; 
         cc2;
         (fetch(?NORM()), id) <+ (id, remove-intermediates);
         <printnl>(stderr, ["compilation succeeded"]);
	 <exit> 0
	 ))
\end{code}

	Processing the command-line options

\begin{code}
rules

  process-options ::
  (* { prog, dir, incl, execdir, name, cc, help, cincl, clib, norm: *)

    where(filter-options(?"-I") => incl);
    where(filter-option-args(?"-CI") => cincl);
    where(filter-option-args(?"-CL") => clib);
    options(?prog, 
                 ( aoption("-e", ?execdir)
		 + aoption("-I", id)
		 + aoption("-CI", id)
		 + aoption("-CL", id)
		 + option("-CC"; ?cc)
		 + option("-h" + "-?" + "--help"; ?help)
		 + option("-norm"; ?norm)
		 + aoption("-i", ?name)
                 ))
    -->
    !([ExecDir(execdir),
       InclDir(incl),
       CInclDir(cincl), CLibDir(clib), 
       <!cc; !CC() <+ !ALL()>(),
       <!help; !HELP() <+ !NOHELP()>(),
       <!norm; !NORM() <+ !RM()>()], 
      (name, ".r"))
  (* } *)

strategies

  sc-usage = 
	<printnl>(stderr, 
		  ["usage : sc [-I dir] [-CI dir] [-CL dir] [-CC] [-h] spec"])
\end{code}

	Parsing specifications

\begin{code}
strategies

  parse = 
  { dir, incl, edir :
    (list(try(InclDir(?incl) + ExecDir(?edir))), id);
    (id, pipe'(<pref(!edir)> "/parse-stratego", !".tree", 
	       !Cons("-silent", incl)))
  }
\end{code}

	The core of the compiler consists of the components that
	transform a specification to abstract machine instructions.

\begin{code}
strategies

  core = 
  { dir :
    (list(try(ExecDir(?dir))), id);
    (id, frontend(!dir);
         optimizer(!dir);
         matching-tree(!dir);
         optimizer(!dir);
         backend(!dir);
         postprocess(!dir);
         pp-instructions(!dir)
    )}

  pref(d) = {x: ?x; <conc-strings>(<d>(), x)}

  frontend(d)        = pipe(<pref(d)> "/frontend",      !".s")
  optimizer(d)       = pipe(<pref(d)> "/optimizer",     !".so1")
  matching-tree(d)   = pipe(<pref(d)> "/matching-tree", !".so2")
  backend(d)         = pipe(<pref(d)> "/backend",       !".i1")
  postprocess(d)     = pipe(<pref(d)> "/postprocess",   !".i")
  pp-instructions(d) = pipe(!"pp-instructions",    !".c")
	  (* pipe(<pref(d)> "pp-instructions",    !".c")/*)
\end{code}

\begin{code}
strategies

rules

  I-option : x -> <conc-strings>("-I", x)
  L-option : x -> <conc-strings>("-L", x)

strategies

  lib(d)      = <conc-strings>(<d>(), "/lib")
  liblib(d)   = <conc-strings>(<lib(d)>(), "/lib")
  include(d)  = <conc-strings>(<lib(d)>(), "/include")
  libstrat(d) = <conc-strings>(<lib(d)>(), "/stratego")
  
  gcc = {args: ?args; <call>("gcc", args)}

  cc1 = {
          dir, cfile, target, cincl: 
	  where(<printnl>(stderr, ["compiling"]));
	  (list(try(CInclDir(?cincl))), id); (id, 
          where(conc-strings => cfile);
          (id, !".o");        
          where(conc-strings => target);
          where(<gcc> <conc> (cincl,["-c", cfile,"-o", target]))
	)}

  cc2 = {
          dir, ofile, target, clib: 
	  where(<printnl>(stderr, ["linking"]));
	  (list(try(Dir(?dir) + CLibDir(?clib))), id); (id, 
          where(conc-strings => ofile);
          (id, !""); 
          where(conc-strings => target);
          where(<gcc> <conc>([ofile, "-o", target], 
			     <map(split-at-space); concat> clib))
        )}
\end{code}

\begin{code}
rules

  remove-intermediates ::
    ?(base, _) -->
    <call> ("rm", <rzip(conc-strings)> (base, 
	    [".tree", ".s", ".so1", ".so2", ".i1", ".i", ".o"]))
\end{code}
