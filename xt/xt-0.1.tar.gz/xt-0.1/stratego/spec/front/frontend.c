#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(a_49);
  goto main;
  main :
  Epushd(0,9);
  Cpush(n_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  OneNextSon();
  Rpush(o_0);
  r_61 :
  Cpush(q_0);
  Rpush(r_0);
  goto m_112;
  r_0 :
  Cpop();
  goto p_0;
  q_0 :
  Cpush(t_0);
  Cpush(v_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto u_0;
  v_0 :
  Cpush(x_0);
  Rpush(y_0);
  goto n_112;
  y_0 :
  Cpop();
  goto w_0;
  x_0 :
  Cpush(a_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto z_0;
  a_1 :
  Cpush(c_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto b_1;
  c_1 :
  Cpush(e_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-i");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,3);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto d_1;
  e_1 :
  Cpush(g_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-o");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,4);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto f_1;
  g_1 :
  Cpush(i_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto h_1;
  i_1 :
  Cpush(k_1);
  Rpush(l_1);
  goto n_112;
  l_1 :
  Cpop();
  goto j_1;
  k_1 :
  Cpush(n_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto m_1;
  n_1 :
  Cpush(p_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto o_1;
  p_1 :
  Cpush(r_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto q_1;
  r_1 :
  Cpush(t_1);
  Rpush(u_1);
  goto n_112;
  u_1 :
  Cpop();
  goto s_1;
  t_1 :
  Cpush(w_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto v_1;
  w_1 :
  Cpush(y_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto x_1;
  y_1 :
  Cpush(a_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto z_1;
  a_2 :
  Cpush(c_2);
  Rpush(d_2);
  goto n_112;
  d_2 :
  Cpop();
  goto b_2;
  c_2 :
  Cpush(f_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto e_2;
  f_2 :
  Cpush(h_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto g_2;
  h_2 :
  Cpush(j_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto i_2;
  j_2 :
  Cpush(l_2);
  Rpush(m_2);
  goto n_112;
  m_2 :
  Cpop();
  goto k_2;
  l_2 :
  Cpush(o_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto n_2;
  o_2 :
  Cpush(q_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto p_2;
  q_2 :
  Cpush(s_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto r_2;
  s_2 :
  Cpush(u_2);
  Rpush(v_2);
  goto n_112;
  v_2 :
  Cpop();
  goto t_2;
  u_2 :
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  AllBuild();
  t_2 :
  r_2 :
  p_2 :
  n_2 :
  k_2 :
  i_2 :
  g_2 :
  e_2 :
  b_2 :
  z_1 :
  x_1 :
  v_1 :
  s_1 :
  q_1 :
  o_1 :
  m_1 :
  j_1 :
  h_1 :
  f_1 :
  d_1 :
  b_1 :
  z_0 :
  w_0 :
  u_0 :
  Rpush(w_2);
  goto r_61;
  w_2 :
  Cpop();
  goto s_0;
  t_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(x_2);
  goto r_61;
  x_2 :
  AllBuild();
  s_0 :
  p_0 :
  Return();
  o_0 :
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto m_0;
  n_0 :
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildStr("");
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(y_2);
  goto t_112;
  y_2 :
  Tpop();
  Rpush(z_2);
  goto o_112;
  z_2 :
  BuildInt(1);
  Rpush(a_3);
  goto u_112;
  a_3 :
  m_0 :
  Cpush(c_3);
  Tdupl();
  BuildVard(0,7);
  Tpop();
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(d_3);
  goto t_112;
  d_3 :
  Tpop();
  Rpush(e_3);
  goto o_112;
  e_3 :
  BuildInt(1);
  Rpush(f_3);
  goto u_112;
  f_3 :
  Cpop();
  goto b_3;
  c_3 :
  Cpush(h_3);
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  Cpush(j_3);
  BuildVard(0,3);
  Cpop();
  goto i_3;
  j_3 :
  BuildFun("stdin",0);
  i_3 :
  Rpush(k_3);
  goto p_112;
  k_3 :
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Tdupl();
  Rpush(l_3);
  goto q_112;
  l_3 :
  Tpop();
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Rpush(m_3);
  goto v_112;
  m_3 :
  Tdupl();
  Rpush(n_3);
  goto q_112;
  n_3 :
  MatchVard(0,9);
  Tpop();
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(p_3);
  BuildVard(0,4);
  Cpop();
  goto o_3;
  p_3 :
  BuildFun("stdout",0);
  o_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(r_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(s_3);
  goto r_112;
  s_3 :
  Cpop();
  goto q_3;
  r_3 :
  Rpush(t_3);
  goto s_112;
  t_3 :
  q_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting succeeded (");
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildStr(" secs)");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(u_3);
  goto t_112;
  u_3 :
  BuildInt(0);
  Rpush(v_3);
  goto u_112;
  v_3 :
  Cpop();
  goto g_3;
  h_3 :
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(x_3);
  BuildVard(0,4);
  Cpop();
  goto w_3;
  x_3 :
  BuildFun("stdout",0);
  w_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(z_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(a_4);
  goto r_112;
  a_4 :
  Cpop();
  goto y_3;
  z_3 :
  Rpush(b_4);
  goto s_112;
  b_4 :
  y_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(c_4);
  goto t_112;
  c_4 :
  BuildInt(1);
  Rpush(d_4);
  goto u_112;
  d_4 :
  g_3 :
  b_3 :
  Epopd(0,9);
  Return();
  m_112 :
  MatchFun("Nil");
  Return();
  n_112 :
  MatchFun("None");
  Return();
  o_112 :
  Tdupl();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stderr",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  Epushd(3,1);
  MatchVard(3,1);
  BuildVard(3,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(e_4);
  goto t_112;
  e_4 :
  Tpop();
  Return();
  p_112 :
  _ST_ReadFromFile();
  Return();
  q_112 :
  _ST_dtime();
  Return();
  r_112 :
  _ST_WriteToBinaryFile();
  Return();
  s_112 :
  _ST_WriteToTextFile();
  Return();
  t_112 :
  _ST_printnl();
  Return();
  u_112 :
  _ST_exit();
  Return();
  v_112 :
  Rpush(f_4);
  goto w_112;
  f_4 :
  Tdupl();
  Rpush(g_4);
  goto k_113;
  g_4 :
  Tpop();
  Rpush(h_4);
  goto x_113;
  h_4 :
  Rpush(i_4);
  goto h_114;
  i_4 :
  Rpush(j_4);
  goto l_114;
  j_4 :
  Rpush(k_4);
  goto w_114;
  k_4 :
  Return();
  w_112 :
  Epushd(0,1);
  MatchFun("Specification");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Rpush(l_4);
  o_62 :
  Cpush(n_4);
  Rpush(o_4);
  goto m_112;
  o_4 :
  Cpop();
  goto m_4;
  n_4 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(p_4);
  goto x_112;
  p_4 :
  OneNextSon();
  Rpush(q_4);
  goto o_62;
  q_4 :
  AllBuild();
  m_4 :
  Return();
  l_4 :
  Rpush(r_4);
  n_63 :
  Cpush(t_4);
  Rpush(u_4);
  goto m_112;
  u_4 :
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpop();
  goto s_4;
  t_4 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(v_4);
  goto n_63;
  v_4 :
  OneNextSon();
  Rpush(w_4);
  goto b_113;
  w_4 :
  AllBuild();
  AllBuild();
  Epushd(0,8);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,7);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,6);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,8);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(x_4);
  k_64 :
  Cpush(z_4);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(a_5);
  goto k_64;
  a_5 :
  AllBuild();
  Cpop();
  goto y_4;
  z_4 :
  Rpush(b_5);
  goto m_112;
  b_5 :
  BuildVard(2,1);
  y_4 :
  Return();
  x_4 :
  Epopd(2,2);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(3,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(3,2);
  Rpush(c_5);
  l_64 :
  Cpush(e_5);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(f_5);
  goto l_64;
  f_5 :
  AllBuild();
  Cpop();
  goto d_5;
  e_5 :
  Rpush(g_5);
  goto m_112;
  g_5 :
  BuildVard(3,1);
  d_5 :
  Return();
  c_5 :
  Epopd(3,2);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(h_5);
  m_64 :
  Cpush(j_5);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(k_5);
  goto m_64;
  k_5 :
  AllBuild();
  Cpop();
  goto i_5;
  j_5 :
  Rpush(l_5);
  goto m_112;
  l_5 :
  BuildVard(4,1);
  i_5 :
  Return();
  h_5 :
  Epopd(4,2);
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(0,7);
  Tpush();
  BuildVard(0,8);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(5,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(5,2);
  Rpush(m_5);
  n_64 :
  Cpush(o_5);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(p_5);
  goto n_64;
  p_5 :
  AllBuild();
  Cpop();
  goto n_5;
  o_5 :
  Rpush(q_5);
  goto m_112;
  q_5 :
  BuildVard(5,1);
  n_5 :
  Return();
  m_5 :
  Epopd(5,2);
  MatchVard(4,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,8);
  s_4 :
  Return();
  r_4 :
  Epushd(0,4);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Operations",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Signature",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Overlays",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Rules",1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Strategies",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Specification",1);
  Epopd(0,4);
  MatchFun("Specification");
  TravInit();
  OneNextSon();
  Rpush(r_5);
  goto c_113;
  r_5 :
  AllBuild();
  Rpush(s_5);
  goto f_113;
  s_5 :
  Return();
  x_112 :
  Epushd(0,4);
  MatchFunFC("Signature",&&y_5);
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Rpush(z_5);
  goto a_0;
  z_5 :
  goto x_5;
  y_5 :
  MatchFunFC("Strategies",&&a_6);
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Rpush(b_6);
  goto b_0;
  b_6 :
  goto x_5;
  a_6 :
  MatchFunFC("Rules",&&c_6);
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Rpush(d_6);
  goto c_0;
  d_6 :
  goto x_5;
  c_6 :
  MatchFunFC("Overlays",&&e_6);
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Rpush(f_6);
  goto d_0;
  f_6 :
  goto x_5;
  e_6 :
  goto fail;
  x_5 :
  goto w_5;
  d_0 :
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Return();
  w_5 :
  goto v_5;
  c_0 :
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Return();
  v_5 :
  goto u_5;
  b_0 :
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Return();
  u_5 :
  goto t_5;
  a_0 :
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(g_6);
  goto y_112;
  g_6 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Return();
  t_5 :
  Epopd(0,4);
  Return();
  y_112 :
  Rpush(h_6);
  s_64 :
  Cpush(j_6);
  Rpush(k_6);
  goto m_112;
  k_6 :
  Cpop();
  goto i_6;
  j_6 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(l_6);
  goto z_112;
  l_6 :
  OneNextSon();
  Rpush(m_6);
  goto s_64;
  m_6 :
  AllBuild();
  i_6 :
  Return();
  h_6 :
  Rpush(n_6);
  goto a_113;
  n_6 :
  Return();
  z_112 :
  Epushd(0,2);
  MatchFunFC("Operations",&&r_6);
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Rpush(s_6);
  goto e_0;
  s_6 :
  goto q_6;
  r_6 :
  MatchFunFC("Sorts",&&t_6);
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Rpush(u_6);
  goto f_0;
  u_6 :
  goto q_6;
  t_6 :
  goto fail;
  q_6 :
  goto p_6;
  f_0 :
  BuildFun("Nil",0);
  Return();
  p_6 :
  goto o_6;
  e_0 :
  BuildVard(0,1);
  Return();
  o_6 :
  Epopd(0,2);
  Return();
  a_113 :
  Rpush(v_6);
  b_38 :
  Cpush(x_6);
  Rpush(y_6);
  goto m_112;
  y_6 :
  Cpop();
  goto w_6;
  x_6 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  Rpush(z_6);
  v_64 :
  Cpush(b_7);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(c_7);
  goto v_64;
  c_7 :
  AllBuild();
  Cpop();
  goto a_7;
  b_7 :
  Rpush(d_7);
  goto m_112;
  d_7 :
  BuildVard(0,1);
  Rpush(e_7);
  goto b_38;
  e_7 :
  a_7 :
  Return();
  z_6 :
  Epopd(0,2);
  w_6 :
  Return();
  v_6 :
  Return();
  b_113 :
  MatchFun("TNil");
  Return();
  c_113 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Cpush(g_7);
  Rpush(h_7);
  v_65 :
  Cpush(j_7);
  Rpush(k_7);
  goto m_112;
  k_7 :
  Cpop();
  goto i_7;
  j_7 :
  Cpush(m_7);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(n_7);
  goto d_113;
  n_7 :
  OneNextSon();
  Rpush(o_7);
  goto v_65;
  o_7 :
  AllBuild();
  Cpop();
  goto l_7;
  m_7 :
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  Rpush(p_7);
  goto v_65;
  p_7 :
  l_7 :
  i_7 :
  Return();
  h_7 :
  Cpop();
  goto f_7;
  g_7 :
  Rpush(q_7);
  w_65 :
  Cpush(s_7);
  Rpush(t_7);
  goto m_112;
  t_7 :
  Cpop();
  goto r_7;
  s_7 :
  Cpush(v_7);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(w_7);
  goto d_113;
  w_7 :
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(x_7);
  goto w_65;
  x_7 :
  AllBuild();
  Cpop();
  goto u_7;
  v_7 :
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  Rpush(y_7);
  goto w_65;
  y_7 :
  u_7 :
  r_7 :
  Return();
  q_7 :
  f_7 :
  Rpush(z_7);
  goto a_113;
  z_7 :
  Epushd(2,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(2,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(2,1);
  Rpush(a_8);
  x_65 :
  Cpush(c_8);
  Rpush(m_8);
  goto m_112;
  m_8 :
  Cpop();
  goto b_8;
  c_8 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(5,1);
  MatchVard(5,1);
  BuildVard(5,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Op",2);
  Epopd(5,1);
  OneNextSon();
  Rpush(n_8);
  goto x_65;
  n_8 :
  AllBuild();
  b_8 :
  Return();
  a_8 :
  MatchVard(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epopd(3,1);
  Epopd(2,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,3);
  Rpush(o_8);
  goto e_113;
  o_8 :
  Return();
  d_113 :
  Epushd(0,2);
  MatchFunFC("Signature",&&s_8);
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Rpush(t_8);
  goto g_0;
  t_8 :
  goto r_8;
  s_8 :
  MatchFunFC("Overlays",&&u_8);
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Rpush(v_8);
  goto h_0;
  v_8 :
  goto r_8;
  u_8 :
  goto fail;
  r_8 :
  goto q_8;
  h_0 :
  BuildVard(0,2);
  Cpush(x_8);
  Rpush(y_8);
  p_68 :
  Cpush(a_9);
  Rpush(b_9);
  goto m_112;
  b_9 :
  Cpop();
  goto z_8;
  a_9 :
  Cpush(d_9);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,2);
  MatchFun("Overlay");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  Arg(2);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  OneNextSon();
  Rpush(e_9);
  goto p_68;
  e_9 :
  AllBuild();
  Cpop();
  goto c_9;
  d_9 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(f_9);
  goto p_68;
  f_9 :
  c_9 :
  z_8 :
  Return();
  y_8 :
  Cpop();
  goto w_8;
  x_8 :
  Rpush(g_9);
  a_69 :
  Cpush(i_9);
  Rpush(j_9);
  goto m_112;
  j_9 :
  Cpop();
  goto h_9;
  i_9 :
  Cpush(l_9);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,2);
  MatchFun("Overlay");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  Arg(2);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(m_9);
  goto a_69;
  m_9 :
  AllBuild();
  Cpop();
  goto k_9;
  l_9 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(n_9);
  goto a_69;
  n_9 :
  k_9 :
  h_9 :
  Return();
  g_9 :
  w_8 :
  Return();
  q_8 :
  goto p_8;
  g_0 :
  BuildVard(0,1);
  Cpush(p_9);
  Rpush(q_9);
  o_66 :
  Cpush(b_10);
  Rpush(c_10);
  goto m_112;
  c_10 :
  Cpop();
  goto a_10;
  b_10 :
  Cpush(e_10);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchFun("Operations");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,1);
  Cpush(g_10);
  Rpush(h_10);
  f_67 :
  Cpush(j_10);
  Rpush(k_10);
  goto m_112;
  k_10 :
  Cpop();
  goto i_10;
  j_10 :
  Cpush(m_10);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchFun("OpDecl");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("ConstType");
  Arg(0);
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,1);
  OneNextSon();
  Rpush(n_10);
  goto f_67;
  n_10 :
  AllBuild();
  Cpop();
  goto l_10;
  m_10 :
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  Rpush(x_10);
  goto f_67;
  x_10 :
  l_10 :
  i_10 :
  Return();
  h_10 :
  Cpop();
  goto f_10;
  g_10 :
  Rpush(y_10);
  g_67 :
  Cpush(t_11);
  Rpush(g_12);
  goto m_112;
  g_12 :
  Cpop();
  goto s_11;
  t_11 :
  Cpush(i_12);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchFun("OpDecl");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("ConstType");
  Arg(0);
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,1);
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(j_12);
  goto g_67;
  j_12 :
  AllBuild();
  Cpop();
  goto h_12;
  i_12 :
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  Rpush(k_12);
  goto g_67;
  k_12 :
  h_12 :
  s_11 :
  Return();
  y_10 :
  f_10 :
  Epopd(1,1);
  OneNextSon();
  Rpush(l_12);
  goto o_66;
  l_12 :
  AllBuild();
  Cpop();
  goto d_10;
  e_10 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(u_13);
  goto o_66;
  u_13 :
  d_10 :
  a_10 :
  Return();
  q_9 :
  Cpop();
  goto o_9;
  p_9 :
  Rpush(v_13);
  b_68 :
  Cpush(x_13);
  Rpush(y_13);
  goto m_112;
  y_13 :
  Cpop();
  goto w_13;
  x_13 :
  Cpush(a_14);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchFun("Operations");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,1);
  Cpush(c_14);
  Rpush(d_14);
  j_68 :
  Cpush(f_14);
  Rpush(g_14);
  goto m_112;
  g_14 :
  Cpop();
  goto e_14;
  f_14 :
  Cpush(i_14);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchFun("OpDecl");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("ConstType");
  Arg(0);
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,1);
  OneNextSon();
  Rpush(j_14);
  goto j_68;
  j_14 :
  AllBuild();
  Cpop();
  goto h_14;
  i_14 :
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  Rpush(k_14);
  goto j_68;
  k_14 :
  h_14 :
  e_14 :
  Return();
  d_14 :
  Cpop();
  goto b_14;
  c_14 :
  Rpush(l_14);
  k_68 :
  Cpush(n_14);
  Rpush(o_14);
  goto m_112;
  o_14 :
  Cpop();
  goto m_14;
  n_14 :
  Cpush(q_14);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchFun("OpDecl");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("ConstType");
  Arg(0);
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,1);
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(r_14);
  goto k_68;
  r_14 :
  AllBuild();
  Cpop();
  goto p_14;
  q_14 :
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  Rpush(s_14);
  goto k_68;
  s_14 :
  p_14 :
  m_14 :
  Return();
  l_14 :
  b_14 :
  Epopd(1,1);
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(t_14);
  goto b_68;
  t_14 :
  AllBuild();
  Cpop();
  goto z_13;
  a_14 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(u_14);
  goto b_68;
  u_14 :
  z_13 :
  w_13 :
  Return();
  v_13 :
  o_9 :
  Rpush(v_14);
  goto a_113;
  v_14 :
  Return();
  p_8 :
  Epopd(0,2);
  Return();
  e_113 :
  Epushd(0,4);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(w_14);
  m_69 :
  Cpush(y_14);
  Epushd(1,0);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildFun("Nil",0);
  Epopd(1,0);
  Cpop();
  goto x_14;
  y_14 :
  Epushd(1,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,4);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(z_14);
  goto m_69;
  z_14 :
  OneNextSon();
  Rpush(a_15);
  goto b_113;
  a_15 :
  AllBuild();
  AllBuild();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,2);
  x_14 :
  Return();
  w_14 :
  MatchVard(0,1);
  BuildVard(0,4);
  Rpush(b_15);
  v_69 :
  Cpush(d_15);
  Epushd(1,3);
  MatchFun("Var");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,1);
  MatchVard(1,2);
  Tdupl();
  BuildVard(0,1);
  Tdupl();
  e_15 :
  MatchFun("Cons");
  Cpush(f_15);
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Cpop();
  goto g_15;
  f_15 :
  Arg(1);
  Tdrop();
  goto e_15;
  g_15 :
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Cpop();
  goto c_15;
  d_15 :
  AllInit();
  h_15 :
  AllNextSon(&&i_15);
  Rpush(j_15);
  goto v_69;
  j_15 :
  goto h_15;
  i_15 :
  AllBuild();
  c_15 :
  Return();
  b_15 :
  Epopd(0,4);
  Return();
  f_113 :
  Rpush(k_15);
  i_70 :
  Cpush(m_15);
  Epushd(0,3);
  MatchFun("LRule");
  Arg(0);
  MatchFun("Rule");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(n_15);
  goto g_113;
  n_15 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Rule",3);
  Tpush();
  BuildFun("SRule",1);
  Tpush();
  BuildFun("Scope",2);
  Epopd(1,1);
  Epopd(0,3);
  Cpop();
  goto l_15;
  m_15 :
  l_15 :
  AllInit();
  o_15 :
  AllNextSon(&&p_15);
  Rpush(q_15);
  goto i_70;
  q_15 :
  goto o_15;
  p_15 :
  AllBuild();
  Return();
  k_15 :
  Return();
  g_113 :
  Rpush(r_15);
  q_70 :
  Cpush(t_15);
  Epushd(0,1);
  MatchFun("Var");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto s_15;
  t_15 :
  Epushd(0,2);
  Tdupl();
  Rpush(u_15);
  goto h_113;
  u_15 :
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Rpush(v_15);
  v_70 :
  Cpush(x_15);
  Rpush(y_15);
  goto m_112;
  y_15 :
  Cpop();
  goto w_15;
  x_15 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(z_15);
  goto q_70;
  z_15 :
  OneNextSon();
  Rpush(a_16);
  goto v_70;
  a_16 :
  AllBuild();
  w_15 :
  Return();
  v_15 :
  Rpush(b_16);
  c_71 :
  Cpush(d_16);
  Rpush(e_16);
  goto m_112;
  e_16 :
  BuildFun("Nil",0);
  Cpop();
  goto c_16;
  d_16 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(f_16);
  goto c_71;
  f_16 :
  OneNextSon();
  Rpush(g_16);
  goto b_113;
  g_16 :
  AllBuild();
  AllBuild();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Rpush(h_16);
  j_71 :
  Cpush(j_16);
  Rpush(k_16);
  goto m_112;
  k_16 :
  BuildVard(1,2);
  Cpop();
  goto i_16;
  j_16 :
  Cpush(m_16);
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  Tdupl();
  BuildVard(1,2);
  Tdupl();
  n_16 :
  MatchFun("Cons");
  Cpush(o_16);
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Cpop();
  goto p_16;
  o_16 :
  Arg(1);
  Tdrop();
  goto n_16;
  p_16 :
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,2);
  Rpush(q_16);
  goto j_71;
  q_16 :
  Cpop();
  goto l_16;
  m_16 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(r_16);
  goto j_71;
  r_16 :
  AllBuild();
  l_16 :
  i_16 :
  Return();
  h_16 :
  Epopd(1,2);
  c_16 :
  Return();
  b_16 :
  MatchVard(0,1);
  Tpop();
  Cpush(t_16);
  Rpush(u_16);
  goto j_113;
  u_16 :
  MatchVard(0,2);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(v_16);
  goto i_113;
  v_16 :
  Cpop();
  goto s_16;
  t_16 :
  BuildVard(0,1);
  s_16 :
  Epopd(0,2);
  s_15 :
  Return();
  r_15 :
  Return();
  h_113 :
  _ST_explode_term();
  Return();
  i_113 :
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Rpush(w_16);
  j_36 :
  Cpush(y_16);
  Rpush(z_16);
  goto m_112;
  z_16 :
  Cpop();
  goto x_16;
  y_16 :
  Cpush(b_17);
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tdupl();
  c_17 :
  MatchFun("Cons");
  Cpush(d_17);
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Cpop();
  goto e_17;
  d_17 :
  Arg(1);
  Tdrop();
  goto c_17;
  e_17 :
  Tpop();
  Tpop();
  BuildVard(1,1);
  Epopd(1,2);
  Rpush(f_17);
  goto j_36;
  f_17 :
  Cpop();
  goto a_17;
  b_17 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_17);
  goto j_36;
  g_17 :
  AllBuild();
  a_17 :
  x_16 :
  Return();
  w_16 :
  Epopd(0,2);
  Return();
  j_113 :
  Cpush(i_17);
  Epushd(0,2);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  Epopd(0,2);
  Cpop();
  goto h_17;
  i_17 :
  Epushd(0,3);
  MatchFun("LRule");
  Arg(0);
  MatchFun("Rule");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,3);
  Rpush(j_17);
  goto g_113;
  j_17 :
  Epopd(0,3);
  h_17 :
  Return();
  k_113 :
  MatchFun("Specification");
  TravInit();
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("Signature");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("Overlays");
  TravInit();
  OneNextSon();
  Rpush(k_17);
  goto l_113;
  k_17 :
  AllBuild();
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("Rules");
  TravInit();
  OneNextSon();
  Rpush(l_17);
  goto l_113;
  l_17 :
  AllBuild();
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("Strategies");
  TravInit();
  OneNextSon();
  Rpush(m_17);
  goto l_113;
  m_17 :
  AllBuild();
  OneNextSon();
  Rpush(n_17);
  goto m_112;
  n_17 :
  AllBuild();
  AllBuild();
  AllBuild();
  AllBuild();
  AllBuild();
  Return();
  l_113 :
  Cpush(p_17);
  Rpush(q_17);
  o_71 :
  Cpush(s_17);
  Rpush(t_17);
  goto m_112;
  t_17 :
  Cpop();
  goto r_17;
  s_17 :
  Cpush(v_17);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(w_17);
  goto m_113;
  w_17 :
  OneNextSon();
  Rpush(x_17);
  goto o_71;
  x_17 :
  AllBuild();
  Cpop();
  goto u_17;
  v_17 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,2);
  Epopd(0,2);
  Rpush(y_17);
  goto o_71;
  y_17 :
  u_17 :
  r_17 :
  Return();
  q_17 :
  Cpop();
  goto o_17;
  p_17 :
  Rpush(z_17);
  r_71 :
  Cpush(b_18);
  Rpush(c_18);
  goto m_112;
  c_18 :
  Cpop();
  goto a_18;
  b_18 :
  Cpush(e_18);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(f_18);
  goto m_113;
  f_18 :
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_18);
  goto r_71;
  g_18 :
  AllBuild();
  Cpop();
  goto d_18;
  e_18 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,2);
  Epopd(0,2);
  Rpush(h_18);
  goto r_71;
  h_18 :
  d_18 :
  a_18 :
  Return();
  z_17 :
  o_17 :
  MatchFun("Nil");
  Return();
  m_113 :
  Cpush(j_18);
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  OneNextSon();
  OneNextSon();
  Rpush(k_18);
  goto n_113;
  k_18 :
  Cpush(l_18);
  Tdupl();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(m_18);
  goto m_112;
  m_18 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(n_18);
  goto m_112;
  n_18 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(o_18);
  goto m_112;
  o_18 :
  OneNextSon();
  Rpush(p_18);
  goto b_113;
  p_18 :
  AllBuild();
  AllBuild();
  AllBuild();
  OneNextSon();
  Rpush(q_18);
  goto m_112;
  q_18 :
  AllBuild();
  Cpop();
  Crestore();
  Cjump();
  l_18 :
  AllBuild();
  Rpush(r_18);
  goto r_113;
  r_18 :
  Cpop();
  goto i_18;
  j_18 :
  Cpush(t_18);
  MatchFun("RDef");
  TravInit();
  OneNextSon();
  OneNextSon();
  OneNextSon();
  Rpush(u_18);
  goto n_113;
  u_18 :
  Cpush(i_19);
  Tdupl();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(j_19);
  goto m_112;
  j_19 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(k_19);
  goto m_112;
  k_19 :
  OneNextSon();
  Rpush(l_19);
  goto b_113;
  l_19 :
  AllBuild();
  AllBuild();
  AllBuild();
  OneNextSon();
  Rpush(m_19);
  goto m_112;
  m_19 :
  AllBuild();
  Cpop();
  Crestore();
  Cjump();
  i_19 :
  AllBuild();
  Rpush(n_19);
  goto r_113;
  n_19 :
  Cpop();
  goto s_18;
  t_18 :
  MatchFun("Overlay");
  Rpush(o_19);
  goto n_113;
  o_19 :
  Cpush(u_19);
  Tdupl();
  MatchFun("Overlay");
  TravInit();
  OneNextSon();
  OneNextSon();
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(v_19);
  goto m_112;
  v_19 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(w_19);
  goto m_112;
  w_19 :
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(x_19);
  goto m_112;
  x_19 :
  OneNextSon();
  Rpush(y_19);
  goto b_113;
  y_19 :
  AllBuild();
  AllBuild();
  AllBuild();
  OneNextSon();
  Rpush(z_19);
  goto m_112;
  z_19 :
  AllBuild();
  AllBuild();
  Cpop();
  Crestore();
  Cjump();
  u_19 :
  Rpush(a_20);
  goto r_113;
  a_20 :
  s_18 :
  i_18 :
  Return();
  n_113 :
  Rpush(b_20);
  u_27 :
  Cpush(d_20);
  Cpush(f_20);
  MatchFun("Build");
  TravInit();
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(g_20);
  goto g_113;
  g_20 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  AllBuild();
  Cpop();
  goto e_20;
  f_20 :
  Cpush(i_20);
  MatchFun("Match");
  TravInit();
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(j_20);
  goto g_113;
  j_20 :
  MatchVard(1,1);
  BuildFun("Nil",0);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  AllBuild();
  Cpop();
  goto h_20;
  i_20 :
  Cpush(l_20);
  MatchFun("MA");
  TravInit();
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(m_20);
  goto g_113;
  m_20 :
  MatchVard(1,1);
  BuildFun("Nil",0);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  OneNextSon();
  Rpush(n_20);
  goto u_27;
  n_20 :
  AllBuild();
  Cpop();
  goto k_20;
  l_20 :
  Cpush(p_20);
  MatchFun("AM");
  TravInit();
  OneNextSon();
  Rpush(q_20);
  goto u_27;
  q_20 :
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(r_20);
  goto g_113;
  r_20 :
  MatchVard(1,1);
  BuildFun("Nil",0);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  AllBuild();
  Cpop();
  goto o_20;
  p_20 :
  Cpush(t_20);
  MatchFun("BA");
  TravInit();
  OneNextSon();
  Rpush(u_20);
  goto u_27;
  u_20 :
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(v_20);
  goto g_113;
  v_20 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  AllBuild();
  Cpop();
  goto s_20;
  t_20 :
  Cpush(x_20);
  MatchFun("BAM");
  TravInit();
  OneNextSon();
  Rpush(y_20);
  goto u_27;
  y_20 :
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(z_20);
  goto g_113;
  z_20 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(a_21);
  goto g_113;
  a_21 :
  MatchVard(1,1);
  BuildFun("Nil",0);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  AllBuild();
  Cpop();
  goto w_20;
  x_20 :
  Cpush(c_21);
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(d_21);
  goto u_27;
  d_21 :
  AllBuild();
  Cpop();
  goto b_21;
  c_21 :
  Cpush(f_21);
  MatchFun("Rule");
  TravInit();
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(g_21);
  goto g_113;
  g_21 :
  MatchVard(1,1);
  BuildFun("Nil",0);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(h_21);
  goto g_113;
  h_21 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  OneNextSon();
  Rpush(i_21);
  goto u_27;
  i_21 :
  AllBuild();
  Cpop();
  goto e_21;
  f_21 :
  Cpush(k_21);
  MatchFun("Overlay");
  TravInit();
  OneNextSon();
  OneNextSon();
  OneNextSon();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(l_21);
  goto g_113;
  l_21 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,1);
  Epopd(0,1);
  AllBuild();
  Cpop();
  goto j_21;
  k_21 :
  MatchFun("Cong");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(m_21);
  j_73 :
  Cpush(o_21);
  Rpush(p_21);
  goto m_112;
  p_21 :
  Cpop();
  goto n_21;
  o_21 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(q_21);
  goto u_27;
  q_21 :
  OneNextSon();
  Rpush(r_21);
  goto j_73;
  r_21 :
  AllBuild();
  n_21 :
  Return();
  m_21 :
  AllBuild();
  j_21 :
  e_21 :
  b_21 :
  w_20 :
  s_20 :
  o_20 :
  k_20 :
  h_20 :
  e_20 :
  Cpop();
  goto c_20;
  d_20 :
  AllInit();
  s_21 :
  AllNextSon(&&t_21);
  Rpush(u_21);
  goto u_27;
  u_21 :
  goto s_21;
  t_21 :
  AllBuild();
  c_20 :
  Cpush(w_21);
  Rpush(x_21);
  goto o_113;
  x_21 :
  Cpop();
  goto v_21;
  w_21 :
  Rpush(y_21);
  goto q_113;
  y_21 :
  v_21 :
  Return();
  b_20 :
  Return();
  o_113 :
  Cpush(a_22);
  Epushd(0,1);
  MatchFun("Seqs");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Rpush(b_22);
  goto p_113;
  b_22 :
  Epopd(0,1);
  Cpop();
  goto z_21;
  a_22 :
  Cpush(d_22);
  Epushd(0,2);
  MatchFun("Seq");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(e_22);
  goto p_113;
  e_22 :
  Epopd(0,2);
  Cpop();
  goto c_22;
  d_22 :
  Cpush(g_22);
  Epushd(0,3);
  MatchFun("Rule");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(h_22);
  goto p_113;
  h_22 :
  Epopd(0,3);
  Cpop();
  goto f_22;
  g_22 :
  Cpush(j_22);
  Epushd(0,3);
  MatchFun("StratRule");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(k_22);
  goto p_113;
  k_22 :
  Epopd(0,3);
  Cpop();
  goto i_22;
  j_22 :
  Cpush(m_22);
  Epushd(0,2);
  MatchFun("MA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(n_22);
  goto p_113;
  n_22 :
  Epopd(0,2);
  Cpop();
  goto l_22;
  m_22 :
  Cpush(p_22);
  Epushd(0,2);
  MatchFun("AM");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(q_22);
  goto p_113;
  q_22 :
  Epopd(0,2);
  Cpop();
  goto o_22;
  p_22 :
  Cpush(s_22);
  Epushd(0,2);
  MatchFun("BA");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(t_22);
  goto p_113;
  t_22 :
  Epopd(0,2);
  Cpop();
  goto r_22;
  s_22 :
  Cpush(v_22);
  Epushd(0,3);
  MatchFun("BAM");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(w_22);
  goto p_113;
  w_22 :
  Epopd(0,3);
  Cpop();
  goto u_22;
  v_22 :
  Cpush(y_22);
  Epushd(0,2);
  MatchFun("Cong");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,2);
  Rpush(z_22);
  goto p_113;
  z_22 :
  Epopd(0,2);
  Cpop();
  goto x_22;
  y_22 :
  Cpush(b_23);
  Epushd(0,2);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,2);
  Rpush(c_23);
  y_73 :
  Cpush(e_23);
  Rpush(f_23);
  goto m_112;
  f_23 :
  Cpop();
  goto d_23;
  e_23 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(2,1);
  Epushd(3,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(3,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Rpush(g_23);
  goto i_113;
  g_23 :
  MatchVard(2,1);
  Epushd(3,1);
  Epushd(4,1);
  Epushd(5,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(5,1);
  BuildVard(1,2);
  Tpush();
  BuildVard(5,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(5,1);
  Epushd(5,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(6,1);
  BuildVard(5,1);
  Tpush();
  BuildVard(5,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(h_23);
  goto i_113;
  h_23 :
  MatchVard(6,1);
  BuildVard(5,1);
  Tpush();
  BuildVard(6,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(6,1);
  Rpush(i_23);
  goto i_113;
  i_23 :
  Epopd(5,2);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epushd(4,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,2);
  Rpush(j_23);
  a_75 :
  Cpush(l_23);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(m_23);
  goto a_75;
  m_23 :
  AllBuild();
  Cpop();
  goto k_23;
  l_23 :
  Rpush(n_23);
  goto m_112;
  n_23 :
  BuildVard(4,1);
  k_23 :
  Return();
  j_23 :
  Epopd(4,2);
  MatchVard(3,1);
  BuildVard(1,2);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,3);
  OneNextSon();
  Rpush(o_23);
  goto y_73;
  o_23 :
  AllBuild();
  d_23 :
  Return();
  c_23 :
  Epopd(0,2);
  Cpop();
  goto a_23;
  b_23 :
  Epushd(0,3);
  MatchFun("Overlay");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Epushd(1,1);
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Rpush(p_23);
  goto p_113;
  p_23 :
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Overlay",3);
  Epopd(1,1);
  Epopd(0,3);
  a_23 :
  x_22 :
  u_22 :
  r_22 :
  o_22 :
  l_22 :
  i_22 :
  f_22 :
  c_22 :
  z_21 :
  Return();
  p_113 :
  Rpush(q_23);
  q_82 :
  Cpush(s_23);
  Rpush(t_23);
  goto m_112;
  t_23 :
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Cpop();
  goto r_23;
  s_23 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(u_23);
  goto q_82;
  u_23 :
  OneNextSon();
  Rpush(v_23);
  goto b_113;
  v_23 :
  AllBuild();
  AllBuild();
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,2);
  Rpush(w_23);
  z_83 :
  Cpush(y_23);
  Rpush(z_23);
  goto m_112;
  z_23 :
  Cpop();
  goto x_23;
  y_23 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  BuildVard(0,1);
  Rpush(a_24);
  a_84 :
  Cpush(c_24);
  Rpush(d_24);
  goto m_112;
  d_24 :
  Cpop();
  goto b_24;
  c_24 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(3,6);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,5);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,4);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,6);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(4,1);
  Epushd(5,1);
  BuildVard(3,2);
  Tpush();
  BuildVard(3,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(e_24);
  goto i_113;
  e_24 :
  MatchVard(5,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(5,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(5,1);
  Epushd(5,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(5,1);
  Rpush(f_24);
  b_84 :
  Cpush(h_24);
  Rpush(i_24);
  goto m_112;
  i_24 :
  BuildVard(5,2);
  Cpop();
  goto g_24;
  h_24 :
  Cpush(k_24);
  Epushd(6,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(6,2);
  Tpop();
  Arg(1);
  MatchVard(6,1);
  Tpop();
  Tdupl();
  BuildVard(5,2);
  Tdupl();
  l_24 :
  MatchFun("Cons");
  Cpush(m_24);
  Arg(0);
  MatchVard(6,2);
  Tpop();
  Cpop();
  goto n_24;
  m_24 :
  Arg(1);
  Tdrop();
  goto l_24;
  n_24 :
  Tpop();
  Tpop();
  BuildVard(6,1);
  Epopd(6,2);
  Rpush(o_24);
  goto b_84;
  o_24 :
  Cpop();
  goto j_24;
  k_24 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(p_24);
  goto b_84;
  p_24 :
  AllBuild();
  j_24 :
  g_24 :
  Return();
  f_24 :
  Epopd(5,2);
  MatchVard(4,1);
  Epushd(5,1);
  BuildVard(3,3);
  Tpush();
  BuildVard(3,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(6,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(6,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(6,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(6,1);
  Rpush(q_24);
  d_84 :
  Cpush(s_24);
  Rpush(t_24);
  goto m_112;
  t_24 :
  BuildVard(6,2);
  Cpop();
  goto r_24;
  s_24 :
  Cpush(v_24);
  Epushd(7,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(7,2);
  Tpop();
  Arg(1);
  MatchVard(7,1);
  Tpop();
  Tdupl();
  BuildVard(6,2);
  Tdupl();
  w_24 :
  MatchFun("Cons");
  Cpush(x_24);
  Arg(0);
  MatchVard(7,2);
  Tpop();
  Cpop();
  goto y_24;
  x_24 :
  Arg(1);
  Tdrop();
  goto w_24;
  y_24 :
  Tpop();
  Tpop();
  BuildVard(7,1);
  Epopd(7,2);
  Rpush(z_24);
  goto d_84;
  z_24 :
  Cpop();
  goto u_24;
  v_24 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(a_25);
  goto d_84;
  a_25 :
  AllBuild();
  u_24 :
  r_24 :
  Return();
  q_24 :
  Epopd(6,2);
  MatchVard(5,1);
  Epushd(6,1);
  BuildVard(3,5);
  Tpush();
  BuildVard(3,6);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(7,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(7,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(7,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(7,1);
  Rpush(b_25);
  f_84 :
  Cpush(d_25);
  Rpush(e_25);
  goto m_112;
  e_25 :
  BuildVard(7,2);
  Cpop();
  goto c_25;
  d_25 :
  Cpush(g_25);
  Epushd(8,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(8,2);
  Tpop();
  Arg(1);
  MatchVard(8,1);
  Tpop();
  Tdupl();
  BuildVard(7,2);
  Tdupl();
  h_25 :
  MatchFun("Cons");
  Cpush(i_25);
  Arg(0);
  MatchVard(8,2);
  Tpop();
  Cpop();
  goto j_25;
  i_25 :
  Arg(1);
  Tdrop();
  goto h_25;
  j_25 :
  Tpop();
  Tpop();
  BuildVard(8,1);
  Epopd(8,2);
  Rpush(k_25);
  goto f_84;
  k_25 :
  Cpop();
  goto f_25;
  g_25 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(l_25);
  goto f_84;
  l_25 :
  AllBuild();
  f_25 :
  c_25 :
  Return();
  b_25 :
  Epopd(7,2);
  MatchVard(6,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(5,1);
  Tpush();
  BuildVard(6,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(6,1);
  Epopd(5,1);
  Epopd(4,1);
  Epopd(3,6);
  Epopd(2,1);
  OneNextSon();
  Rpush(m_25);
  goto a_84;
  m_25 :
  AllBuild();
  b_24 :
  Return();
  a_24 :
  Epopd(1,1);
  OneNextSon();
  Rpush(n_25);
  goto z_83;
  n_25 :
  AllBuild();
  x_23 :
  Return();
  w_23 :
  Rpush(o_25);
  h_84 :
  Cpush(q_25);
  Rpush(r_25);
  goto m_112;
  r_25 :
  BuildFun("Nil",0);
  Cpop();
  goto p_25;
  q_25 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(s_25);
  goto h_84;
  s_25 :
  OneNextSon();
  Rpush(t_25);
  goto b_113;
  t_25 :
  AllBuild();
  AllBuild();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Rpush(u_25);
  i_84 :
  Cpush(w_25);
  Rpush(x_25);
  goto m_112;
  x_25 :
  BuildVard(1,2);
  Cpop();
  goto v_25;
  w_25 :
  Cpush(z_25);
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  Tdupl();
  BuildVard(1,2);
  Tdupl();
  a_26 :
  MatchFun("Cons");
  Cpush(b_26);
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Cpop();
  goto c_26;
  b_26 :
  Arg(1);
  Tdrop();
  goto a_26;
  c_26 :
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,2);
  Rpush(d_26);
  goto i_84;
  d_26 :
  Cpop();
  goto y_25;
  z_25 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(e_26);
  goto i_84;
  e_26 :
  AllBuild();
  y_25 :
  v_25 :
  Return();
  u_25 :
  Epopd(1,2);
  p_25 :
  Return();
  o_25 :
  Epopd(0,2);
  r_23 :
  Return();
  q_23 :
  Return();
  q_113 :
  Rpush(f_26);
  goto h_113;
  f_26 :
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,3);
  Epopd(0,3);
  Rpush(g_26);
  w_91 :
  Cpush(i_26);
  Rpush(j_26);
  goto m_112;
  j_26 :
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Cpop();
  goto h_26;
  i_26 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(k_26);
  goto w_91;
  k_26 :
  OneNextSon();
  Rpush(l_26);
  goto b_113;
  l_26 :
  AllBuild();
  AllBuild();
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,2);
  Rpush(m_26);
  e_93 :
  Cpush(o_26);
  Rpush(q_26);
  goto m_112;
  q_26 :
  Cpop();
  goto n_26;
  o_26 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  BuildVard(0,1);
  Rpush(r_26);
  f_93 :
  Cpush(u_26);
  Rpush(v_26);
  goto m_112;
  v_26 :
  Cpop();
  goto t_26;
  u_26 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(3,6);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,5);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,4);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,6);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(5,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(5,1);
  Rpush(w_26);
  g_93 :
  Cpush(y_26);
  Rpush(f_27);
  goto m_112;
  f_27 :
  BuildVard(5,2);
  Cpop();
  goto x_26;
  y_26 :
  Cpush(h_27);
  Epushd(6,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(6,2);
  Tpop();
  Arg(1);
  MatchVard(6,1);
  Tpop();
  Tdupl();
  BuildVard(5,2);
  Tdupl();
  i_27 :
  MatchFun("Cons");
  Cpush(j_27);
  Arg(0);
  MatchVard(6,2);
  Tpop();
  Cpop();
  goto k_27;
  j_27 :
  Arg(1);
  Tdrop();
  goto i_27;
  k_27 :
  Tpop();
  Tpop();
  BuildVard(6,1);
  Epopd(6,2);
  Rpush(l_27);
  goto g_93;
  l_27 :
  Cpop();
  goto g_27;
  h_27 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(m_27);
  goto g_93;
  m_27 :
  AllBuild();
  g_27 :
  x_26 :
  Return();
  w_26 :
  Epopd(5,2);
  MatchVard(4,1);
  Epushd(5,1);
  BuildVard(3,3);
  Tpush();
  BuildVard(3,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(6,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(6,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(6,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(6,1);
  Rpush(n_27);
  i_93 :
  Cpush(p_27);
  Rpush(q_27);
  goto m_112;
  q_27 :
  BuildVard(6,2);
  Cpop();
  goto o_27;
  p_27 :
  Cpush(v_27);
  Epushd(7,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(7,2);
  Tpop();
  Arg(1);
  MatchVard(7,1);
  Tpop();
  Tdupl();
  BuildVard(6,2);
  Tdupl();
  w_27 :
  MatchFun("Cons");
  Cpush(x_27);
  Arg(0);
  MatchVard(7,2);
  Tpop();
  Cpop();
  goto y_27;
  x_27 :
  Arg(1);
  Tdrop();
  goto w_27;
  y_27 :
  Tpop();
  Tpop();
  BuildVard(7,1);
  Epopd(7,2);
  Rpush(z_27);
  goto i_93;
  z_27 :
  Cpop();
  goto s_27;
  v_27 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(a_28);
  goto i_93;
  a_28 :
  AllBuild();
  s_27 :
  o_27 :
  Return();
  n_27 :
  Epopd(6,2);
  MatchVard(5,1);
  Epushd(6,1);
  BuildVard(3,5);
  Tpush();
  BuildVard(3,6);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(7,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(7,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(7,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(7,1);
  Rpush(b_28);
  k_93 :
  Cpush(d_28);
  Rpush(e_28);
  goto m_112;
  e_28 :
  BuildVard(7,2);
  Cpop();
  goto c_28;
  d_28 :
  Cpush(g_28);
  Epushd(8,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(8,2);
  Tpop();
  Arg(1);
  MatchVard(8,1);
  Tpop();
  Tdupl();
  BuildVard(7,2);
  Tdupl();
  h_28 :
  MatchFun("Cons");
  Cpush(i_28);
  Arg(0);
  MatchVard(8,2);
  Tpop();
  Cpop();
  goto j_28;
  i_28 :
  Arg(1);
  Tdrop();
  goto h_28;
  j_28 :
  Tpop();
  Tpop();
  BuildVard(8,1);
  Epopd(8,2);
  Rpush(k_28);
  goto k_93;
  k_28 :
  Cpop();
  goto f_28;
  g_28 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(l_28);
  goto k_93;
  l_28 :
  AllBuild();
  f_28 :
  c_28 :
  Return();
  b_28 :
  Epopd(7,2);
  MatchVard(6,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(5,1);
  Tpush();
  BuildVard(6,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(6,1);
  Epopd(5,1);
  Epopd(4,1);
  Epopd(3,6);
  Epopd(2,1);
  OneNextSon();
  Rpush(m_28);
  goto f_93;
  m_28 :
  AllBuild();
  t_26 :
  Return();
  r_26 :
  Epopd(1,1);
  OneNextSon();
  Rpush(n_28);
  goto e_93;
  n_28 :
  AllBuild();
  n_26 :
  Return();
  m_26 :
  Rpush(o_28);
  m_93 :
  Cpush(q_28);
  Rpush(r_28);
  goto m_112;
  r_28 :
  BuildFun("Nil",0);
  Cpop();
  goto p_28;
  q_28 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(s_28);
  goto m_93;
  s_28 :
  OneNextSon();
  Rpush(t_28);
  goto b_113;
  t_28 :
  AllBuild();
  AllBuild();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Rpush(u_28);
  n_93 :
  Cpush(w_28);
  Rpush(x_28);
  goto m_112;
  x_28 :
  BuildVard(1,2);
  Cpop();
  goto v_28;
  w_28 :
  Cpush(z_28);
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  Tdupl();
  BuildVard(1,2);
  Tdupl();
  a_29 :
  MatchFun("Cons");
  Cpush(b_29);
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Cpop();
  goto c_29;
  b_29 :
  Arg(1);
  Tdrop();
  goto a_29;
  c_29 :
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,2);
  Rpush(d_29);
  goto n_93;
  d_29 :
  Cpop();
  goto y_28;
  z_28 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(e_29);
  goto n_93;
  e_29 :
  AllBuild();
  y_28 :
  v_28 :
  Return();
  u_28 :
  Epopd(1,2);
  p_28 :
  Return();
  o_28 :
  Epopd(0,2);
  h_26 :
  Return();
  g_26 :
  Return();
  r_113 :
  Rpush(f_29);
  goto s_113;
  f_29 :
  Rpush(g_29);
  goto w_113;
  g_29 :
  Return();
  s_113 :
  Cpush(i_29);
  Epushd(0,3);
  MatchFun("RDef");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Epushd(1,3);
  BuildVard(0,3);
  Rpush(j_29);
  u_93 :
  Cpush(l_29);
  Rpush(m_29);
  goto m_112;
  m_29 :
  Cpop();
  goto k_29;
  l_29 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(3,1);
  BuildVard(2,2);
  Rpush(n_29);
  goto t_113;
  n_29 :
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(2,3);
  Rpush(o_29);
  goto v_113;
  o_29 :
  MatchVard(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(4,1);
  Epopd(3,1);
  Rpush(p_29);
  goto a_113;
  p_29 :
  Epopd(2,3);
  OneNextSon();
  Rpush(q_29);
  goto u_93;
  q_29 :
  AllBuild();
  k_29 :
  Return();
  j_29 :
  Rpush(r_29);
  goto a_113;
  r_29 :
  MatchVard(1,1);
  BuildStr("error in rule ");
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildStr(" : ");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,3);
  Rpush(s_29);
  h_94 :
  Cpush(u_29);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(v_29);
  goto h_94;
  v_29 :
  AllBuild();
  Cpop();
  goto t_29;
  u_29 :
  Rpush(w_29);
  goto m_112;
  w_29 :
  BuildVard(1,2);
  t_29 :
  Return();
  s_29 :
  Epopd(1,3);
  Epopd(0,3);
  Cpop();
  goto h_29;
  i_29 :
  Cpush(y_29);
  Epushd(0,3);
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Epushd(1,3);
  BuildVard(0,3);
  Rpush(z_29);
  o_94 :
  Cpush(b_30);
  Rpush(c_30);
  goto m_112;
  c_30 :
  Cpop();
  goto a_30;
  b_30 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(3,1);
  BuildVard(2,1);
  Rpush(d_30);
  goto t_113;
  d_30 :
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(2,2);
  Rpush(e_30);
  goto u_113;
  e_30 :
  MatchVard(4,1);
  Epushd(5,1);
  BuildVard(2,3);
  Rpush(f_30);
  goto v_113;
  f_30 :
  MatchVard(5,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildVard(5,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(5,1);
  Epopd(4,1);
  Epopd(3,1);
  Rpush(g_30);
  goto a_113;
  g_30 :
  Epopd(2,3);
  OneNextSon();
  Rpush(h_30);
  goto o_94;
  h_30 :
  AllBuild();
  a_30 :
  Return();
  z_29 :
  Rpush(i_30);
  goto a_113;
  i_30 :
  MatchVard(1,1);
  BuildStr("error in definition ");
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildStr(" : ");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,3);
  Rpush(j_30);
  d_95 :
  Cpush(l_30);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(m_30);
  goto d_95;
  m_30 :
  AllBuild();
  Cpop();
  goto k_30;
  l_30 :
  Rpush(n_30);
  goto m_112;
  n_30 :
  BuildVard(1,2);
  k_30 :
  Return();
  j_30 :
  Epopd(1,3);
  Epopd(0,3);
  Cpop();
  goto x_29;
  y_29 :
  Epushd(0,3);
  MatchFun("Overlay");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Epushd(1,3);
  BuildVard(0,3);
  Rpush(o_30);
  j_95 :
  Cpush(q_30);
  Rpush(r_30);
  goto m_112;
  r_30 :
  Cpop();
  goto p_30;
  q_30 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(3,1);
  BuildVard(2,2);
  Rpush(s_30);
  goto t_113;
  s_30 :
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(2,3);
  Rpush(t_30);
  goto v_113;
  t_30 :
  MatchVard(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(4,1);
  Epopd(3,1);
  Rpush(u_30);
  goto a_113;
  u_30 :
  Epopd(2,3);
  OneNextSon();
  Rpush(v_30);
  goto j_95;
  v_30 :
  AllBuild();
  p_30 :
  Return();
  o_30 :
  Rpush(w_30);
  goto a_113;
  w_30 :
  MatchVard(1,1);
  BuildStr("error in overlay ");
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildStr(" : ");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,3);
  Rpush(x_30);
  w_95 :
  Cpush(z_30);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(b_31);
  goto w_95;
  b_31 :
  AllBuild();
  Cpop();
  goto y_30;
  z_30 :
  Rpush(c_31);
  goto m_112;
  c_31 :
  BuildVard(1,2);
  y_30 :
  Return();
  x_30 :
  Epopd(1,3);
  Epopd(0,3);
  x_29 :
  h_29 :
  Return();
  t_113 :
  Cpush(e_31);
  Epushd(0,0);
  MatchFun("Nil");
  BuildFun("Nil",0);
  Epopd(0,0);
  Cpop();
  goto d_31;
  e_31 :
  Cpush(g_31);
  Epushd(0,1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  BuildStr("variable ");
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildStr(": used, but not bound");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto f_31;
  g_31 :
  Epushd(0,3);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildStr("variables ");
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildStr(": used, but not bound");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,3);
  f_31 :
  d_31 :
  Return();
  u_113 :
  Cpush(i_31);
  Epushd(0,0);
  MatchFun("Nil");
  BuildFun("Nil",0);
  Epopd(0,0);
  Cpop();
  goto h_31;
  i_31 :
  Cpush(k_31);
  Epushd(0,1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  BuildStr("variable ");
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildStr(": matched, but not declared");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto j_31;
  k_31 :
  Epushd(0,3);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildStr("variables ");
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildStr(": matched, but not declared");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,3);
  j_31 :
  h_31 :
  Return();
  v_113 :
  Cpush(m_31);
  Epushd(0,0);
  MatchFun("Nil");
  BuildFun("Nil",0);
  Epopd(0,0);
  Cpop();
  goto l_31;
  m_31 :
  Cpush(o_31);
  Epushd(0,1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  BuildStr("variable ");
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildStr(": declared, but not bound");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto n_31;
  o_31 :
  Epushd(0,3);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildStr("variables ");
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildStr(": declared, but not bound");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,3);
  n_31 :
  l_31 :
  Return();
  w_113 :
  Tdupl();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stderr",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(p_31);
  goto t_112;
  p_31 :
  Tpop();
  Return();
  x_113 :
  Epushd(0,4);
  MatchFun("Specification");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("Signature");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Cons");
  Arg(0);
  MatchFun("Overlays");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Cons");
  Arg(0);
  MatchFun("Rules");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Cons");
  Arg(0);
  MatchFun("Strategies");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Rpush(q_31);
  goto c_114;
  q_31 :
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,2);
  Rpush(r_31);
  l_96 :
  Cpush(t_31);
  Rpush(u_31);
  goto m_112;
  u_31 :
  Cpop();
  goto s_31;
  t_31 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(3,3);
  MatchFun("Overlay");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchVard(3,2);
  Tpop();
  Arg(2);
  MatchVard(3,3);
  Tpop();
  Epushd(4,1);
  BuildVard(3,3);
  Rpush(v_31);
  goto f_114;
  v_31 :
  MatchVard(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("SDef",3);
  Epopd(4,1);
  Epopd(3,3);
  OneNextSon();
  Rpush(w_31);
  goto l_96;
  w_31 :
  AllBuild();
  s_31 :
  Return();
  r_31 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(0,3);
  Rpush(x_31);
  y_96 :
  Cpush(z_31);
  Rpush(a_32);
  goto m_112;
  a_32 :
  Cpop();
  goto y_31;
  z_31 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(4,3);
  MatchFun("RDef");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Arg(1);
  MatchVard(4,2);
  Tpop();
  Arg(2);
  MatchVard(4,3);
  Tpop();
  Epushd(5,1);
  BuildVard(4,3);
  Rpush(b_32);
  goto g_113;
  b_32 :
  MatchVard(5,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(4,2);
  Tpush();
  BuildVard(5,1);
  Tpush();
  BuildVard(4,3);
  Tpush();
  BuildFun("SRule",1);
  Tpush();
  BuildFun("Scope",2);
  Tpush();
  BuildFun("SDef",3);
  Epopd(5,1);
  Epopd(4,3);
  OneNextSon();
  Rpush(c_32);
  goto y_96;
  c_32 :
  AllBuild();
  y_31 :
  Return();
  x_31 :
  MatchVard(3,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Rpush(d_32);
  h_97 :
  Cpush(f_32);
  e_32 :
  Epushd(1,4);
  MatchFun("Op");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tdupl();
  g_32 :
  MatchFun("Cons");
  Cpush(h_32);
  Arg(0);
  MatchFun("Overlay");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,3);
  Tpop();
  Arg(2);
  MatchVard(1,4);
  Tpop();
  Tpop();
  Cpop();
  goto i_32;
  h_32 :
  Arg(1);
  Tdrop();
  goto g_32;
  i_32 :
  Tpop();
  Tpop();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(j_32);
  goto e_113;
  j_32 :
  Epopd(1,4);
  Tduplinv();
  goto e_32;
  f_32 :
  AllInit();
  k_32 :
  AllNextSon(&&l_32);
  Rpush(m_32);
  goto h_97;
  m_32 :
  goto k_32;
  l_32 :
  AllBuild();
  Return();
  d_32 :
  Rpush(n_32);
  goto a_113;
  n_32 :
  Rpush(o_32);
  o_97 :
  Cpush(q_32);
  Rpush(r_32);
  goto m_112;
  r_32 :
  Cpop();
  goto p_32;
  q_32 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(s_32);
  goto y_113;
  s_32 :
  OneNextSon();
  Rpush(t_32);
  goto o_97;
  t_32 :
  AllBuild();
  p_32 :
  Return();
  o_32 :
  Epopd(0,4);
  Return();
  y_113 :
  Rpush(u_32);
  goto z_113;
  u_32 :
  Rpush(v_32);
  goto b_114;
  v_32 :
  Return();
  z_113 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  BuildFun("Nil",0);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(w_32);
  v_97 :
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(x_32);
  w_97 :
  Cpush(z_32);
  MatchFun("Var");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  BuildVard(0,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Rpush(a_33);
  goto a_114;
  a_33 :
  AllBuild();
  Cpop();
  goto y_32;
  z_32 :
  Cpush(c_33);
  Epushd(1,3);
  Tdupl();
  Rpush(d_33);
  goto j_113;
  d_33 :
  MatchVard(1,1);
  Rpush(e_33);
  i_98 :
  Cpush(g_33);
  Rpush(h_33);
  goto m_112;
  h_33 :
  Cpop();
  goto f_33;
  g_33 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  new();
  OneNextSon();
  Rpush(i_33);
  goto i_98;
  i_33 :
  AllBuild();
  f_33 :
  Return();
  e_33 :
  MatchVard(1,2);
  Epushd(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(j_33);
  j_98 :
  Cpush(l_33);
  Epushd(3,0);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildFun("Nil",0);
  Epopd(3,0);
  Cpop();
  goto k_33;
  l_33 :
  Epushd(3,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchVard(3,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(3,3);
  Tpush();
  BuildVard(3,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,4);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(m_33);
  goto j_98;
  m_33 :
  OneNextSon();
  Rpush(n_33);
  goto b_113;
  n_33 :
  AllBuild();
  AllBuild();
  Epushd(3,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,2);
  k_33 :
  Return();
  j_33 :
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(o_33);
  s_98 :
  Cpush(q_33);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(r_33);
  goto s_98;
  r_33 :
  AllBuild();
  Cpop();
  goto p_33;
  q_33 :
  Rpush(s_33);
  goto m_112;
  s_33 :
  BuildVard(2,1);
  p_33 :
  Return();
  o_33 :
  Epopd(2,2);
  MatchVard(1,3);
  Tpop();
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  BuildVard(1,2);
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(t_33);
  goto v_97;
  t_33 :
  Epopd(2,1);
  AllBuild();
  Epopd(1,3);
  Cpop();
  goto b_33;
  c_33 :
  AllInit();
  u_33 :
  AllNextSon(&&v_33);
  Rpush(w_33);
  goto w_97;
  w_33 :
  goto u_33;
  v_33 :
  AllBuild();
  b_33 :
  y_32 :
  Return();
  x_32 :
  Epopd(0,1);
  Return();
  w_32 :
  Return();
  a_114 :
  Rpush(x_33);
  k_35 :
  Cpush(z_33);
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,2);
  Epopd(0,2);
  Cpop();
  goto y_33;
  z_33 :
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  Rpush(a_34);
  goto k_35;
  a_34 :
  y_33 :
  Return();
  x_33 :
  Return();
  b_114 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  BuildFun("Nil",0);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(b_34);
  n_99 :
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(c_34);
  o_99 :
  Cpush(e_34);
  MatchFun("SVar");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  BuildVard(0,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Rpush(f_34);
  goto a_114;
  f_34 :
  AllBuild();
  Cpop();
  goto d_34;
  e_34 :
  Cpush(h_34);
  Epushd(1,3);
  Tdupl();
  Cpush(j_34);
  Epushd(2,4);
  MatchFun("Let");
  Arg(0);
  MatchFun("SDef");
  Arg(0);
  MatchVard(2,4);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  Arg(2);
  MatchVard(2,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(2,3);
  Tpop();
  BuildVard(2,4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(2,4);
  Cpop();
  goto i_34;
  j_34 :
  Cpush(l_34);
  Epushd(2,3);
  MatchFun("SDef");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchVard(2,3);
  Tpop();
  Arg(2);
  MatchVard(2,2);
  Tpop();
  BuildVard(2,3);
  Epopd(2,3);
  Cpop();
  goto k_34;
  l_34 :
  Epushd(2,2);
  MatchFun("Rec");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  BuildVard(2,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(2,2);
  k_34 :
  i_34 :
  MatchVard(1,1);
  Rpush(m_34);
  j_100 :
  Cpush(o_34);
  Rpush(p_34);
  goto m_112;
  p_34 :
  Cpop();
  goto n_34;
  o_34 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  new();
  OneNextSon();
  Rpush(q_34);
  goto j_100;
  q_34 :
  AllBuild();
  n_34 :
  Return();
  m_34 :
  MatchVard(1,2);
  Epushd(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(r_34);
  k_100 :
  Cpush(t_34);
  Epushd(3,0);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildFun("Nil",0);
  Epopd(3,0);
  Cpop();
  goto s_34;
  t_34 :
  Epushd(3,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchVard(3,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(3,3);
  Tpush();
  BuildVard(3,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,4);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(u_34);
  goto k_100;
  u_34 :
  OneNextSon();
  Rpush(v_34);
  goto b_113;
  v_34 :
  AllBuild();
  AllBuild();
  Epushd(3,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,2);
  s_34 :
  Return();
  r_34 :
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(w_34);
  t_100 :
  Cpush(y_34);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(z_34);
  goto t_100;
  z_34 :
  AllBuild();
  Cpop();
  goto x_34;
  y_34 :
  Rpush(a_35);
  goto m_112;
  a_35 :
  BuildVard(2,1);
  x_34 :
  Return();
  w_34 :
  Epopd(2,2);
  MatchVard(1,3);
  Tpop();
  Cpush(c_35);
  MatchFun("Let");
  TravInit();
  OneNextSon();
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  BuildVard(1,2);
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  OneNextSon();
  OneNextSon();
  AllBuild();
  Rpush(d_35);
  goto o_99;
  d_35 :
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(e_35);
  goto n_99;
  e_35 :
  Epopd(2,1);
  AllBuild();
  Cpop();
  goto b_35;
  c_35 :
  Cpush(g_35);
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  OneNextSon();
  BuildVard(1,2);
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(h_35);
  goto n_99;
  h_35 :
  Epopd(2,1);
  AllBuild();
  Cpop();
  goto f_35;
  g_35 :
  MatchFun("Rec");
  TravInit();
  OneNextSon();
  BuildVard(1,2);
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(i_35);
  goto n_99;
  i_35 :
  Epopd(2,1);
  AllBuild();
  f_35 :
  b_35 :
  Epopd(1,3);
  Cpop();
  goto g_34;
  h_34 :
  AllInit();
  j_35 :
  AllNextSon(&&l_35);
  Rpush(m_35);
  goto o_99;
  m_35 :
  goto j_35;
  l_35 :
  AllBuild();
  g_34 :
  d_34 :
  Return();
  c_34 :
  Epopd(0,1);
  Return();
  b_34 :
  Return();
  c_114 :
  Rpush(n_35);
  k_101 :
  Cpush(p_35);
  Rpush(q_35);
  goto m_112;
  q_35 :
  Cpop();
  goto o_35;
  p_35 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(r_35);
  goto d_114;
  r_35 :
  OneNextSon();
  Rpush(s_35);
  goto k_101;
  s_35 :
  AllBuild();
  o_35 :
  Return();
  n_35 :
  Rpush(t_35);
  goto a_113;
  t_35 :
  Return();
  d_114 :
  Epushd(0,2);
  MatchFunFC("Sorts",&&x_35);
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Rpush(y_35);
  goto i_0;
  y_35 :
  goto w_35;
  x_35 :
  MatchFunFC("Operations",&&z_35);
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Rpush(a_36);
  goto j_0;
  a_36 :
  goto w_35;
  z_35 :
  goto fail;
  w_35 :
  goto v_35;
  j_0 :
  BuildVard(0,2);
  Rpush(b_36);
  l_101 :
  Cpush(d_36);
  Rpush(e_36);
  goto m_112;
  e_36 :
  Cpop();
  goto c_36;
  d_36 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(f_36);
  goto e_114;
  f_36 :
  OneNextSon();
  Rpush(g_36);
  goto l_101;
  g_36 :
  AllBuild();
  c_36 :
  Return();
  b_36 :
  Return();
  v_35 :
  goto u_35;
  i_0 :
  BuildFun("Nil",0);
  Return();
  u_35 :
  Epopd(0,2);
  Return();
  e_114 :
  Cpush(l_36);
  Epushd(0,2);
  MatchFun("OpDecl");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("ConstType");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cong",2);
  Tpush();
  BuildFun("SDef",3);
  Epopd(0,2);
  Cpop();
  goto k_36;
  l_36 :
  Epushd(0,4);
  MatchFun("OpDecl");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("FunType");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,3);
  Rpush(m_36);
  m_101 :
  Cpush(o_36);
  Rpush(p_36);
  goto m_112;
  p_36 :
  Cpop();
  goto n_36;
  o_36 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  new();
  OneNextSon();
  Rpush(q_36);
  goto m_101;
  q_36 :
  AllBuild();
  n_36 :
  Return();
  m_36 :
  MatchVard(0,4);
  Tpop();
  Epushd(1,1);
  BuildVard(0,4);
  Rpush(r_36);
  o_101 :
  Cpush(t_36);
  Rpush(u_36);
  goto m_112;
  u_36 :
  Cpop();
  goto s_36;
  t_36 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Call",2);
  Epopd(2,1);
  OneNextSon();
  Rpush(v_36);
  goto o_101;
  v_36 :
  AllBuild();
  s_36 :
  Return();
  r_36 :
  MatchVard(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Cong",2);
  Tpush();
  BuildFun("SDef",3);
  Epopd(1,1);
  Epopd(0,4);
  k_36 :
  Return();
  f_114 :
  Rpush(w_36);
  a_31 :
  Cpush(y_36);
  MatchFun("Op");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(z_36);
  t_101 :
  Cpush(b_37);
  Rpush(c_37);
  goto m_112;
  c_37 :
  Cpop();
  goto a_37;
  b_37 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(d_37);
  goto a_31;
  d_37 :
  OneNextSon();
  Rpush(e_37);
  goto t_101;
  e_37 :
  AllBuild();
  a_37 :
  Return();
  z_36 :
  AllBuild();
  Cpop();
  goto x_36;
  y_36 :
  x_36 :
  Rpush(f_37);
  goto g_114;
  f_37 :
  Return();
  w_36 :
  Return();
  g_114 :
  Cpush(h_37);
  Epushd(0,1);
  MatchFun("Var");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Call",2);
  Epopd(0,1);
  Cpop();
  goto g_37;
  h_37 :
  Cpush(j_37);
  Epushd(0,2);
  MatchFun("Op");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Call",2);
  Epopd(0,2);
  Cpop();
  goto i_37;
  j_37 :
  Epushd(0,2);
  MatchFunFC("Str",&&n_37);
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Rpush(o_37);
  goto k_0;
  o_37 :
  goto m_37;
  n_37 :
  MatchFunFC("Int",&&p_37);
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Rpush(q_37);
  goto l_0;
  q_37 :
  goto m_37;
  p_37 :
  goto fail;
  m_37 :
  goto l_37;
  l_0 :
  BuildVard(0,2);
  Tpush();
  BuildFun("Int",1);
  Tpush();
  BuildFun("Match",1);
  Return();
  l_37 :
  goto k_37;
  k_0 :
  BuildVard(0,1);
  Tpush();
  BuildFun("Str",1);
  Tpush();
  BuildFun("Match",1);
  Return();
  k_37 :
  Epopd(0,2);
  i_37 :
  g_37 :
  Return();
  h_114 :
  Epushd(0,1);
  MatchVard(0,1);
  BuildStr("main");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildStr("main");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,1);
  Cpush(s_37);
  r_37 :
  Epushd(0,9);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,8);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,3);
  Cpush(u_37);
  Rpush(v_37);
  m_103 :
  Cpush(x_37);
  Rpush(y_37);
  goto m_112;
  y_37 :
  Cpop();
  goto w_37;
  x_37 :
  Cpush(a_38);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  Tpop();
  Arg(2);
  Tpop();
  OneNextSon();
  Rpush(c_38);
  goto m_103;
  c_38 :
  AllBuild();
  Cpop();
  goto z_37;
  a_38 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(d_38);
  goto m_103;
  d_38 :
  z_37 :
  w_37 :
  Return();
  v_37 :
  Cpop();
  goto t_37;
  u_37 :
  Rpush(e_38);
  n_103 :
  Cpush(g_38);
  Rpush(h_38);
  goto m_112;
  h_38 :
  Cpop();
  goto f_38;
  g_38 :
  Cpush(j_38);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  Tpop();
  Arg(2);
  Tpop();
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(k_38);
  goto n_103;
  k_38 :
  AllBuild();
  Cpop();
  goto i_38;
  j_38 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(l_38);
  goto n_103;
  l_38 :
  i_38 :
  f_38 :
  Return();
  e_38 :
  t_37 :
  MatchVard(0,4);
  Epushd(1,1);
  BuildVard(0,4);
  Rpush(m_38);
  goto k_114;
  m_38 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,8);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(n_38);
  goto i_113;
  n_38 :
  MatchVard(0,7);
  BuildVard(0,7);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,2);
  Rpush(o_38);
  o_103 :
  Cpush(q_38);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(r_38);
  goto o_103;
  r_38 :
  AllBuild();
  Cpop();
  goto p_38;
  q_38 :
  Rpush(s_38);
  goto m_112;
  s_38 :
  BuildVard(1,1);
  p_38 :
  Return();
  o_38 :
  Epopd(1,2);
  MatchVard(0,6);
  BuildVard(0,7);
  Tpush();
  BuildVard(0,8);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,2);
  Rpush(t_38);
  p_103 :
  Cpush(v_38);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(w_38);
  goto p_103;
  w_38 :
  AllBuild();
  Cpop();
  goto u_38;
  v_38 :
  Rpush(x_38);
  goto m_112;
  x_38 :
  BuildVard(1,1);
  u_38 :
  Return();
  t_38 :
  Epopd(1,2);
  MatchVard(0,9);
  Tpop();
  Epushd(1,1);
  BuildVard(0,4);
  Rpush(y_38);
  goto i_114;
  y_38 :
  MatchVard(1,1);
  BuildVard(0,6);
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Epopd(0,9);
  Tduplinv();
  goto r_37;
  s_37 :
  Cpush(a_39);
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  BuildVard(0,3);
  Epopd(0,3);
  Cpop();
  goto z_38;
  a_39 :
  Epushd(0,5);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  BuildStr("error: operator ");
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildStr(" undefined ");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,5);
  Rpush(b_39);
  goto w_113;
  b_39 :
  Epushd(0,1);
  MatchVard(0,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epopd(0,1);
  z_38 :
  Return();
  i_114 :
  Cpush(d_39);
  Epushd(0,1);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Cpop();
  goto c_39;
  d_39 :
  Epushd(0,7);
  MatchFun("Cons");
  Arg(0);
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,6);
  Tpop();
  Tdupl();
  BuildVard(0,4);
  Rpush(e_39);
  j_104 :
  Cpush(g_39);
  Rpush(h_39);
  goto m_112;
  h_39 :
  Cpop();
  goto f_39;
  g_39 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  new();
  OneNextSon();
  Rpush(i_39);
  goto j_104;
  i_39 :
  AllBuild();
  f_39 :
  Return();
  e_39 :
  MatchVard(0,1);
  BuildVard(0,1);
  Rpush(j_39);
  l_104 :
  Cpush(l_39);
  Rpush(m_39);
  goto m_112;
  m_39 :
  Cpop();
  goto k_39;
  l_39 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Call",2);
  Epopd(1,1);
  OneNextSon();
  Rpush(n_39);
  goto l_104;
  n_39 :
  AllBuild();
  k_39 :
  Return();
  j_39 :
  MatchVard(0,2);
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("SDef",3);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("Cons",2);
  Rpush(o_39);
  o_104 :
  Cpush(q_39);
  Rpush(r_39);
  goto m_112;
  r_39 :
  Cpop();
  goto p_39;
  q_39 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,2);
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Arg(2);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(s_39);
  goto j_114;
  s_39 :
  Epopd(1,2);
  OneNextSon();
  Rpush(t_39);
  goto o_104;
  t_39 :
  AllBuild();
  p_39 :
  Return();
  o_39 :
  MatchVard(0,7);
  Tpop();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,7);
  Tpush();
  BuildFun("Choices",1);
  Tpush();
  BuildFun("SDef",3);
  Epopd(0,7);
  c_39 :
  Return();
  j_114 :
  Epushd(0,4);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(u_39);
  a_105 :
  Cpush(w_39);
  Epushd(1,0);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildFun("Nil",0);
  Epopd(1,0);
  Cpop();
  goto v_39;
  w_39 :
  Epushd(1,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,4);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(x_39);
  goto a_105;
  x_39 :
  OneNextSon();
  Rpush(y_39);
  goto b_113;
  y_39 :
  AllBuild();
  AllBuild();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,2);
  v_39 :
  Return();
  u_39 :
  MatchVard(0,1);
  BuildVard(0,4);
  Rpush(z_39);
  j_105 :
  Cpush(b_40);
  Epushd(1,3);
  MatchFun("Call");
  Arg(0);
  MatchFun("SVar");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  BuildVard(1,1);
  MatchVard(1,2);
  Tdupl();
  BuildVard(0,1);
  Tdupl();
  c_40 :
  MatchFun("Cons");
  Cpush(d_40);
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Cpop();
  goto e_40;
  d_40 :
  Arg(1);
  Tdrop();
  goto c_40;
  e_40 :
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Cpop();
  goto a_40;
  b_40 :
  AllInit();
  f_40 :
  AllNextSon(&&g_40);
  Rpush(h_40);
  goto j_105;
  h_40 :
  goto f_40;
  g_40 :
  AllBuild();
  a_40 :
  Return();
  z_39 :
  Epopd(0,4);
  Return();
  k_114 :
  Rpush(i_40);
  a_106 :
  Cpush(k_40);
  Epushd(0,1);
  MatchFun("SVar");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto j_40;
  k_40 :
  Epushd(0,2);
  Tdupl();
  Rpush(l_40);
  goto h_113;
  l_40 :
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Rpush(m_40);
  f_106 :
  Cpush(o_40);
  Rpush(p_40);
  goto m_112;
  p_40 :
  Cpop();
  goto n_40;
  o_40 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(q_40);
  goto a_106;
  q_40 :
  OneNextSon();
  Rpush(r_40);
  goto f_106;
  r_40 :
  AllBuild();
  n_40 :
  Return();
  m_40 :
  Rpush(s_40);
  m_106 :
  Cpush(u_40);
  Rpush(v_40);
  goto m_112;
  v_40 :
  BuildFun("Nil",0);
  Cpop();
  goto t_40;
  u_40 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(w_40);
  goto m_106;
  w_40 :
  OneNextSon();
  Rpush(x_40);
  goto b_113;
  x_40 :
  AllBuild();
  AllBuild();
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,1);
  Rpush(y_40);
  t_106 :
  Cpush(a_41);
  Rpush(b_41);
  goto m_112;
  b_41 :
  BuildVard(1,2);
  Cpop();
  goto z_40;
  a_41 :
  Cpush(d_41);
  Epushd(2,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  Tdupl();
  BuildVard(1,2);
  Tdupl();
  e_41 :
  MatchFun("Cons");
  Cpush(f_41);
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Cpop();
  goto g_41;
  f_41 :
  Arg(1);
  Tdrop();
  goto e_41;
  g_41 :
  Tpop();
  Tpop();
  BuildVard(2,1);
  Epopd(2,2);
  Rpush(h_41);
  goto t_106;
  h_41 :
  Cpop();
  goto c_41;
  d_41 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(i_41);
  goto t_106;
  i_41 :
  AllBuild();
  c_41 :
  z_40 :
  Return();
  y_40 :
  Epopd(1,2);
  t_40 :
  Return();
  s_40 :
  MatchVard(0,1);
  Tpop();
  Cpush(k_41);
  Cpush(m_41);
  Epushd(1,4);
  MatchFun("Let");
  Arg(0);
  MatchFun("SDef");
  Arg(0);
  MatchVard(1,4);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Arg(2);
  MatchVard(1,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(1,3);
  Tpop();
  BuildVard(1,4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,4);
  Cpop();
  goto l_41;
  m_41 :
  Cpush(o_41);
  Epushd(1,3);
  MatchFun("SDef");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,3);
  Tpop();
  Arg(2);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Cpop();
  goto n_41;
  o_41 :
  Epushd(1,2);
  MatchFun("Rec");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(1,2);
  n_41 :
  l_41 :
  MatchVard(0,2);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(p_41);
  goto i_113;
  p_41 :
  Cpop();
  goto j_41;
  k_41 :
  BuildVard(0,1);
  j_41 :
  Epopd(0,2);
  j_40 :
  Return();
  i_40 :
  Return();
  l_114 :
  Rpush(q_41);
  e_107 :
  Cpush(s_41);
  Rpush(t_41);
  goto m_112;
  t_41 :
  Cpop();
  goto r_41;
  s_41 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  OneNextSon();
  OneNextSon();
  Rpush(u_41);
  goto m_114;
  u_41 :
  AllBuild();
  OneNextSon();
  Rpush(v_41);
  goto e_107;
  v_41 :
  AllBuild();
  r_41 :
  Return();
  q_41 :
  Return();
  m_114 :
  Rpush(w_41);
  k_107 :
  Cpush(y_41);
  Rpush(z_41);
  goto n_114;
  z_41 :
  Cpop();
  goto x_41;
  y_41 :
  x_41 :
  Cpush(b_42);
  a_42 :
  Cpush(d_42);
  Rpush(e_42);
  goto t_114;
  e_42 :
  Cpop();
  goto c_42;
  d_42 :
  Cpush(g_42);
  Rpush(h_42);
  goto u_114;
  h_42 :
  Cpop();
  goto f_42;
  g_42 :
  Cpush(j_42);
  Epushd(0,2);
  MatchFun("Build");
  Arg(0);
  MatchFun("App");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,2);
  Cpop();
  goto i_42;
  j_42 :
  Rpush(k_42);
  goto v_114;
  k_42 :
  i_42 :
  f_42 :
  c_42 :
  Tduplinv();
  goto a_42;
  b_42 :
  AllInit();
  l_42 :
  AllNextSon(&&m_42);
  Rpush(n_42);
  goto k_107;
  n_42 :
  goto l_42;
  m_42 :
  AllBuild();
  Return();
  w_41 :
  Return();
  n_114 :
  Rpush(o_42);
  t_27 :
  Cpush(q_42);
  Cpush(s_42);
  Rpush(t_42);
  goto o_114;
  t_42 :
  Rpush(u_42);
  goto t_27;
  u_42 :
  Cpop();
  goto r_42;
  s_42 :
  Cpush(w_42);
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(y_42);
  goto t_27;
  y_42 :
  AllBuild();
  Cpop();
  goto v_42;
  w_42 :
  Rpush(a_43);
  goto p_114;
  a_43 :
  v_42 :
  r_42 :
  Cpop();
  goto p_42;
  q_42 :
  p_42 :
  Return();
  o_42 :
  Return();
  o_114 :
  Epushd(0,11);
  MatchFun("SRule");
  Arg(0);
  MatchFun("Rule");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Tdupl();
  new();
  MatchVard(0,9);
  BuildVard(0,2);
  Rpush(b_43);
  o_107 :
  Cpush(d_43);
  MatchFun("Con");
  Arg(0);
  MatchFun("Var");
  Arg(0);
  MatchVard(0,8);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,6);
  Tpop();
  Arg(2);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,8);
  Tpush();
  BuildFun("Var",1);
  Cpop();
  goto c_43;
  d_43 :
  IsAppl();
  OneInit();
  e_43 :
  OneNextSon();
  Cpush(e_43);
  Rpush(g_43);
  goto o_107;
  g_43 :
  Cpop();
  OneBuild();
  c_43 :
  Return();
  b_43 :
  MatchVard(0,10);
  BuildVard(0,3);
  Rpush(h_43);
  p_107 :
  Cpush(j_43);
  MatchFun("Con");
  Arg(0);
  MatchFun("Var");
  Arg(0);
  MatchVard(0,8);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,7);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  BuildVard(0,9);
  Tpush();
  BuildFun("Var",1);
  Cpop();
  goto i_43;
  j_43 :
  IsAppl();
  OneInit();
  k_43 :
  OneNextSon();
  Cpush(k_43);
  Rpush(m_43);
  goto p_107;
  m_43 :
  Cpop();
  OneBuild();
  i_43 :
  Return();
  h_43 :
  MatchVard(0,11);
  Tpop();
  BuildVard(0,9);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,10);
  Tpush();
  BuildVard(0,11);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildVard(0,7);
  Tpush();
  BuildFun("Id",0);
  Tpush();
  BuildFun("Rule",3);
  Tpush();
  BuildFun("SRule",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Call",2);
  Tpush();
  BuildVard(0,8);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildFun("BAM",3);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Rule",3);
  Tpush();
  BuildFun("SRule",1);
  Tpush();
  BuildFun("Scope",2);
  Epopd(0,11);
  Return();
  p_114 :
  Cpush(o_43);
  Epushd(0,3);
  MatchFun("SRule");
  Arg(0);
  MatchFun("Rule");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Rpush(p_43);
  goto q_114;
  p_43 :
  BuildVard(0,3);
  Rpush(q_43);
  goto r_114;
  q_43 :
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildFun("Match",1);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("Where",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Seqs",1);
  Epopd(0,3);
  Cpop();
  goto n_43;
  o_43 :
  Epushd(0,3);
  MatchFun("SRule");
  Arg(0);
  MatchFun("StratRule");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Where",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Seqs",1);
  Epopd(0,3);
  n_43 :
  Return();
  q_114 :
  Cpush(r_43);
  Tdupl();
  Rpush(s_43);
  q_107 :
  Cpush(v_43);
  MatchFun("Con");
  Cpop();
  goto u_43;
  v_43 :
  MatchFun("App");
  u_43 :
  AllInit();
  w_43 :
  AllNextSon(&&x_43);
  Rpush(y_43);
  goto q_107;
  y_43 :
  goto w_43;
  x_43 :
  AllBuild();
  Return();
  s_43 :
  Cpop();
  Crestore();
  Cjump();
  r_43 :
  Return();
  r_114 :
  Cpush(z_43);
  Tdupl();
  Rpush(a_44);
  r_107 :
  Cpush(d_44);
  MatchFun("Con");
  Cpop();
  goto c_44;
  d_44 :
  Rpush(e_44);
  goto s_114;
  e_44 :
  c_44 :
  AllInit();
  f_44 :
  AllNextSon(&&g_44);
  Rpush(h_44);
  goto r_107;
  h_44 :
  goto f_44;
  g_44 :
  AllBuild();
  Return();
  a_44 :
  Cpop();
  Crestore();
  Cjump();
  z_43 :
  Return();
  s_114 :
  MatchFun("Wld");
  Return();
  t_114 :
  Cpush(j_44);
  Epushd(0,2);
  MatchFun("BA");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,2);
  Cpop();
  goto i_44;
  j_44 :
  Cpush(l_44);
  Epushd(0,2);
  MatchFun("MA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Match",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,2);
  Cpop();
  goto k_44;
  l_44 :
  Cpush(n_44);
  Epushd(0,2);
  MatchFun("AM");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Match",1);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,2);
  Cpop();
  goto m_44;
  n_44 :
  Cpush(p_44);
  Epushd(0,3);
  MatchFun("BAM");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Match",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Seqs",1);
  Epopd(0,3);
  Cpop();
  goto o_44;
  p_44 :
  Cpush(r_44);
  Epushd(0,0);
  MatchFun("Seqs");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  BuildFun("Id",0);
  Epopd(0,0);
  Cpop();
  goto q_44;
  r_44 :
  Cpush(t_44);
  Epushd(0,2);
  MatchFun("Seqs");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Seqs",1);
  Tpush();
  BuildFun("Seq",2);
  Epopd(0,2);
  Cpop();
  goto s_44;
  t_44 :
  Cpush(v_44);
  Epushd(0,0);
  MatchFun("Choices");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,0);
  Cpop();
  goto u_44;
  v_44 :
  Cpush(x_44);
  Epushd(0,2);
  MatchFun("Choices");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Choices",1);
  Tpush();
  BuildFun("Choice",2);
  Epopd(0,2);
  Cpop();
  goto w_44;
  x_44 :
  Cpush(z_44);
  Epushd(0,0);
  MatchFun("LChoices");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  BuildFun("Fail",0);
  Epopd(0,0);
  Cpop();
  goto y_44;
  z_44 :
  Epushd(0,2);
  MatchFun("LChoices");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("LChoices",1);
  Tpush();
  BuildFun("LChoice",2);
  Epopd(0,2);
  y_44 :
  w_44 :
  u_44 :
  s_44 :
  q_44 :
  o_44 :
  m_44 :
  k_44 :
  i_44 :
  Return();
  u_114 :
  Epushd(0,4);
  MatchFun("Build");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Rpush(a_45);
  s_107 :
  Cpush(c_45);
  MatchFun("App");
  Arg(0);
  MatchFun("Build");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,3);
  Cpop();
  goto b_45;
  c_45 :
  IsAppl();
  OneInit();
  d_45 :
  OneNextSon();
  Cpush(d_45);
  Rpush(f_45);
  goto s_107;
  f_45 :
  Cpop();
  OneBuild();
  b_45 :
  Return();
  a_45 :
  MatchVard(0,4);
  Tpop();
  BuildVard(0,4);
  Tpush();
  BuildFun("Build",1);
  Epopd(0,4);
  Return();
  v_114 :
  Epushd(0,5);
  MatchFun("Build");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tdupl();
  new();
  MatchVard(0,4);
  BuildVard(0,3);
  Rpush(g_45);
  t_107 :
  Cpush(k_45);
  MatchFun("App");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,4);
  Tpush();
  BuildFun("Var",1);
  Cpop();
  goto j_45;
  k_45 :
  IsAppl();
  OneInit();
  l_45 :
  OneNextSon();
  Cpush(l_45);
  Rpush(n_45);
  goto t_107;
  n_45 :
  Cpop();
  OneBuild();
  j_45 :
  Return();
  g_45 :
  MatchVard(0,5);
  Tpop();
  BuildVard(0,4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildFun("BAM",3);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Scope",2);
  Epopd(0,5);
  Return();
  w_114 :
  Epushd(0,3);
  MatchVard(0,1);
  Tdupl();
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(p_45);
  o_45 :
  Cpush(r_45);
  Epushd(1,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,4);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(1,4);
  Rpush(s_45);
  goto x_114;
  s_45 :
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,4);
  Cpop();
  goto q_45;
  r_45 :
  Epushd(1,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,4);
  q_45 :
  Tduplinv();
  goto o_45;
  p_45 :
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,3);
  Rpush(t_45);
  goto y_114;
  t_45 :
  Epushd(0,6);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  MatchVard(0,5);
  Tdupl();
  BuildVard(0,5);
  Cpush(v_45);
  Rpush(w_45);
  w_108 :
  Cpush(y_45);
  Rpush(z_45);
  goto m_112;
  z_45 :
  Cpop();
  goto x_45;
  y_45 :
  Cpush(b_46);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchFun("SDef");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  Tpop();
  Arg(2);
  Tpop();
  Tdupl();
  Cpush(c_46);
  Tdupl();
  BuildVard(1,1);
  MatchString("main");
  Cpop();
  Crestore();
  Cjump();
  c_46 :
  Tpop();
  Epushd(2,1);
  BuildFun("TNil",0);
  new();
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  OneNextSon();
  Rpush(d_46);
  goto w_108;
  d_46 :
  AllBuild();
  Cpop();
  goto a_46;
  b_46 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(e_46);
  goto w_108;
  e_46 :
  a_46 :
  x_45 :
  Return();
  w_45 :
  Cpop();
  goto u_45;
  v_45 :
  Rpush(f_46);
  h_109 :
  Cpush(h_46);
  Rpush(i_46);
  goto m_112;
  i_46 :
  Cpop();
  goto g_46;
  h_46 :
  Cpush(k_46);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchFun("SDef");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  Tpop();
  Arg(2);
  Tpop();
  Tdupl();
  Cpush(l_46);
  Tdupl();
  BuildVard(1,1);
  MatchString("main");
  Cpop();
  Crestore();
  Cjump();
  l_46 :
  Tpop();
  Epushd(2,1);
  BuildFun("TNil",0);
  new();
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  OneNextSon();
  AllBuild();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(m_46);
  goto h_109;
  m_46 :
  AllBuild();
  Cpop();
  goto j_46;
  k_46 :
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Rpush(n_46);
  goto h_109;
  n_46 :
  j_46 :
  g_46 :
  Return();
  f_46 :
  u_45 :
  MatchVard(0,3);
  BuildVard(0,3);
  Rpush(o_46);
  p_109 :
  Cpush(q_46);
  Rpush(r_46);
  goto m_112;
  r_46 :
  Cpop();
  goto p_46;
  q_46 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Call",2);
  Epopd(1,1);
  OneNextSon();
  Rpush(s_46);
  goto b_113;
  s_46 :
  AllBuild();
  AllBuild();
  OneNextSon();
  Rpush(t_46);
  goto p_109;
  t_46 :
  AllBuild();
  p_46 :
  Return();
  o_46 :
  MatchVard(0,4);
  BuildVard(0,5);
  Rpush(u_46);
  j_110 :
  Cpush(w_46);
  Rpush(x_46);
  goto m_112;
  x_46 :
  Cpop();
  goto v_46;
  w_46 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,4);
  MatchFun("SDef");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Arg(2);
  MatchVard(1,2);
  Tpop();
  Tdupl();
  Cpush(z_46);
  BuildVard(0,3);
  Tdupl();
  a_47 :
  MatchFun("Cons");
  Cpush(b_47);
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Cpop();
  goto c_47;
  b_47 :
  Arg(1);
  Tdrop();
  goto a_47;
  c_47 :
  Tpop();
  Cpop();
  goto y_46;
  z_46 :
  BuildVard(1,3);
  MatchVard(1,4);
  y_46 :
  Tpop();
  Epushd(2,1);
  BuildVard(1,2);
  Epushd(3,1);
  Tdupl();
  BuildVard(0,4);
  MatchVard(3,1);
  Tpop();
  Rpush(d_47);
  g_111 :
  Cpush(f_47);
  Epushd(4,3);
  MatchFun("Call");
  Arg(0);
  MatchFun("SVar");
  Arg(0);
  MatchVard(4,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  BuildVard(4,1);
  MatchVard(4,2);
  Tdupl();
  BuildVard(3,1);
  Tdupl();
  g_47 :
  MatchFun("Cons");
  Cpush(h_47);
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Cpop();
  goto i_47;
  h_47 :
  Arg(1);
  Tdrop();
  goto g_47;
  i_47 :
  Tpop();
  Tpop();
  BuildVard(4,3);
  Epopd(4,3);
  Cpop();
  goto e_47;
  f_47 :
  AllInit();
  j_47 :
  AllNextSon(&&k_47);
  Rpush(l_47);
  goto g_111;
  l_47 :
  goto j_47;
  k_47 :
  AllBuild();
  e_47 :
  Return();
  d_47 :
  Epopd(3,1);
  MatchVard(2,1);
  BuildVard(1,4);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("SDef",3);
  Epopd(2,1);
  Epopd(1,4);
  OneNextSon();
  Rpush(m_47);
  goto j_110;
  m_47 :
  AllBuild();
  v_46 :
  Return();
  u_46 :
  MatchVard(0,6);
  Tpop();
  BuildVard(0,6);
  Epopd(0,6);
  Return();
  x_114 :
  Cpush(o_47);
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("Cons");
  OneNextSon();
  AllBuild();
  Cpop();
  goto n_47;
  o_47 :
  Cpush(r_47);
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  Cpush(s_47);
  Tdupl();
  MatchString("main");
  Cpop();
  Crestore();
  Cjump();
  s_47 :
  OneNextSon();
  Rpush(t_47);
  goto m_112;
  t_47 :
  OneNextSon();
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("Seq");
  TravInit();
  OneNextSon();
  MatchFun("Match");
  OneNextSon();
  AllBuild();
  AllBuild();
  AllBuild();
  Cpop();
  goto p_47;
  r_47 :
  MatchFun("SDef");
  TravInit();
  OneNextSon();
  Cpush(u_47);
  Tdupl();
  MatchString("main");
  Cpop();
  Crestore();
  Cjump();
  u_47 :
  OneNextSon();
  Rpush(v_47);
  goto m_112;
  v_47 :
  OneNextSon();
  MatchFun("Seq");
  TravInit();
  OneNextSon();
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("Seq");
  TravInit();
  OneNextSon();
  MatchFun("Match");
  OneNextSon();
  AllBuild();
  AllBuild();
  OneNextSon();
  AllBuild();
  AllBuild();
  p_47 :
  n_47 :
  Return();
  y_114 :
  Rpush(w_47);
  r_27 :
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  AllInit();
  x_47 :
  AllNextSon(&&y_47);
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Rpush(z_47);
  goto r_27;
  z_47 :
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchVard(2,1);
  Tpop();
  BuildVard(2,2);
  Epopd(2,2);
  goto x_47;
  y_47 :
  AllBuild();
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Epopd(0,2);
  Cpush(b_48);
  Rpush(c_48);
  goto z_114;
  c_48 :
  Cpush(e_48);
  d_48 :
  Rpush(f_48);
  goto z_114;
  f_48 :
  Tduplinv();
  goto d_48;
  e_48 :
  Rpush(g_48);
  goto r_27;
  g_48 :
  Cpop();
  goto a_48;
  b_48 :
  a_48 :
  Return();
  w_47 :
  Return();
  z_114 :
  Cpush(i_48);
  Epushd(0,5);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Call");
  Arg(0);
  MatchFun("SVar");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,5);
  Tdupl();
  j_48 :
  MatchFun("Cons");
  Cpush(k_48);
  Arg(0);
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Cpop();
  goto l_48;
  k_48 :
  Arg(1);
  Tdrop();
  goto j_48;
  l_48 :
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,4);
  Rpush(m_48);
  goto y_113;
  m_48 :
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,3);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(3,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Epushd(4,3);
  BuildVard(3,1);
  Tpush();
  BuildVard(3,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(n_48);
  x_111 :
  Cpush(p_48);
  Epushd(5,0);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildFun("Nil",0);
  Epopd(5,0);
  Cpop();
  goto o_48;
  p_48 :
  Epushd(5,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchVard(5,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchVard(5,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(5,1);
  Tpush();
  BuildVard(5,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(5,3);
  Tpush();
  BuildVard(5,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(5,4);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Epushd(5,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(5,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(5,2);
  Tpush();
  BuildFun("SDef",3);
  Epopd(5,2);
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(q_48);
  goto x_111;
  q_48 :
  OneNextSon();
  Rpush(r_48);
  goto b_113;
  r_48 :
  AllBuild();
  AllBuild();
  Epushd(5,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(5,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(5,1);
  Tpush();
  BuildVard(5,2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(5,2);
  o_48 :
  Return();
  n_48 :
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildVard(3,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(4,3);
  Rpush(s_48);
  k_112 :
  Cpush(u_48);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(v_48);
  goto k_112;
  v_48 :
  AllBuild();
  Cpop();
  goto t_48;
  u_48 :
  Rpush(w_48);
  goto m_112;
  w_48 :
  BuildVard(4,2);
  t_48 :
  Return();
  s_48 :
  Epopd(4,3);
  Epopd(3,3);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,5);
  Cpop();
  goto h_48;
  i_48 :
  Epushd(0,4);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Call");
  Arg(0);
  MatchFun("SVar");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,4);
  Tdupl();
  x_48 :
  MatchFun("Cons");
  Cpush(y_48);
  Arg(0);
  MatchFun("SDef");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  Arg(2);
  MatchFun("Call");
  Arg(0);
  MatchFun("SVar");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Nil");
  Tpop();
  Tpop();
  Tpop();
  Cpop();
  goto z_48;
  y_48 :
  Arg(1);
  Tdrop();
  goto x_48;
  z_48 :
  Tpop();
  Tpop();
  BuildVard(0,3);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("Call",2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,4);
  h_48 :
  Return();
  a_49 :
DOIT_END
