\literate[Needed Definitions]

% $Id: needed-defs.r,v 1.3 2000/01/20 17:53:36 visser Exp $

% Copyright (C) 1998, 1999, 2000 Eelco Visser <visser@acm.org>
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
% 02111-1307, USA.


	Extract those definitions that are needed for the strategy
	\cd{main}.

\begin{code}
module needed-defs
imports strategy sugar stratlib list-set list-misc lib
\end{code}

\begin{code}
rules

  Init: defs -> (["main"], ["main"], [], defs)

  Next: (Cons(f, needed), seen, ndefs, defs) ->
	(needed'', seen', Cons(<joindefs> fdefs, ndefs), defs)
	where
	  <filter(match(SDef(f,_,_)))> defs => fdefs;
	  <diff> (<svars> fdefs, seen) => needed';
	  <conc> (needed', needed) => needed'';
          <conc> (needed', seen) => seen'

  End : ([], seen, ndefs, defs) -> ndefs

  JoinDefs1 : [sdef] -> sdef

  JoinDefs2 : Cons(SDef(f, xs, s), defs) -> SDef(f, ys, Choices(ss))
	      where <map(new)> xs => ys ;
		    <map(MkCall)> ys => ys' ; 
		    <map({zs, s: <<SDef(f, zs, s) -> <ssubs> (zs, ys', s)>>})>
                     Cons(SDef(f, xs, s), defs) => ss

  MissingDef : (Cons(f, fs), seen, ndefs, defs) -> 
               ["error: operator ", f, " undefined "]

strategies

  joindefs = JoinDefs1 <+ JoinDefs2  

  needed-defs = Init; repeat(Next); (End <+ (MissingDef; fatal-error; FAIL))
\end{code}