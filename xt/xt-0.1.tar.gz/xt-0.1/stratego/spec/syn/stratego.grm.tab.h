/*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

typedef union{
   int    num;
   double real;
   char   *string;
   ATerm  term;
   ATermList list;
} YYSTYPE;
#define	LCID	257
#define	STRINGTOK	258
#define	UCID	259
#define	ID	260
#define	ARROW	261
#define	LONGARROW	262
#define	ASSIGN	263
#define	ASTERISK	264
#define	BACKARROW	265
#define	BAR	266
#define	BUILD	267
#define	ANNBUILD	268
#define	ANNRM	269
#define	BUILDe	270
#define	COMMA	271
#define	EQ	272
#define	FAIL	273
#define	GG	274
#define	IMPORTS	275
#define	KIDS	276
#define	LBRACK	277
#define	LCURLY	278
#define	LL	279
#define	LPAREN	280
#define	LT	281
#define	GT	282
#define	ANNMATCH	283
#define	MATCH	284
#define	MATCHe	285
#define	MODULE	286
#define	NEW	287
#define	OPERATIONS	288
#define	OVERLAYS	289
#define	PARSEPROG	290
#define	PARSEQUERY	291
#define	PRIM	292
#define	RCURLY	293
#define	RPAREN	294
#define	RULES	295
#define	SIGNATURE	296
#define	SORTS	297
#define	STARSTAR	298
#define	STRATEGIES	299
#define	STR_GT	300
#define	SUCC	301
#define	UNDERSCORE	302
#define	DOT	303
#define	BACKSLASH	304
#define	COLON	305
#define	DOUBLECOLON	306
#define	PLUS	307
#define	LTPLUS	308
#define	SEMICOLON	309
#define	DOUBLEARROW	310
#define	RBRACK	311
#define	NOT	312
#define	WHERE	313
#define	TEST	314
#define	ONE	315
#define	ALL	316
#define	THREAD	317
#define	SOMETOK	318
#define	MU	319
#define	REAL	320
#define	INT	321

