/*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(l_4);
  goto main;
  main :
  Epushd(0,9);
  Cpush(b_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  OneNextSon();
  Rpush(c_0);
  p_29 :
  Cpush(e_0);
  Rpush(f_0);
  goto e_31;
  f_0 :
  Cpop();
  goto d_0;
  e_0 :
  Cpush(h_0);
  Cpush(j_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto i_0;
  j_0 :
  Cpush(l_0);
  Rpush(m_0);
  goto f_31;
  m_0 :
  Cpop();
  goto k_0;
  l_0 :
  Cpush(o_0);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto n_0;
  o_0 :
  Cpush(q_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-i");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,3);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto p_0;
  q_0 :
  Cpush(s_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-o");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,4);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto r_0;
  s_0 :
  Cpush(u_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto t_0;
  u_0 :
  Cpush(w_0);
  Rpush(x_0);
  goto f_31;
  x_0 :
  Cpop();
  goto v_0;
  w_0 :
  Cpush(z_0);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto y_0;
  z_0 :
  Cpush(b_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto a_1;
  b_1 :
  Cpush(d_1);
  Rpush(e_1);
  goto f_31;
  e_1 :
  Cpop();
  goto c_1;
  d_1 :
  Cpush(g_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto f_1;
  g_1 :
  Cpush(i_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto h_1;
  i_1 :
  Cpush(k_1);
  Rpush(l_1);
  goto f_31;
  l_1 :
  Cpop();
  goto j_1;
  k_1 :
  Cpush(n_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto m_1;
  n_1 :
  Cpush(p_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto o_1;
  p_1 :
  Cpush(r_1);
  Rpush(s_1);
  goto f_31;
  s_1 :
  Cpop();
  goto q_1;
  r_1 :
  Cpush(u_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto t_1;
  u_1 :
  Cpush(w_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto v_1;
  w_1 :
  Cpush(y_1);
  Rpush(z_1);
  goto f_31;
  z_1 :
  Cpop();
  goto x_1;
  y_1 :
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  AllBuild();
  x_1 :
  v_1 :
  t_1 :
  q_1 :
  o_1 :
  m_1 :
  j_1 :
  h_1 :
  f_1 :
  c_1 :
  a_1 :
  y_0 :
  v_0 :
  t_0 :
  r_0 :
  p_0 :
  n_0 :
  k_0 :
  i_0 :
  Rpush(a_2);
  goto p_29;
  a_2 :
  Cpop();
  goto g_0;
  h_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(b_2);
  goto p_29;
  b_2 :
  AllBuild();
  g_0 :
  d_0 :
  Return();
  c_0 :
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto a_0;
  b_0 :
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildStr("");
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(c_2);
  goto l_31;
  c_2 :
  Tpop();
  Rpush(d_2);
  goto g_31;
  d_2 :
  BuildInt(1);
  Rpush(e_2);
  goto m_31;
  e_2 :
  a_0 :
  Cpush(g_2);
  Tdupl();
  BuildVard(0,7);
  Tpop();
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(h_2);
  goto l_31;
  h_2 :
  Tpop();
  Rpush(i_2);
  goto g_31;
  i_2 :
  BuildInt(1);
  Rpush(j_2);
  goto m_31;
  j_2 :
  Cpop();
  goto f_2;
  g_2 :
  Cpush(l_2);
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  Cpush(n_2);
  BuildVard(0,3);
  Cpop();
  goto m_2;
  n_2 :
  BuildFun("stdin",0);
  m_2 :
  Rpush(o_2);
  goto h_31;
  o_2 :
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Tdupl();
  Rpush(p_2);
  goto i_31;
  p_2 :
  Tpop();
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Rpush(q_2);
  q_30 :
  Cpush(s_2);
  MatchFun("cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(t_2);
  goto q_30;
  t_2 :
  AllBuild();
  Cpop();
  goto r_2;
  s_2 :
  AllInit();
  u_2 :
  AllNextSon(&&v_2);
  Rpush(w_2);
  goto q_30;
  w_2 :
  goto u_2;
  v_2 :
  AllBuild();
  r_2 :
  Cpush(y_2);
  Cpush(a_3);
  Epushd(1,0);
  MatchFun("primes");
  BuildInt(2);
  Tpush();
  BuildFun("from",1);
  Tpush();
  BuildFun("sieve",1);
  Epopd(1,0);
  Cpop();
  goto z_2;
  a_3 :
  Cpush(c_3);
  Epushd(1,1);
  MatchFun("from");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Epushd(2,1);
  BuildVard(1,1);
  Tpush();
  BuildInt(1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(d_3);
  goto n_31;
  d_3 :
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("from",1);
  Tpush();
  BuildFun("cons",2);
  Epopd(2,1);
  Epopd(1,1);
  Cpop();
  goto b_3;
  c_3 :
  Cpush(f_3);
  Epushd(1,2);
  MatchFun("sieve");
  Arg(0);
  MatchFun("cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("filter",2);
  Tpush();
  BuildFun("sieve",1);
  Tpush();
  BuildFun("cons",2);
  Epopd(1,2);
  Cpop();
  goto e_3;
  f_3 :
  Cpush(h_3);
  Epushd(1,3);
  MatchFun("filter");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(1,2);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(i_3);
  goto o_31;
  i_3 :
  Tpop();
  BuildVard(1,2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("filter",2);
  Epopd(1,3);
  Cpop();
  goto g_3;
  h_3 :
  Cpush(k_3);
  Epushd(1,3);
  MatchFun("filter");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(1,2);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(l_3);
  Tdupl();
  Rpush(m_3);
  goto o_31;
  m_3 :
  Cpop();
  Crestore();
  Cjump();
  l_3 :
  Tpop();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("filter",2);
  Tpush();
  BuildFun("cons",2);
  Epopd(1,3);
  Cpop();
  goto j_3;
  k_3 :
  Cpush(o_3);
  Epushd(1,2);
  MatchFun("take");
  Arg(0);
  MatchInt(0);
  Tpop();
  Arg(1);
  MatchFun("cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildFun("nil",0);
  Epopd(1,2);
  Cpop();
  goto n_3;
  o_3 :
  Epushd(1,3);
  MatchFun("take");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchFun("cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(1,3);
  Tpush();
  BuildInt(0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(p_3);
  goto r_31;
  p_3 :
  Tpop();
  Epushd(2,1);
  BuildVard(1,3);
  Tpush();
  BuildInt(1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(q_3);
  goto q_31;
  q_3 :
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("take",2);
  Tpush();
  BuildFun("cons",2);
  Epopd(2,1);
  Epopd(1,3);
  n_3 :
  j_3 :
  g_3 :
  e_3 :
  b_3 :
  z_2 :
  Rpush(r_3);
  goto q_30;
  r_3 :
  Cpop();
  goto x_2;
  y_2 :
  x_2 :
  Return();
  q_2 :
  Tdupl();
  Rpush(s_3);
  goto i_31;
  s_3 :
  MatchVard(0,9);
  Tpop();
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(u_3);
  BuildVard(0,4);
  Cpop();
  goto t_3;
  u_3 :
  BuildFun("stdout",0);
  t_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(w_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(x_3);
  goto j_31;
  x_3 :
  Cpop();
  goto v_3;
  w_3 :
  Rpush(y_3);
  goto k_31;
  y_3 :
  v_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting succeeded (");
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildStr(" secs)");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(z_3);
  goto l_31;
  z_3 :
  BuildInt(0);
  Rpush(a_4);
  goto m_31;
  a_4 :
  Cpop();
  goto k_2;
  l_2 :
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(c_4);
  BuildVard(0,4);
  Cpop();
  goto b_4;
  c_4 :
  BuildFun("stdout",0);
  b_4 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(e_4);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(f_4);
  goto j_31;
  f_4 :
  Cpop();
  goto d_4;
  e_4 :
  Rpush(g_4);
  goto k_31;
  g_4 :
  d_4 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(h_4);
  goto l_31;
  h_4 :
  BuildInt(1);
  Rpush(i_4);
  goto m_31;
  i_4 :
  k_2 :
  f_2 :
  Epopd(0,9);
  Return();
  e_31 :
  MatchFun("Nil");
  Return();
  f_31 :
  MatchFun("None");
  Return();
  g_31 :
  Tdupl();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stderr",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  Epushd(3,1);
  MatchVard(3,1);
  BuildVard(3,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(j_4);
  goto l_31;
  j_4 :
  Tpop();
  Return();
  h_31 :
  _ST_ReadFromFile();
  Return();
  i_31 :
  _ST_dtime();
  Return();
  j_31 :
  _ST_WriteToBinaryFile();
  Return();
  k_31 :
  _ST_WriteToTextFile();
  Return();
  l_31 :
  _ST_printnl();
  Return();
  m_31 :
  _ST_exit();
  Return();
  n_31 :
  _ST_add();
  Return();
  o_31 :
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  Rpush(k_4);
  goto p_31;
  k_4 :
  MatchInt(0);
  Return();
  p_31 :
  _ST_mod();
  Return();
  q_31 :
  _ST_minus();
  Return();
  r_31 :
  _ST_gt();
  Return();
  l_4 :
DOIT_END
