/*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(g_0);
  goto main;
  main :
  Cpush(b_0);
  BuildFun("stdin",0);
  Rpush(c_0);
  goto k_15;
  c_0 :
  Rpush(d_0);
  goto n_15;
  d_0 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stdout",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(e_0);
  goto l_15;
  e_0 :
  Cpop();
  goto a_0;
  b_0 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(f_0);
  goto m_15;
  f_0 :
  a_0 :
  Return();
  k_15 :
  _ST_ReadFromFile();
  Return();
  l_15 :
  _ST_WriteToTextFile();
  Return();
  m_15 :
  _ST_printnl();
  Return();
  n_15 :
  Epushd(0,3);
  MatchFun("F");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("G");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("H",3);
  Epopd(0,3);
  Return();
  g_0 :
DOIT_END
