
\literate[Library for Strategies]
	
% $Id: stratlib.r,v 1.5 2000/01/20 17:53:37 visser Exp $

% Copyright (C) 1998, 1999, 2000 Eelco Visser <visser@acm.org>
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
% 02111-1307, USA.


	This module instantiates several language independent functions
	defined in module subs to the strategy language. 

\begin{code}
module stratlib
imports strategy substitution
\end{code}

\begin{code}
rules

  Add1 : Var(x)  -> [x]
  Add2 : SVar(x) -> [x]
 
  IsVar  : Var(x) -> x
  IsSVar : Call(SVar(x), []) -> x
  MkTVar : x -> Var(x)
  MkSVar : x -> SVar(x)
  MkCall : x -> Call(SVar(x), [])

  Bind0 : Scope(xs, s) -> xs
  Bind0 : LRule(Rule(t1, t2, s)) -> <tvars> t1
  Bind1 : Let(SDef(f, xs, s1), s2) -> [f]
  Bind2 : SDef(f, xs, s) -> xs
  Bind3 : Rec(x, s) -> [x]
\end{code}

\begin{code}
strategies

  tvars = vars(Add1, Bind0)
  svars = vars(Add2, Bind1 + Bind2 + Bind3)

  tsubs = subs(IsVar)
  ssubs = subs(IsSVar)

  rn_apply(nvs, bnd, nbnd) = Scope(nvs, bnd)
  			   + Let(SDef(nvs ; Hd, id, id) ; nbnd, bnd)
  			   + SDef(id, nvs, bnd)
			   + Rec(nvs ; Hd, bnd)

(*
  trename = rename(Var(id), MkTVar, Bind0)
  srename = rename(SVar(id), MkSVar, Bind1 + Bind2 + Bind3)
*)

  tapply(nvs, bnd, nbnd) = Scope(nvs, bnd)
  
  sapply(nvs, bnd, nbnd) = Let(SDef(nvs ; Hd, id, id) ; nbnd, bnd)
  			   + SDef(id, nvs, bnd)
			   + Rec(nvs ; Hd, bnd)

  trename = rename(Var, Bind0, tapply)
  srename = rename(SVar, Bind1 + Bind2 + Bind3, sapply)

  strename = trename ; srename

  is_var_list = map({x:match(Var(x))})
  is_svar_list = map({x:match(SVar(x))})
\end{code}

	Context strategies for strategies

\begin{code}
strategies

  conLChoice(s) = rec x(s + LChoice(x, id) + LChoice(id, x))

  conChoice(s) = rec x(s + (Choice(x, id) + Choice(id, x)))

  conChoiceL(s) = Choice(s, id) + s

  choicebu-l'(s) = rec x(try(Choice(id, x); s))

  choicebu-l(s) = rec x(try(Choice(x, x); s))

  choicetd(s) = rec x(s <+ Choice(x, x))

  choicemap(s) = rec x(Choice(x, x) <+ s)

  choicebu(s) = rec x(try(Choice(x, x); s))

  firstInSeq(s) = s <+ Seq(s, id)

  lastInSeq(s) = Seq(id, rec x(s <+ Seq(not(oncetd(s)), x)))
\end{code}