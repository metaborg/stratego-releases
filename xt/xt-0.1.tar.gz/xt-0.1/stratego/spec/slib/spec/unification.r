\literate[{\btt UNIFICATION}]


% Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2, or (at your option)
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
% 02111-1307, USA.


\begin{code}
module unification
imports list term substitution
\end{code}

	Syntactic unification, no variable bindings are taken into
	account.

\begin{code}
strategies

  unify(isvar) = InitUnify; rec x(Unified + Unify(isvar); x)

rules 

  InitUnify : pairs -> ([], pairs)

  Unified : 
	(sbs, []) -> sbs

  Unify(isvar) : 
	(sbs, Cons((Var(x),Var(x)), ps)) -> 
	(sbs, ps)

  Unify(isvar) : 
	(sbs, Cons((x,y), ps)) -> 
	(Cons((x, y), sbs''), ps')
	where <isvar> x; <eq + not(in)>(x,y); 
              <subs'(isvar, ![(x,y)])> (sbs, ps) => (sbs'', ps')

  Unify(isvar) : 
	(sbs, Cons((x,y), ps)) -> 
	(sbs, Cons((y,x), ps))
	where <not(isvar)> x; <isvar> y

  Unify(isvar) : 
	(sbs, Cons((x,y), ps)) ->
	(sbs, <conc>(ps', ps))
	where <not(isvar)> x; <not(isvar)> y;
	      <explode-term> x => (f, xs); <explode-term> y => (f, ys);
	      <zip(id)> (xs, ys) => ps'
\end{code}
