module BinSet
imports lib bin-tree-set
strategies

  main = stdio((mkbinset, mkbinset); debug; merge)