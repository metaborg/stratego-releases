#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(n_3);
  goto main;
  main :
  Cpush(b_0);
  BuildFun("stdin",0);
  Rpush(c_0);
  goto f_31;
  c_0 :
  Rpush(d_0);
  c_30 :
  Cpush(f_0);
  Rpush(g_0);
  goto i_31;
  g_0 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Epushd(2,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(2,1);
  Rpush(h_0);
  goto k_31;
  h_0 :
  Epushd(4,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildFun("Var",1);
  Epopd(4,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(2,1);
  Rpush(i_0);
  d_30 :
  Cpush(k_0);
  Rpush(l_0);
  goto j_31;
  l_0 :
  Cpop();
  goto j_0;
  k_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(m_0);
  goto k_31;
  m_0 :
  Epushd(5,1);
  MatchVard(5,1);
  BuildVard(5,1);
  Tpush();
  BuildFun("Var",1);
  Epopd(5,1);
  OneNextSon();
  Rpush(n_0);
  goto d_30;
  n_0 :
  AllBuild();
  j_0 :
  Return();
  i_0 :
  MatchVard(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epopd(3,1);
  Epopd(2,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  Rpush(s_0);
  e_30 :
  Cpush(u_0);
  Rpush(v_0);
  goto j_31;
  v_0 :
  Cpop();
  goto t_0;
  u_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(w_0);
  goto c_30;
  w_0 :
  OneNextSon();
  Rpush(x_0);
  goto e_30;
  x_0 :
  AllBuild();
  t_0 :
  Return();
  s_0 :
  Rpush(y_0);
  goto n_31;
  y_0 :
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(z_0);
  goto p_31;
  z_0 :
  Cpop();
  goto e_0;
  f_0 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  Epushd(2,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(2,1);
  Rpush(a_1);
  goto k_31;
  a_1 :
  Epushd(4,1);
  MatchVard(4,1);
  BuildVard(4,1);
  Tpush();
  BuildFun("Var",1);
  Epopd(4,1);
  MatchVard(3,1);
  Epushd(4,1);
  BuildVard(2,1);
  AllInit();
  b_1 :
  AllNextSon(&&c_1);
  Rpush(d_1);
  goto k_31;
  d_1 :
  Epushd(5,1);
  MatchVard(5,1);
  BuildVard(5,1);
  Tpush();
  BuildFun("Var",1);
  Epopd(5,1);
  goto b_1;
  c_1 :
  AllBuild();
  MatchVard(4,1);
  BuildVard(3,1);
  Tpush();
  BuildVard(4,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(4,1);
  Epopd(3,1);
  Epopd(2,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  Rpush(e_1);
  goto l_31;
  e_1 :
  Rpush(f_1);
  f_30 :
  Cpush(h_1);
  Rpush(i_1);
  goto j_31;
  i_1 :
  Cpop();
  goto g_1;
  h_1 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(j_1);
  goto c_30;
  j_1 :
  OneNextSon();
  Rpush(k_1);
  goto f_30;
  k_1 :
  AllBuild();
  g_1 :
  Return();
  f_1 :
  Rpush(l_1);
  goto n_31;
  l_1 :
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(m_1);
  goto p_31;
  m_1 :
  e_0 :
  Return();
  d_0 :
  Epushd(0,3);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("GraphLet",2);
  Epopd(0,3);
  Cpush(o_1);
  n_1 :
  Cpush(q_1);
  Rpush(r_1);
  goto q_31;
  r_1 :
  Epushd(0,4);
  MatchFun("GraphLet");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tdupl();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(s_1);
  Tdupl();
  Epushd(1,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,3);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  Tpop();
  BuildVard(2,3);
  Epopd(2,3);
  Rpush(y_1);
  t_1 :
  Cpush(u_1);
  MatchVard(1,1);
  Cpop();
  goto x_1;
  u_1 :
  IsAppl();
  MatchTravInit();
  v_1 :
  OneMatchNextSon();
  Cpush(v_1);
  Rpush(w_1);
  goto t_1;
  w_1 :
  Cpop();
  MatchTravEnd();
  x_1 :
  Return();
  y_1 :
  Epopd(1,1);
  Cpop();
  Crestore();
  Cjump();
  s_1 :
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("GraphLet",2);
  Epopd(0,4);
  Cpop();
  goto p_1;
  q_1 :
  Cpush(a_2);
  Epushd(0,4);
  MatchFun("GraphLet");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tdupl();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(b_2);
  Tdupl();
  Epushd(1,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,3);
  Tpop();
  Arg(1);
  MatchVard(2,2);
  Tpop();
  Tpop();
  BuildVard(2,3);
  Epopd(2,3);
  Rpush(h_2);
  c_2 :
  Cpush(d_2);
  MatchVard(1,1);
  Cpop();
  goto g_2;
  d_2 :
  IsAppl();
  MatchTravInit();
  e_2 :
  OneMatchNextSon();
  Cpush(e_2);
  Rpush(f_2);
  goto c_2;
  f_2 :
  Cpop();
  MatchTravEnd();
  g_2 :
  Return();
  h_2 :
  Epopd(1,1);
  Cpop();
  Crestore();
  Cjump();
  b_2 :
  Tpop();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("GraphLet",2);
  Epopd(0,4);
  Cpop();
  goto z_1;
  a_2 :
  Epushd(0,4);
  MatchFun("GraphLet");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,3);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  BuildVard(2,1);
  Tpush();
  BuildVard(2,2);
  Tpush();
  BuildVard(2,3);
  Tpush();
  BuildFun("Let",3);
  Epopd(2,3);
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("GraphLet",2);
  Epopd(1,1);
  Epopd(0,4);
  z_1 :
  p_1 :
  Tduplinv();
  goto n_1;
  o_1 :
  Epushd(0,1);
  MatchFun("GraphLet");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  BuildVard(0,1);
  Epopd(0,1);
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stdout",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(i_2);
  goto g_31;
  i_2 :
  Cpop();
  goto a_0;
  b_0 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(j_2);
  goto h_31;
  j_2 :
  a_0 :
  Return();
  f_31 :
  _ST_ReadFromFile();
  Return();
  g_31 :
  _ST_WriteToTextFile();
  Return();
  h_31 :
  _ST_printnl();
  Return();
  i_31 :
  Cpush(l_2);
  Rpush(m_2);
  goto j_31;
  m_2 :
  Cpop();
  goto k_2;
  l_2 :
  MatchFun("Cons");
  k_2 :
  Return();
  j_31 :
  MatchFun("Nil");
  Return();
  k_31 :
  _ST_address();
  Return();
  l_31 :
  Rpush(n_2);
  goto m_31;
  n_2 :
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,3);
  Epopd(0,3);
  Return();
  m_31 :
  _ST_explode_term();
  Return();
  n_31 :
  Rpush(o_2);
  v_30 :
  Cpush(q_2);
  Rpush(r_2);
  goto j_31;
  r_2 :
  BuildFun("Nil",0);
  Cpop();
  goto p_2;
  q_2 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(s_2);
  goto v_30;
  s_2 :
  OneNextSon();
  Rpush(t_2);
  goto o_31;
  t_2 :
  AllBuild();
  AllBuild();
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Rpush(u_2);
  c_31 :
  Cpush(w_2);
  Rpush(x_2);
  goto j_31;
  x_2 :
  BuildVard(0,2);
  Cpop();
  goto v_2;
  w_2 :
  Cpush(z_2);
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tdupl();
  a_3 :
  MatchFun("Cons");
  Cpush(b_3);
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Cpop();
  goto c_3;
  b_3 :
  Arg(1);
  Tdrop();
  goto a_3;
  c_3 :
  Tpop();
  Tpop();
  BuildVard(1,1);
  Epopd(1,2);
  Rpush(d_3);
  goto c_31;
  d_3 :
  Cpop();
  goto y_2;
  z_2 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(e_3);
  goto c_31;
  e_3 :
  AllBuild();
  y_2 :
  v_2 :
  Return();
  u_2 :
  Epopd(0,2);
  p_2 :
  Return();
  o_2 :
  Return();
  o_31 :
  MatchFun("TNil");
  Return();
  p_31 :
  Cpush(g_3);
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Nil");
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto f_3;
  g_3 :
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,3);
  f_3 :
  Return();
  q_31 :
  Epushd(0,5);
  MatchFun("GraphLet");
  Arg(0);
  MatchFun("Cons");
  Arg(0);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tdupl();
  BuildVard(0,3);
  Rpush(h_3);
  e_31 :
  Cpush(j_3);
  MatchVard(0,1);
  BuildVard(0,4);
  Cpop();
  goto i_3;
  j_3 :
  IsAppl();
  OneInit();
  k_3 :
  OneNextSon();
  Cpush(k_3);
  Rpush(m_3);
  goto e_31;
  m_3 :
  Cpop();
  OneBuild();
  i_3 :
  Return();
  h_3 :
  MatchVard(0,5);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("GraphLet",2);
  Epopd(0,5);
  Return();
  n_3 :
DOIT_END
