/*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*/

#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(h_1);
  goto main;
  main :
  Cpush(b_0);
  BuildFun("stdin",0);
  Rpush(c_0);
  goto f_23;
  c_0 :
  Rpush(d_0);
  w_22 :
  Cpush(f_0);
  MatchFun("F");
  Epushd(0,1);
  MatchVard(0,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  Cpop();
  goto e_0;
  f_0 :
  Rpush(g_0);
  goto i_23;
  g_0 :
  Epushd(0,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,3);
  Epopd(0,3);
  Rpush(h_0);
  x_22 :
  Cpush(j_0);
  Rpush(k_0);
  goto j_23;
  k_0 :
  Cpop();
  goto i_0;
  j_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(l_0);
  goto w_22;
  l_0 :
  OneNextSon();
  Rpush(m_0);
  goto x_22;
  m_0 :
  AllBuild();
  i_0 :
  Return();
  h_0 :
  Rpush(n_0);
  y_22 :
  Cpush(p_0);
  Rpush(q_0);
  goto j_23;
  q_0 :
  BuildFun("Nil",0);
  Cpop();
  goto o_0;
  p_0 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(r_0);
  goto y_22;
  r_0 :
  OneNextSon();
  Rpush(s_0);
  goto k_23;
  s_0 :
  AllBuild();
  AllBuild();
  Rpush(t_0);
  goto l_23;
  t_0 :
  o_0 :
  Return();
  n_0 :
  e_0 :
  Return();
  d_0 :
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stdout",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(u_0);
  goto g_23;
  u_0 :
  Cpop();
  goto a_0;
  b_0 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(v_0);
  goto h_23;
  v_0 :
  a_0 :
  Return();
  f_23 :
  _ST_ReadFromFile();
  Return();
  g_23 :
  _ST_WriteToTextFile();
  Return();
  h_23 :
  _ST_printnl();
  Return();
  i_23 :
  _ST_explode_term();
  Return();
  j_23 :
  MatchFun("Nil");
  Return();
  k_23 :
  MatchFun("TNil");
  Return();
  l_23 :
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Rpush(w_0);
  v_15 :
  Cpush(y_0);
  Rpush(z_0);
  goto j_23;
  z_0 :
  BuildVard(0,2);
  Cpop();
  goto x_0;
  y_0 :
  Cpush(b_1);
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tdupl();
  c_1 :
  MatchFun("Cons");
  Cpush(d_1);
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Cpop();
  goto e_1;
  d_1 :
  Arg(1);
  Tdrop();
  goto c_1;
  e_1 :
  Tpop();
  Tpop();
  BuildVard(1,1);
  Epopd(1,2);
  Rpush(f_1);
  goto v_15;
  f_1 :
  Cpop();
  goto a_1;
  b_1 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(g_1);
  goto v_15;
  g_1 :
  AllBuild();
  a_1 :
  x_0 :
  Return();
  w_0 :
  Epopd(0,2);
  Return();
  h_1 :
DOIT_END
