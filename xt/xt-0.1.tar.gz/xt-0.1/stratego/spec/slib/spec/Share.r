module Share
imports lib share

strategies

  main = stdio(share(\ x -> Var(x)\, 
		     fail, 
                     \ (x,e,e') -> Let(x, e, e') \ ))