#include <stratego.h>
#include <stratego-lib.h>
#include <stratego-ext.h>
DOIT_START
cur_rule_counter = 0;
  Rpush(l_21);
  goto main;
  main :
  Epushd(0,9);
  Cpush(b_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,1);
  OneNextSon();
  Rpush(c_0);
  k_64 :
  Cpush(e_0);
  Rpush(f_0);
  goto z_78;
  f_0 :
  Cpop();
  goto d_0;
  e_0 :
  Cpush(h_0);
  Cpush(j_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto i_0;
  j_0 :
  Cpush(l_0);
  Rpush(m_0);
  goto a_79;
  m_0 :
  Cpop();
  goto k_0;
  l_0 :
  Cpush(o_0);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto n_0;
  o_0 :
  Cpush(q_0);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-silent");
  MatchVard(0,2);
  AllBuild();
  Cpop();
  goto p_0;
  q_0 :
  Cpush(s_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-i");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,3);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto r_0;
  s_0 :
  Cpush(u_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-o");
  OneNextSon();
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchVard(0,4);
  OneNextSon();
  AllBuild();
  AllBuild();
  Epushd(1,4);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,4);
  Tpop();
  BuildVard(1,4);
  Epopd(1,4);
  Cpop();
  goto t_0;
  u_0 :
  Cpush(w_0);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto v_0;
  w_0 :
  Cpush(y_0);
  Rpush(z_0);
  goto a_79;
  z_0 :
  Cpop();
  goto x_0;
  y_0 :
  Cpush(b_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto a_1;
  b_1 :
  Cpush(d_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-b");
  MatchVard(0,5);
  AllBuild();
  Cpop();
  goto c_1;
  d_1 :
  Cpush(f_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto e_1;
  f_1 :
  Cpush(h_1);
  Rpush(i_1);
  goto a_79;
  i_1 :
  Cpop();
  goto g_1;
  h_1 :
  Cpush(k_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto j_1;
  k_1 :
  Cpush(m_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-stats");
  MatchVard(0,6);
  AllBuild();
  Cpop();
  goto l_1;
  m_1 :
  Cpush(o_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto n_1;
  o_1 :
  Cpush(q_1);
  Rpush(r_1);
  goto a_79;
  r_1 :
  Cpop();
  goto p_1;
  q_1 :
  Cpush(t_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto s_1;
  t_1 :
  Cpush(v_1);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-help");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto u_1;
  v_1 :
  Cpush(x_1);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto w_1;
  x_1 :
  Cpush(z_1);
  Rpush(a_2);
  goto a_79;
  a_2 :
  Cpop();
  goto y_1;
  z_1 :
  Cpush(c_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto b_2;
  c_2 :
  Cpush(e_2);
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-h");
  MatchVard(0,7);
  AllBuild();
  Cpop();
  goto d_2;
  e_2 :
  Cpush(g_2);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  OneNextSon();
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto f_2;
  g_2 :
  Cpush(i_2);
  Rpush(j_2);
  goto a_79;
  j_2 :
  Cpop();
  goto h_2;
  i_2 :
  MatchFun("Some");
  TravInit();
  OneNextSon();
  MatchString("-pp");
  MatchVard(0,8);
  AllBuild();
  h_2 :
  f_2 :
  d_2 :
  b_2 :
  y_1 :
  w_1 :
  u_1 :
  s_1 :
  p_1 :
  n_1 :
  l_1 :
  j_1 :
  g_1 :
  e_1 :
  c_1 :
  a_1 :
  x_0 :
  v_0 :
  t_0 :
  r_0 :
  p_0 :
  n_0 :
  k_0 :
  i_0 :
  Rpush(k_2);
  goto k_64;
  k_2 :
  Cpop();
  goto g_0;
  h_0 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(l_2);
  goto k_64;
  l_2 :
  AllBuild();
  g_0 :
  d_0 :
  Return();
  c_0 :
  AllBuild();
  Epushd(1,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  BuildVard(1,2);
  Epopd(1,2);
  Cpop();
  goto a_0;
  b_0 :
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildStr("");
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(m_2);
  goto g_79;
  m_2 :
  Tpop();
  Rpush(n_2);
  goto b_79;
  n_2 :
  BuildInt(1);
  Rpush(o_2);
  goto h_79;
  o_2 :
  a_0 :
  Cpush(q_2);
  Tdupl();
  BuildVard(0,7);
  Tpop();
  Tdupl();
  Epushd(1,1);
  BuildFun("TNil",0);
  BuildVard(0,1);
  MatchVard(1,1);
  BuildFun("stderr",0);
  Tpush();
  BuildStr("usage : ");
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildStr(" [-silent] [-i file] [-o file] [-pp] [-b] [-stats] [-help|-h]");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(1,1);
  Rpush(r_2);
  goto g_79;
  r_2 :
  Tpop();
  Rpush(s_2);
  goto b_79;
  s_2 :
  BuildInt(1);
  Rpush(t_2);
  goto h_79;
  t_2 :
  Cpop();
  goto p_2;
  q_2 :
  Cpush(v_2);
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  Cpush(x_2);
  BuildVard(0,3);
  Cpop();
  goto w_2;
  x_2 :
  BuildFun("stdin",0);
  w_2 :
  Rpush(y_2);
  goto c_79;
  y_2 :
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Tdupl();
  Rpush(z_2);
  goto d_79;
  z_2 :
  Tpop();
  Epushd(1,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Arg(1);
  MatchVard(1,2);
  Tpop();
  Tpop();
  BuildVard(1,3);
  Epopd(1,3);
  Rpush(a_3);
  w_64 :
  Cpush(c_3);
  Rpush(d_3);
  goto i_79;
  d_3 :
  Cpop();
  goto b_3;
  c_3 :
  Cpush(f_3);
  Epushd(1,1);
  MatchFun("Match");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  BuildVard(1,1);
  Tpush();
  BuildFun("Id",0);
  Tpush();
  BuildFun("Pat",2);
  Rpush(g_3);
  goto s_79;
  g_3 :
  Epopd(1,1);
  Cpop();
  goto e_3;
  f_3 :
  e_3 :
  b_3 :
  AllInit();
  h_3 :
  AllNextSon(&&i_3);
  Rpush(j_3);
  goto w_64;
  j_3 :
  goto h_3;
  i_3 :
  AllBuild();
  Return();
  a_3 :
  Tdupl();
  Rpush(k_3);
  goto d_79;
  k_3 :
  MatchVard(0,9);
  Tpop();
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(m_3);
  BuildVard(0,4);
  Cpop();
  goto l_3;
  m_3 :
  BuildFun("stdout",0);
  l_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(o_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(p_3);
  goto e_79;
  p_3 :
  Cpop();
  goto n_3;
  o_3 :
  Rpush(q_3);
  goto f_79;
  q_3 :
  n_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting succeeded (");
  Tpush();
  BuildVard(0,9);
  Tpush();
  BuildStr(" secs)");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(r_3);
  goto g_79;
  r_3 :
  BuildInt(0);
  Rpush(s_3);
  goto h_79;
  s_3 :
  Cpop();
  goto u_2;
  v_2 :
  Epushd(1,1);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(1,1);
  Cpush(u_3);
  BuildVard(0,4);
  Cpop();
  goto t_3;
  u_3 :
  BuildFun("stdout",0);
  t_3 :
  MatchVard(2,1);
  Epushd(3,1);
  BuildVard(1,1);
  MatchVard(3,1);
  BuildVard(2,1);
  Tpush();
  BuildVard(3,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(3,1);
  Epopd(2,1);
  Epopd(1,1);
  Cpush(w_3);
  Tdupl();
  BuildVard(0,5);
  Tpop();
  Rpush(x_3);
  goto e_79;
  x_3 :
  Cpop();
  goto v_3;
  w_3 :
  Rpush(y_3);
  goto f_79;
  y_3 :
  v_3 :
  BuildFun("stderr",0);
  Tpush();
  BuildStr("  rewriting failed");
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(z_3);
  goto g_79;
  z_3 :
  BuildInt(1);
  Rpush(a_4);
  goto h_79;
  a_4 :
  u_2 :
  p_2 :
  Epopd(0,9);
  Return();
  z_78 :
  MatchFun("Nil");
  Return();
  a_79 :
  MatchFun("None");
  Return();
  b_79 :
  Tdupl();
  Epushd(0,1);
  MatchVard(0,1);
  Epushd(1,1);
  BuildVard(0,1);
  BuildFun("stderr",0);
  MatchVard(1,1);
  Epushd(2,1);
  BuildVard(0,1);
  Epushd(3,1);
  MatchVard(3,1);
  BuildVard(3,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(3,1);
  MatchVard(2,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(2,1);
  Epopd(1,1);
  Epopd(0,1);
  Rpush(b_4);
  goto g_79;
  b_4 :
  Tpop();
  Return();
  c_79 :
  _ST_ReadFromFile();
  Return();
  d_79 :
  _ST_dtime();
  Return();
  e_79 :
  _ST_WriteToBinaryFile();
  Return();
  f_79 :
  _ST_WriteToTextFile();
  Return();
  g_79 :
  _ST_printnl();
  Return();
  h_79 :
  _ST_exit();
  Return();
  i_79 :
  Rpush(c_4);
  goto j_79;
  c_4 :
  Rpush(d_4);
  goto k_79;
  d_4 :
  Rpush(e_4);
  goto l_79;
  e_4 :
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(f_4);
  goto m_79;
  f_4 :
  Rpush(g_4);
  i_65 :
  Cpush(i_4);
  MatchFun("Let");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(j_4);
  goto i_65;
  j_4 :
  AllBuild();
  Cpop();
  goto h_4;
  i_4 :
  Rpush(k_4);
  goto o_79;
  k_4 :
  h_4 :
  Return();
  g_4 :
  AllBuild();
  Return();
  j_79 :
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(l_4);
  j_65 :
  Cpush(n_4);
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("Seq");
  TravInit();
  OneNextSon();
  MatchFun("Match");
  OneNextSon();
  AllBuild();
  AllBuild();
  Cpop();
  goto m_4;
  n_4 :
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(o_4);
  goto j_65;
  o_4 :
  OneNextSon();
  Rpush(p_4);
  goto j_65;
  p_4 :
  AllBuild();
  m_4 :
  Return();
  l_4 :
  OneNextSon();
  Rpush(q_4);
  k_65 :
  Cpush(s_4);
  MatchFun("Scope");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("Seq");
  TravInit();
  OneNextSon();
  MatchFun("Match");
  OneNextSon();
  AllBuild();
  AllBuild();
  Cpop();
  goto r_4;
  s_4 :
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(t_4);
  goto k_65;
  t_4 :
  OneNextSon();
  Rpush(u_4);
  goto k_65;
  u_4 :
  AllBuild();
  r_4 :
  Return();
  q_4 :
  AllBuild();
  Return();
  k_79 :
  Rpush(v_4);
  p_66 :
  Cpush(x_4);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(y_4);
  goto p_66;
  y_4 :
  OneNextSon();
  Rpush(z_4);
  goto p_66;
  z_4 :
  AllBuild();
  Cpop();
  goto w_4;
  x_4 :
  Epushd(0,6);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Match");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,2);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Id",0);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Pair",2);
  Rpush(a_5);
  q_67 :
  Cpush(c_5);
  Cpush(e_5);
  Epushd(1,4);
  MatchFun("Pair");
  Arg(0);
  MatchFun("Var");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,4);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(f_5);
  Tdupl();
  Epushd(2,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(3,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,3);
  Tpop();
  Arg(1);
  MatchVard(3,2);
  Tpop();
  Tpop();
  BuildVard(3,3);
  Epopd(3,3);
  Rpush(l_5);
  g_5 :
  Cpush(h_5);
  MatchVard(2,1);
  Cpop();
  goto k_5;
  h_5 :
  IsAppl();
  MatchTravInit();
  i_5 :
  OneMatchNextSon();
  Cpush(i_5);
  Rpush(j_5);
  goto g_5;
  j_5 :
  Cpop();
  MatchTravEnd();
  k_5 :
  Return();
  l_5 :
  Epopd(2,1);
  Cpop();
  Crestore();
  Cjump();
  f_5 :
  Tpop();
  BuildVard(1,3);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Pair",2);
  Epopd(1,4);
  Cpop();
  goto d_5;
  e_5 :
  Epushd(1,5);
  MatchFun("Pair");
  Arg(0);
  MatchFun("Var");
  Arg(0);
  MatchVard(1,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,4);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(1,3);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epushd(3,3);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,3);
  Tpop();
  Arg(1);
  MatchVard(3,2);
  Tpop();
  Tpop();
  BuildVard(3,3);
  Epopd(3,3);
  Rpush(r_5);
  m_5 :
  Cpush(n_5);
  MatchVard(2,1);
  Cpop();
  goto q_5;
  n_5 :
  IsAppl();
  MatchTravInit();
  o_5 :
  OneMatchNextSon();
  Cpush(o_5);
  Rpush(p_5);
  goto m_5;
  p_5 :
  Cpop();
  MatchTravEnd();
  q_5 :
  Return();
  r_5 :
  Epopd(2,1);
  new();
  MatchVard(1,5);
  Tpop();
  BuildVard(1,3);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildVard(1,4);
  Tpush();
  BuildVard(1,5);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(1,3);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildFun("Build",1);
  Tpush();
  BuildVard(1,5);
  Tpush();
  BuildFun("Var",1);
  Tpush();
  BuildFun("Match",1);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("Pair",2);
  Epopd(1,5);
  d_5 :
  Cpop();
  goto b_5;
  c_5 :
  ThreadInit();
  s_5 :
  ThreadNextSon(&&t_5);
  Rpush(u_5);
  goto q_67;
  u_5 :
  ThreadSetEnv();
  goto s_5;
  t_5 :
  ThreadBuild();
  b_5 :
  Return();
  a_5 :
  MatchFun("Pair");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,6);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(v_5);
  t_67 :
  Cpush(x_5);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(y_5);
  goto t_67;
  y_5 :
  AllBuild();
  Cpop();
  goto w_5;
  x_5 :
  Rpush(z_5);
  goto z_78;
  z_5 :
  BuildVard(2,1);
  w_5 :
  Return();
  v_5 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Match",1);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Seq",2);
  Tpush();
  BuildFun("Scope",2);
  Epopd(1,1);
  Epopd(0,6);
  w_4 :
  Return();
  v_4 :
  Return();
  l_79 :
  Rpush(a_6);
  c_68 :
  Cpush(c_6);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(d_6);
  goto c_68;
  d_6 :
  OneNextSon();
  Rpush(e_6);
  goto c_68;
  e_6 :
  AllBuild();
  Epushd(0,4);
  MatchFun("Choice");
  Arg(0);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Scope");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(f_6);
  s_68 :
  Cpush(h_6);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(i_6);
  goto s_68;
  i_6 :
  AllBuild();
  Cpop();
  goto g_6;
  h_6 :
  Rpush(j_6);
  goto z_78;
  j_6 :
  BuildVard(2,1);
  g_6 :
  Return();
  f_6 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Choice",2);
  Tpush();
  BuildFun("Scope",2);
  Epopd(1,1);
  Epopd(0,4);
  Cpop();
  goto b_6;
  c_6 :
  b_6 :
  Return();
  a_6 :
  Return();
  m_79 :
  Rpush(k_6);
  w_68 :
  Cpush(m_6);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(n_6);
  goto w_68;
  n_6 :
  OneNextSon();
  Rpush(o_6);
  goto w_68;
  o_6 :
  AllBuild();
  Cpop();
  goto l_6;
  m_6 :
  Epushd(0,3);
  MatchFun("Seq");
  Arg(0);
  MatchFun("Match");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Tdupl();
  new();
  MatchVard(0,3);
  Tpop();
  BuildVard(0,3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildFun("SDef",3);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("SVar",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Call",2);
  Tpush();
  BuildFun("Pat",2);
  Tpush();
  BuildFun("Let",2);
  Epopd(0,3);
  l_6 :
  Return();
  k_6 :
  Rpush(p_6);
  z_38 :
  Rpush(q_6);
  a_69 :
  AllInit();
  r_6 :
  AllNextSon(&&s_6);
  Rpush(t_6);
  goto a_69;
  t_6 :
  goto r_6;
  s_6 :
  AllBuild();
  Cpush(v_6);
  Rpush(w_6);
  goto n_79;
  w_6 :
  AllInit();
  x_6 :
  AllNextSon(&&y_6);
  Rpush(z_6);
  goto z_38;
  z_6 :
  goto x_6;
  y_6 :
  AllBuild();
  Cpop();
  goto u_6;
  v_6 :
  u_6 :
  Return();
  q_6 :
  Return();
  p_6 :
  Return();
  n_79 :
  Cpush(b_7);
  Epushd(0,3);
  MatchFun("Choice");
  Arg(0);
  MatchFun("Let");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Choice",2);
  Tpush();
  BuildFun("Let",2);
  Epopd(0,3);
  Cpop();
  goto a_7;
  b_7 :
  Epushd(0,3);
  MatchFun("Choice");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Let");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Choice",2);
  Tpush();
  BuildFun("Let",2);
  Epopd(0,3);
  a_7 :
  Return();
  o_79 :
  Rpush(c_7);
  goto p_79;
  c_7 :
  Return();
  p_79 :
  Rpush(d_7);
  goto q_79;
  d_7 :
  Rpush(e_7);
  goto r_79;
  e_7 :
  Rpush(f_7);
  goto w_79;
  f_7 :
  Return();
  q_79 :
  Rpush(g_7);
  b_69 :
  Cpush(i_7);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(j_7);
  goto b_69;
  j_7 :
  OneNextSon();
  Rpush(k_7);
  goto b_69;
  k_7 :
  AllBuild();
  Cpop();
  goto h_7;
  i_7 :
  Epushd(0,1);
  MatchVard(0,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Epopd(0,1);
  h_7 :
  Return();
  g_7 :
  Rpush(l_7);
  i_69 :
  Cpush(n_7);
  MatchFun("Choice");
  TravInit();
  OneNextSon();
  Rpush(o_7);
  goto i_69;
  o_7 :
  OneNextSon();
  Rpush(p_7);
  goto i_69;
  p_7 :
  AllBuild();
  Epushd(0,2);
  MatchFun("Choice");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(1,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(1,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(1,2);
  Rpush(q_7);
  s_69 :
  Cpush(s_7);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(t_7);
  goto s_69;
  t_7 :
  AllBuild();
  Cpop();
  goto r_7;
  s_7 :
  Rpush(u_7);
  goto z_78;
  u_7 :
  BuildVard(1,1);
  r_7 :
  Return();
  q_7 :
  Epopd(1,2);
  Epopd(0,2);
  Cpop();
  goto m_7;
  n_7 :
  m_7 :
  Return();
  l_7 :
  Return();
  r_79 :
  Rpush(v_7);
  t_69 :
  Cpush(x_7);
  Rpush(y_7);
  goto z_78;
  y_7 :
  Cpop();
  goto w_7;
  x_7 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Rpush(z_7);
  goto s_79;
  z_7 :
  OneNextSon();
  Rpush(a_8);
  goto t_69;
  a_8 :
  AllBuild();
  w_7 :
  Return();
  v_7 :
  Return();
  s_79 :
  Epushd(0,2);
  MatchFun("Pat");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildFun("MatchTerm",3);
  Epopd(0,2);
  Rpush(b_8);
  h_71 :
  Cpush(d_8);
  c_8 :
  Cpush(f_8);
  Epushd(0,2);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("Wld");
  Tpop();
  Arg(2);
  MatchVard(0,2);
  Tpop();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,2);
  Cpop();
  goto e_8;
  f_8 :
  Cpush(h_8);
  Epushd(0,3);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Str");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Str",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,3);
  Cpop();
  goto g_8;
  h_8 :
  Cpush(j_8);
  Rpush(k_8);
  goto t_79;
  k_8 :
  Cpop();
  goto i_8;
  j_8 :
  Cpush(m_8);
  Rpush(n_8);
  goto u_79;
  n_8 :
  Cpop();
  goto l_8;
  m_8 :
  Cpush(p_8);
  Epushd(0,4);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Op");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Fun",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildInt(0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("MatchKids",4);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,4);
  Cpop();
  goto o_8;
  p_8 :
  Cpush(r_8);
  Epushd(0,3);
  MatchFun("MatchKids");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchFun("Nil");
  Tpop();
  Arg(3);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,3);
  Epopd(0,3);
  Cpop();
  goto q_8;
  r_8 :
  Epushd(0,5);
  MatchFun("MatchKids");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(3);
  MatchVard(0,5);
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Tpush();
  BuildInt(1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Rpush(s_8);
  goto v_79;
  s_8 :
  MatchVard(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("MatchKids",4);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("MatchTerm",3);
  Tpush();
  BuildFun("Down",2);
  Epopd(1,1);
  Epopd(0,5);
  q_8 :
  o_8 :
  l_8 :
  i_8 :
  g_8 :
  e_8 :
  Tduplinv();
  goto c_8;
  d_8 :
  AllInit();
  t_8 :
  AllNextSon(&&u_8);
  Rpush(v_8);
  goto h_71;
  v_8 :
  goto t_8;
  u_8 :
  AllBuild();
  Return();
  b_8 :
  Return();
  t_79 :
  Cpush(x_8);
  Epushd(0,3);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Int");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Int",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,3);
  Cpop();
  goto w_8;
  x_8 :
  Epushd(0,3);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Real");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Real",1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,3);
  w_8 :
  Return();
  u_79 :
  Cpush(z_8);
  Epushd(0,3);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Var");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,3);
  Cpop();
  goto y_8;
  z_8 :
  Epushd(0,3);
  MatchFun("MatchTerm");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("Var");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,3);
  y_8 :
  Return();
  v_79 :
  _ST_plus();
  Return();
  w_79 :
  Rpush(a_9);
  b_72 :
  Cpush(c_9);
  Rpush(d_9);
  goto z_78;
  d_9 :
  BuildFun("Fail",0);
  Tpush();
  BuildFun("Accept",1);
  Cpop();
  goto b_9;
  c_9 :
  Epushd(0,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epopd(0,2);
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  OneNextSon();
  MatchFun("TCons");
  TravInit();
  OneNextSon();
  Rpush(e_9);
  goto b_72;
  e_9 :
  OneNextSon();
  Rpush(f_9);
  goto x_79;
  f_9 :
  AllBuild();
  AllBuild();
  Rpush(g_9);
  goto y_79;
  g_9 :
  b_9 :
  Return();
  a_9 :
  Return();
  x_79 :
  MatchFun("TNil");
  Return();
  y_79 :
  Epushd(0,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Merge",2);
  Epopd(0,2);
  Rpush(n_9);
  t_75 :
  Cpush(p_9);
  o_9 :
  Cpush(r_9);
  Rpush(s_9);
  goto z_79;
  s_9 :
  Cpop();
  goto q_9;
  r_9 :
  Cpush(u_9);
  Epushd(0,6);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,5);
  Rpush(v_9);
  z_76 :
  Cpush(x_9);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,2);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(1,1);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(1,2);
  Tpop();
  Epushd(2,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(3,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(3,1);
  Rpush(y_9);
  a_77 :
  Cpush(a_10);
  Rpush(b_10);
  goto z_78;
  b_10 :
  BuildVard(3,2);
  Cpop();
  goto z_9;
  a_10 :
  Cpush(d_10);
  Epushd(4,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Arg(1);
  MatchVard(4,1);
  Tpop();
  Tdupl();
  BuildVard(3,2);
  Tdupl();
  e_10 :
  MatchFun("Cons");
  Cpush(f_10);
  Arg(0);
  MatchVard(4,2);
  Tpop();
  Cpop();
  goto g_10;
  f_10 :
  Arg(1);
  Tdrop();
  goto e_10;
  g_10 :
  Tpop();
  Tpop();
  BuildVard(4,1);
  Epopd(4,2);
  Rpush(h_10);
  goto a_77;
  h_10 :
  Cpop();
  goto c_10;
  d_10 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(i_10);
  goto a_77;
  i_10 :
  AllBuild();
  c_10 :
  z_9 :
  Return();
  y_9 :
  Epopd(3,2);
  MatchVard(2,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(1,2);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(2,1);
  Epopd(1,2);
  OneNextSon();
  AllBuild();
  Cpop();
  goto w_9;
  x_9 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(j_10);
  goto z_76;
  j_10 :
  AllBuild();
  w_9 :
  Return();
  v_9 :
  MatchVard(0,6);
  Tpop();
  BuildVard(0,6);
  Tpush();
  BuildFun("Case",1);
  Epopd(0,6);
  Cpop();
  goto t_9;
  u_9 :
  Cpush(l_10);
  Epushd(0,7);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Arg(3);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,7);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,7);
  Tdupl();
  m_10 :
  MatchFun("Cons");
  Cpush(n_10);
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchVard(0,5);
  Tpop();
  Arg(2);
  MatchVard(0,6);
  Tpop();
  Tpop();
  Cpop();
  goto o_10;
  n_10 :
  Arg(1);
  Tdrop();
  goto m_10;
  o_10 :
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,1);
  Rpush(p_10);
  d_77 :
  Cpush(r_10);
  Rpush(s_10);
  goto z_78;
  s_10 :
  BuildVard(2,2);
  Cpop();
  goto q_10;
  r_10 :
  Cpush(u_10);
  Epushd(3,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,1);
  Tpop();
  Tdupl();
  BuildVard(2,2);
  Tdupl();
  v_10 :
  MatchFun("Cons");
  Cpush(w_10);
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Cpop();
  goto x_10;
  w_10 :
  Arg(1);
  Tdrop();
  goto v_10;
  x_10 :
  Tpop();
  Tpop();
  BuildVard(3,1);
  Epopd(3,2);
  Rpush(y_10);
  goto d_77;
  y_10 :
  Cpop();
  goto t_10;
  u_10 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(z_10);
  goto d_77;
  z_10 :
  AllBuild();
  t_10 :
  q_10 :
  Return();
  p_10 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Tpush();
  BuildVard(0,7);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,7);
  Cpop();
  goto k_10;
  l_10 :
  Epushd(0,5);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("MatchFunA",4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Case",1);
  Epopd(0,5);
  k_10 :
  t_9 :
  q_9 :
  Tduplinv();
  goto o_9;
  p_9 :
  AllInit();
  a_11 :
  AllNextSon(&&b_11);
  Rpush(c_11);
  goto t_75;
  c_11 :
  goto a_11;
  b_11 :
  AllBuild();
  Return();
  n_9 :
  Return();
  z_79 :
  Cpush(e_11);
  Epushd(0,6);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,1);
  Rpush(f_11);
  f_77 :
  Cpush(h_11);
  Rpush(i_11);
  goto z_78;
  i_11 :
  Cpop();
  goto g_11;
  h_11 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(1,1);
  MatchVard(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("MatchVars",3);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildFun("Merge2",2);
  Epopd(1,1);
  OneNextSon();
  Rpush(j_11);
  goto f_77;
  j_11 :
  AllBuild();
  g_11 :
  Return();
  f_11 :
  MatchVard(0,5);
  Cpush(l_11);
  BuildVard(0,1);
  Tdupl();
  m_11 :
  MatchFun("Cons");
  Cpush(n_11);
  Arg(0);
  MatchFun("MatchVars");
  Tpop();
  Cpop();
  goto o_11;
  n_11 :
  Arg(1);
  Tdrop();
  goto m_11;
  o_11 :
  Tpop();
  BuildVard(0,5);
  Cpop();
  goto k_11;
  l_11 :
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("MatchVars",3);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Cons",2);
  k_11 :
  MatchVard(0,6);
  Tpop();
  BuildVard(0,6);
  Tpush();
  BuildFun("Case",1);
  Epopd(0,6);
  Cpop();
  goto d_11;
  e_11 :
  Cpush(q_11);
  Epushd(0,5);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(r_11);
  l_77 :
  Cpush(t_11);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(u_11);
  goto l_77;
  u_11 :
  AllBuild();
  Cpop();
  goto s_11;
  t_11 :
  Rpush(v_11);
  goto z_78;
  v_11 :
  BuildVard(2,1);
  s_11 :
  Return();
  r_11 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(1,1);
  Epopd(0,5);
  Cpop();
  goto p_11;
  q_11 :
  Cpush(x_11);
  Epushd(0,6);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Arg(3);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Arg(3);
  MatchVard(0,6);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,1);
  Rpush(y_11);
  o_77 :
  Cpush(a_12);
  Rpush(b_12);
  goto z_78;
  b_12 :
  BuildVard(2,2);
  Cpop();
  goto z_11;
  a_12 :
  Cpush(d_12);
  Epushd(3,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,1);
  Tpop();
  Tdupl();
  BuildVard(2,2);
  Tdupl();
  e_12 :
  MatchFun("Cons");
  Cpush(f_12);
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Cpop();
  goto g_12;
  f_12 :
  Arg(1);
  Tdrop();
  goto e_12;
  g_12 :
  Tpop();
  Tpop();
  BuildVard(3,1);
  Epopd(3,2);
  Rpush(h_12);
  goto o_77;
  h_12 :
  Cpop();
  goto c_12;
  d_12 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(i_12);
  goto o_77;
  i_12 :
  AllBuild();
  c_12 :
  z_11 :
  Return();
  y_11 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(1,1);
  Epopd(0,6);
  Cpop();
  goto w_11;
  x_11 :
  Cpush(k_12);
  Epushd(0,7);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,6);
  Tpop();
  Arg(1);
  MatchVard(0,1);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Arg(3);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,7);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Arg(3);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Tdupl();
  BuildVard(0,6);
  Tpush();
  BuildVard(0,7);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Cpush(l_12);
  Tdupl();
  Rpush(m_12);
  goto a_80;
  m_12 :
  Cpop();
  Crestore();
  Cjump();
  l_12 :
  Tpop();
  BuildVard(0,6);
  Tpush();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("MatchFunA",4);
  Tpush();
  BuildVard(0,7);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("MatchFunA",4);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Case",1);
  Epopd(0,7);
  Cpop();
  goto j_12;
  k_12 :
  Cpush(o_12);
  Epushd(0,6);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Arg(3);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchVard(0,5);
  Tpop();
  Arg(2);
  MatchVard(0,6);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,4);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,1);
  Rpush(p_12);
  u_77 :
  Cpush(r_12);
  Rpush(s_12);
  goto z_78;
  s_12 :
  BuildVard(2,2);
  Cpop();
  goto q_12;
  r_12 :
  Cpush(u_12);
  Epushd(3,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,1);
  Tpop();
  Tdupl();
  BuildVard(2,2);
  Tdupl();
  v_12 :
  MatchFun("Cons");
  Cpush(w_12);
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Cpop();
  goto x_12;
  w_12 :
  Arg(1);
  Tdrop();
  goto v_12;
  x_12 :
  Tpop();
  Tpop();
  BuildVard(3,1);
  Epopd(3,2);
  Rpush(y_12);
  goto u_77;
  y_12 :
  Cpop();
  goto t_12;
  u_12 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(f_13);
  goto u_77;
  f_13 :
  AllBuild();
  t_12 :
  q_12 :
  Return();
  p_12 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("MatchVars",3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,6);
  Cpop();
  goto n_12;
  o_12 :
  Cpush(c_16);
  Epushd(0,6);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Arg(1);
  MatchVard(0,5);
  Tpop();
  Arg(2);
  MatchVard(0,6);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Arg(3);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,4);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,1);
  Rpush(d_17);
  a_78 :
  Cpush(o_17);
  Rpush(p_17);
  goto z_78;
  p_17 :
  BuildVard(2,2);
  Cpop();
  goto g_17;
  o_17 :
  Cpush(r_17);
  Epushd(3,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,1);
  Tpop();
  Tdupl();
  BuildVard(2,2);
  Tdupl();
  s_17 :
  MatchFun("Cons");
  Cpush(t_17);
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Cpop();
  goto a_18;
  t_17 :
  Arg(1);
  Tdrop();
  goto s_17;
  a_18 :
  Tpop();
  Tpop();
  BuildVard(3,1);
  Epopd(3,2);
  Rpush(b_18);
  goto a_78;
  b_18 :
  Cpop();
  goto q_17;
  r_17 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(c_18);
  goto a_78;
  c_18 :
  AllBuild();
  q_17 :
  g_17 :
  Return();
  d_17 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("MatchVars",3);
  Tpush();
  BuildFun("Nil",0);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Cons",2);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,6);
  Cpop();
  goto z_15;
  c_16 :
  Cpush(k_18);
  Epushd(0,6);
  MatchFun("Merge2");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,4);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Arg(3);
  MatchVard(0,6);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,1);
  Rpush(l_18);
  g_78 :
  Cpush(n_18);
  Rpush(o_18);
  goto z_78;
  o_18 :
  BuildVard(2,2);
  Cpop();
  goto m_18;
  n_18 :
  Cpush(q_18);
  Epushd(3,2);
  MatchFun("Cons");
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Arg(1);
  MatchVard(3,1);
  Tpop();
  Tdupl();
  BuildVard(2,2);
  Tdupl();
  r_18 :
  MatchFun("Cons");
  Cpush(s_18);
  Arg(0);
  MatchVard(3,2);
  Tpop();
  Cpop();
  goto t_18;
  s_18 :
  Arg(1);
  Tdrop();
  goto r_18;
  t_18 :
  Tpop();
  Tpop();
  BuildVard(3,1);
  Epopd(3,2);
  Rpush(u_18);
  goto g_78;
  u_18 :
  Cpop();
  goto p_18;
  q_18 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(v_18);
  goto g_78;
  v_18 :
  AllBuild();
  p_18 :
  m_18 :
  Return();
  l_18 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(1,1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildVard(0,6);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(1,1);
  Epopd(0,6);
  Cpop();
  goto j_18;
  k_18 :
  Cpush(x_18);
  Epushd(0,5);
  MatchFun("Merge2");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Arg(2);
  MatchVard(0,5);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("TNil",0);
  Tpush();
  BuildFun("TCons",2);
  Tpush();
  BuildFun("TCons",2);
  Epushd(2,2);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,2);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(2,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  BuildVard(2,2);
  Rpush(y_18);
  m_78 :
  Cpush(a_19);
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  OneNextSon();
  Rpush(b_19);
  goto m_78;
  b_19 :
  AllBuild();
  Cpop();
  goto z_18;
  a_19 :
  Rpush(c_19);
  goto z_78;
  c_19 :
  BuildVard(2,1);
  z_18 :
  Return();
  y_18 :
  Epopd(2,2);
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(1,1);
  Epopd(0,5);
  Cpop();
  goto w_18;
  x_18 :
  Cpush(e_19);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Up",1);
  Epopd(0,2);
  Cpop();
  goto d_19;
  e_19 :
  Cpush(g_19);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Up",1);
  Epopd(0,2);
  Cpop();
  goto f_19;
  g_19 :
  Cpush(i_19);
  Epushd(0,3);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Down");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Down",2);
  Epopd(0,3);
  Cpop();
  goto h_19;
  i_19 :
  Cpush(k_19);
  Epushd(0,3);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Down");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Down",2);
  Epopd(0,3);
  Cpop();
  goto j_19;
  k_19 :
  Cpush(m_19);
  Epushd(0,5);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,5);
  Cpop();
  goto l_19;
  m_19 :
  Cpush(o_19);
  Epushd(0,5);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(0,5);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,5);
  Cpop();
  goto n_19;
  o_19 :
  Cpush(q_19);
  Epushd(0,4);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,4);
  Cpop();
  goto p_19;
  q_19 :
  Cpush(s_19);
  Epushd(0,4);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,4);
  Cpop();
  goto r_19;
  s_19 :
  Cpush(u_19);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Rpush(v_19);
  n_78 :
  Cpush(x_19);
  Rpush(y_19);
  goto z_78;
  y_19 :
  Cpop();
  goto w_19;
  x_19 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("Merge",2);
  Epopd(2,1);
  OneNextSon();
  Rpush(z_19);
  goto n_78;
  z_19 :
  AllBuild();
  w_19 :
  Return();
  v_19 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,2);
  Cpop();
  goto t_19;
  u_19 :
  Cpush(b_20);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Rpush(c_20);
  q_78 :
  Cpush(e_20);
  Rpush(f_20);
  goto z_78;
  f_20 :
  Cpop();
  goto d_20;
  e_20 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Accept",1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("Merge",2);
  Epopd(2,1);
  OneNextSon();
  Rpush(g_20);
  goto q_78;
  g_20 :
  AllBuild();
  d_20 :
  Return();
  c_20 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,2);
  Cpop();
  goto a_20;
  b_20 :
  Cpush(i_20);
  Epushd(0,3);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Down");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Down",2);
  Epopd(0,3);
  Cpop();
  goto h_20;
  i_20 :
  Cpush(k_20);
  Epushd(0,3);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Down");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Down",2);
  Epopd(0,3);
  Cpop();
  goto j_20;
  k_20 :
  Cpush(m_20);
  Epushd(0,5);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,5);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,5);
  Cpop();
  goto l_20;
  m_20 :
  Cpush(o_20);
  Epushd(0,5);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchFunA");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Arg(3);
  MatchVard(0,5);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildVard(0,5);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchFunA",4);
  Epopd(0,5);
  Cpop();
  goto n_20;
  o_20 :
  Cpush(q_20);
  Epushd(0,4);
  MatchFun("Merge");
  Arg(0);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,4);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,4);
  Cpop();
  goto p_20;
  q_20 :
  Cpush(s_20);
  Epushd(0,4);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,3);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("MatchVars");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Arg(2);
  MatchVard(0,4);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildVard(0,4);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("MatchVars",3);
  Epopd(0,4);
  Cpop();
  goto r_20;
  s_20 :
  Cpush(u_20);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Rpush(v_20);
  t_78 :
  Cpush(x_20);
  Rpush(y_20);
  goto z_78;
  y_20 :
  Cpop();
  goto w_20;
  x_20 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("Merge",2);
  Epopd(2,1);
  OneNextSon();
  Rpush(z_20);
  goto t_78;
  z_20 :
  AllBuild();
  w_20 :
  Return();
  v_20 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,2);
  Cpop();
  goto t_20;
  u_20 :
  Cpush(b_21);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Case");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Epushd(1,1);
  BuildVard(0,2);
  Rpush(c_21);
  w_78 :
  Cpush(e_21);
  Rpush(f_21);
  goto z_78;
  f_21 :
  Cpop();
  goto d_21;
  e_21 :
  MatchFun("Cons");
  TravInit();
  OneNextSon();
  Epushd(2,1);
  MatchVard(2,1);
  BuildVard(0,1);
  Tpush();
  BuildFun("Up",1);
  Tpush();
  BuildVard(2,1);
  Tpush();
  BuildFun("Merge",2);
  Epopd(2,1);
  OneNextSon();
  Rpush(g_21);
  goto w_78;
  g_21 :
  AllBuild();
  d_21 :
  Return();
  c_21 :
  MatchVard(1,1);
  BuildVard(1,1);
  Tpush();
  BuildFun("Case",1);
  Epopd(1,1);
  Epopd(0,2);
  Cpop();
  goto a_21;
  b_21 :
  Cpush(i_21);
  Epushd(0,3);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Down");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,2);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Down");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchVard(0,3);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildVard(0,3);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Down",2);
  Epopd(0,3);
  Cpop();
  goto h_21;
  i_21 :
  Cpush(k_21);
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Up");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Merge",2);
  Tpush();
  BuildFun("Up",1);
  Epopd(0,2);
  Cpop();
  goto j_21;
  k_21 :
  Epushd(0,2);
  MatchFun("Merge");
  Arg(0);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Tpop();
  Arg(1);
  MatchFun("Accept");
  Arg(0);
  MatchVard(0,2);
  Tpop();
  Tpop();
  BuildVard(0,1);
  Tpush();
  BuildVard(0,2);
  Tpush();
  BuildFun("Choice",2);
  Tpush();
  BuildFun("Accept",1);
  Epopd(0,2);
  j_21 :
  h_21 :
  a_21 :
  t_20 :
  r_20 :
  p_20 :
  n_20 :
  l_20 :
  j_20 :
  h_20 :
  a_20 :
  t_19 :
  r_19 :
  p_19 :
  n_19 :
  l_19 :
  j_19 :
  h_19 :
  f_19 :
  d_19 :
  w_18 :
  j_18 :
  z_15 :
  n_12 :
  j_12 :
  w_11 :
  p_11 :
  d_11 :
  Return();
  a_80 :
  Epushd(0,1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TCons");
  Arg(0);
  MatchVard(0,1);
  Tpop();
  Arg(1);
  MatchFun("TNil");
  Tpop();
  Tpop();
  Epopd(0,1);
  Return();
  l_21 :
DOIT_END
