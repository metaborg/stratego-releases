(*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*)

\literate[{\btt LIST-INDEX}]
\begin{code}
module list-index
imports list-cons simple-traversal
rules

  Ind1   : (1, Cons(x, xs)) -> x
  Ind2   : (n, Cons(x, xs)) -> (<minus> (n, 1), xs) where <geq> (n, 2)

  Gind0  : (x, ys) -> (1, x, ys)
  Gind1  : (n, x, Cons(x, xs)) -> n
  Gind2  : (n, y, Cons(x, xs)) -> (<plus> (n, 1), y, xs)

strategies

(* Index: Get the n-th element of a list *)

  index = repeat(Ind2) ; Ind1

(* Get-index: get index of element in list *)

   get_index = Gind0 ; rec x(Gind1 <+ Gind2 ; x)
   get-index = Gind0 ; rec x(Gind1 <+ Gind2 ; x)
\end{code}

