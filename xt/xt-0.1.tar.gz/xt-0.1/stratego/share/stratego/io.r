(*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*)

\literate[{\btt IO}]

\begin{code}
module io
imports list string tuple integers time
signature
  sorts File
  operations
    stdin  : File
    stdout : File
    stderr : File
strategies

  exit		    = prim("_ST_exit")
  print             = prim("_ST_print")
  printnl           = prim("_ST_printnl")
  printascii        = prim("_ST_printascii")

  open-file	    = prim("_ST_open_file")
  close-file	    = prim("_ST_close_file")

  ReadFromFile      = prim("_ST_ReadFromFile")
  WriteToBinaryFile = prim("_ST_WriteToBinaryFile")
  WriteToTextFile   = prim("_ST_WriteToTextFile")

\end{code}

 	The primitive \verb|print-stack| prints the top n elements of
 	the stack if applied as <print-stack> n or the entire stack if
 	applied to a non-integer term.

\begin{code}
  print-stack       = prim("_ST_PrintStack")
\end{code}

\begin{code}
rules

  singleton : x -> [x]

strategies

  debug = where(split(!stderr, singleton); printnl)

  fatal-error = where(split(!stderr, id); printnl)
\end{code}

	The operator \verb|stdio| implements a simple user-interface
	for transformers. A term is read from standard input,
	transformed with parameter strategy \verb|s| and then written
	to standard output. If the transformation failed the text
	\verb|rewriting failed| is written to standard error.

\begin{code}
strategies

  stdio(s) = !stdin; ReadFromFile;
             s; split(!stdout, id); WriteToTextFile
             <+ <printnl>(stderr, ["rewriting failed"])
\end{code}

	A variant of this strategy provides a pair of the command-line
	options and the input file to the strategy.

\begin{code}
strategies

  stdioO(s) = split(id, !stdin; ReadFromFile); s;
              split(!stdout, id); WriteToTextFile
              <+ <printnl>(stderr, ["rewriting failed"])
\end{code}

