(*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*)

\literate[{\btt SUBSTITUTION}: Operations on Terms with Object Variables]

\begin{code}
module subs
imports simple-traversal tuple list

strategies
\end{code}

	Test occurrence of a in b 

\begin{code}
  in = {a: match((a, _)) ; Snd ; oncetd(match(a))}
\end{code} 

	\paragraph{Free Variables}

	Free variables of a term; The first argument s1 is a strategy
	that transforms variables into lists of variables e;g;
	\verb|Var(x) -> [x]|; The second argument s2 is a strategy
	that maps binding constructs to the list of bound variables,
	e;g; \verb|Scope(xs, s) -> xs|;

\begin{code}
  vars(getvars, boundvars) = 
    rec x(getvars <+ 
          {l1, l2: where(collect-kids(x) => l1); 
	           (boundvars => l2; <diff> (l1, l2)
	            <+ !l1)})
\end{code}

	\paragraph{Substitution}

	Given a triple (xs, ts, t) of a list of strings, a list of
	terms ts and a term t, replace each occurence in t of a
	variable x from xs by its corresponding occurence in ts; The
	parameter strategy isvar should be a rule (or choice of rules)
	of the form Var(x) -> x that recognizes the variable
	constructor and strips it away;

\begin{code}
  subs(isvar) = 
    {lst, xs, ts, t
    : ?(xs, ts, t) ; 
      <zip(id)> (xs, ts) => lst ; 
      <alltd(isvar ; {x, z:<<x -> z where <fetch(?(x, z))> lst >>})> t
    }

  subs'(isvar, mklst) = 
    {lst 
    : where(mklst => lst);
      alltd(isvar; {x, z:<<x -> z where <fetch(?(x, z))> lst >>})
    }

  subs_proper(isvar, ren) = 
    {lst, xs, ts, t
    : ?(xs, ts, t) ; 
      <zip(id)> (xs, ts) => lst ; 
      <alltd(isvar ; {x, z:<<x -> <ren> z where <fetch(?(x, z))> lst >>})> t
    }

  subs_proper'(isvar, ren, mklst) = 
    {lst
    : where(mklst => lst);
      alltd(isvar ; {x, z:<<x -> <ren> z where <fetch(?(x, z))> lst >>})
    }
\end{code} 

\paragraph{Alpha Renaming}

The strategy rename(isvar, mkvar, bnd) renames all bound variables in a term
to fresh variables;

Parameters:
  isvar: Succeeds if applied to a variable
  mkvar: Takes a string and builds a variable
  bnd: Maps a binding construct to the list of bound variables
  rn\_apply(a, b, c): reconstruct the binding construct with fresh variables;
	- a should be applied to the subterm containing the variable(s)
	- b should be applied to the subterms in which the variables are bound
	- c should be applied to the subterms in which the variables are not bound;

\begin{code}
strategies

  rename(isvar, mkvar, bnd)
  = {t : <<t -> (t, [])>>} ; 
    rec ren1( 
    {l: {t: <<(t, l) -> t>>} ; 
        rec ren2( 
        ({t': match(t') ;
             (  isvar ; <lookup> (t', l) 
	     <+ {xs, ys, l':
		 <bnd> t' => xs ; 
	 	 <map(new)> xs => ys ;
		 <conc> (<zip((mkvar,mkvar))> (xs, ys), l) => l' ;
		 <rn_apply(build(ys), {x:<<x -> <ren1> (x, l')>>}, ren2)> t'})}
         <+ all(ren2)))
    })

  rename'(isvar, mkvar, bnd, apply)
  = {t : <<t -> (t, [])>>} ; 
    rec ren1( 
    {l: {t: <<(t, l) -> t>>} ; 
        rec ren2( 
        ({t': match(t') ;
             (  isvar ; <lookup> (t', l) 
	     <+ {xs, ys, l':
		 <bnd> t' => xs ; 
	 	 <map(new)> xs => ys ;
		 <conc> (<zip((mkvar,mkvar))> (xs, ys), l) => l' ;
		 <apply(build(ys), {x:<<x -> <ren1> (x, l')>>}, ren2)> t'})}
         <+ all(ren2)))
    })
\end{code}
