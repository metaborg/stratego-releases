(*

Copyright (C) 1998, 1999 Eelco Visser <visser@acm.org>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
02111-1307, USA.

*)

\literate[{\btt LIST-MISC}]

\begin{code}
module list-misc
imports list-cons list-basic
strategies

  member = {x : (match(x), fetch(match(x)))}

rules

  FoldR    : Cons(x, xs) -> (x, xs)
  TFoldR   : TCons(x, xs) -> (x, xs)

  FoldL(s) : (Cons(x, xs), y) -> (xs, <s> (x, y))
  FoldL(s) : (Nil, y) -> y

  lsplit(f, g) : x -> [<f> x, <g> x]

strategies

  foldr(s1, s2)  = rec x(Nil; s1 + FoldR; (id, x); s2)
  tfoldr(s1, s2) = rec x(TNil; s1 + TFoldR; (id, x); s2)

  foldl(s) = repeat(FoldL(s))

  mapfoldr(s1, s2, s3) = rec x(Nil ; s1 <+ kids ; (s2, x) ; s3)

  last = rec x(Last <+ Tl; x)

  init = at_last(Tl)
\end{code}
