
#ifndef VERSION_H
#define VERSION_H

extern char *at_version;
extern char *at_date;

#endif
