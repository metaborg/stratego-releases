
#ifndef LIST_H
#define LIST_H

void AT_initList(int argc, char *argv[]);

#endif
