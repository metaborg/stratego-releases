#include "aterm2.h"

void AFinitAsFixPatterns();
