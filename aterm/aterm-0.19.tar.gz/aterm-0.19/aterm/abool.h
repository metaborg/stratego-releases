/**
  * abool.h: booleans for the ATerm library.
  */

#ifndef ABOOL_H
#define ABOOL_H

typedef enum { ATfalse=0, ATtrue } ATbool;

#endif
