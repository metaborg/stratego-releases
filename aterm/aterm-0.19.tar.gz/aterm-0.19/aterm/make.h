
#ifndef MAKE_H
#define MAKE_H

#include <stdarg.h>

void AT_initMake(int argc, char *argv[]);

#endif
